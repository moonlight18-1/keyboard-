package com.mlkeyboard.ime

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var config: KeyboardConfig
    private lateinit var statusLabel: TextView
    private lateinit var testInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        config = KeyboardConfig.load(this)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        refreshImeStatus()
    }

    private fun d(dp: Int): Int = (dp * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#F6F7F9"))
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(20), d(28), d(20), d(32))
        }

        val title = TextView(this).apply {
            text = "ML Keyboard"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.parseColor("#0F172A"))
        }
        val subtitle = TextView(this).apply {
            text = "Fast, zero-lag English-only Android keyboard"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#475569"))
            setPadding(0, d(4), 0, d(20))
        }
        container.addView(title)
        container.addView(subtitle)

        // Setup Card
        val setupCard = createCard()
        statusLabel = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(0, 0, 0, d(12))
        }
        setupCard.addView(statusLabel)

        val enableBtn = createPrimaryButton("1. Enable ML Keyboard in Settings") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        val selectBtn = createSecondaryButton("2. Set as Default Keyboard") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        setupCard.addView(enableBtn)
        setupCard.addView(spacer(10))
        setupCard.addView(selectBtn)
        container.addView(setupCard)
        container.addView(spacer(16))

        // Live Test Input Card
        val testCard = createCard()
        testCard.addView(sectionHeader("Test Typing"))
        testInput = EditText(this).apply {
            hint = "Tap here to test ML Keyboard speed..."
            minLines = 2
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextColor(Color.parseColor("#0F172A"))
            setHintTextColor(Color.parseColor("#94A3B8"))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F1F5F9"))
                cornerRadius = d(10).toFloat()
            }
            setPadding(d(12), d(12), d(12), d(12))
        }
        testCard.addView(testInput)
        container.addView(testCard)
        container.addView(spacer(16))

        // Theme & Height Card
        val appearanceCard = createCard()
        appearanceCard.addView(sectionHeader("Appearance & Layout"))
        appearanceCard.addView(createOptionCycleRow("Keyboard Theme", { config.theme.name }) {
            val next = when (config.theme) {
                KeyboardTheme.LIGHT -> KeyboardTheme.DARK
                KeyboardTheme.DARK -> KeyboardTheme.OLED
                KeyboardTheme.OLED -> KeyboardTheme.LIGHT
            }
            config = config.copy(theme = next)
            KeyboardConfig.save(this, config)
            config.theme.name
        })
        appearanceCard.addView(createOptionCycleRow("Key Height", { config.keyHeight.name }) {
            val next = when (config.keyHeight) {
                KeyHeightPreset.COMPACT -> KeyHeightPreset.STANDARD
                KeyHeightPreset.STANDARD -> KeyHeightPreset.TALL
                KeyHeightPreset.TALL -> KeyHeightPreset.COMPACT
            }
            config = config.copy(keyHeight = next)
            KeyboardConfig.save(this, config)
            config.keyHeight.name
        })
        appearanceCard.addView(createToggleRow("Number Row (1-0)", config.numberRow) {
            config = config.copy(numberRow = it)
            KeyboardConfig.save(this, config)
        })
        container.addView(appearanceCard)
        container.addView(spacer(16))

        // Behavior Card
        val behaviorCard = createCard()
        behaviorCard.addView(sectionHeader("Typing Behavior"))
        behaviorCard.addView(createToggleRow("Keypress Popup Preview", config.keypressPopup) {
            config = config.copy(keypressPopup = it)
            KeyboardConfig.save(this, config)
        })
        behaviorCard.addView(createToggleRow("Sound on Keypress", config.soundOnKeypress) {
            config = config.copy(soundOnKeypress = it)
            KeyboardConfig.save(this, config)
        })
        behaviorCard.addView(createToggleRow("Haptic Vibration", config.hapticFeedback) {
            config = config.copy(hapticFeedback = it)
            KeyboardConfig.save(this, config)
        })
        behaviorCard.addView(createToggleRow("Auto-Capitalize Sentences", config.autoCapitalize) {
            config = config.copy(autoCapitalize = it)
            KeyboardConfig.save(this, config)
        })
        behaviorCard.addView(createToggleRow("Double-Space Period", config.doubleSpacePeriod) {
            config = config.copy(doubleSpacePeriod = it)
            KeyboardConfig.save(this, config)
        })
        behaviorCard.addView(createToggleRow("English Auto-Correct", config.autoCorrect) {
            config = config.copy(autoCorrect = it)
            KeyboardConfig.save(this, config)
        })
        container.addView(behaviorCard)

        scroll.addView(container)
        refreshImeStatus()
        return scroll
    }

    private fun refreshImeStatus() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val defaultIme = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: ""
        val isActive = defaultIme.startsWith(packageName)

        when {
            isActive -> {
                statusLabel.text = "Active: ML Keyboard is your default keyboard"
                statusLabel.setTextColor(Color.parseColor("#16A34A"))
            }
            enabled -> {
                statusLabel.text = "Enabled: Tap Step 2 below to set ML Keyboard as active"
                statusLabel.setTextColor(Color.parseColor("#D97706"))
            }
            else -> {
                statusLabel.text = "Not enabled yet: Tap Step 1 below to activate"
                statusLabel.setTextColor(Color.parseColor("#DC2626"))
            }
        }
    }

    private fun createCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(16), d(16), d(16), d(16))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = d(14).toFloat()
                setStroke(d(1), Color.parseColor("#E2E8F0"))
            }
        }
    }

    private fun sectionHeader(text: String): TextView {
        return TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.parseColor("#0F172A"))
            setPadding(0, 0, 0, d(10))
        }
    }

    private fun createPrimaryButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2563EB"))
                cornerRadius = d(10).toFloat()
            }
            setOnClickListener { onClick() }
        }
    }

    private fun createSecondaryButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.parseColor("#0F172A"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F1F5F9"))
                cornerRadius = d(10).toFloat()
                setStroke(d(1), Color.parseColor("#CBD5E1"))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun createToggleRow(label: String, initial: Boolean, onChange: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, d(8), 0, d(8))
        }
        val tv = TextView(this).apply {
            text = label
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#1E293B"))
        }
        val sw = Switch(this).apply {
            isChecked = initial
            setOnCheckedChangeListener { _, checked -> onChange(checked) }
        }
        row.addView(tv)
        row.addView(sw)
        return row
    }

    private fun createOptionCycleRow(label: String, current: () -> String, onCycle: () -> String): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, d(8), 0, d(8))
        }
        val tv = TextView(this).apply {
            text = label
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(Color.parseColor("#1E293B"))
        }
        val btn = Button(this).apply {
            text = current()
            isAllCaps = false
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(Color.parseColor("#2563EB"))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#EFF6FF"))
                cornerRadius = d(8).toFloat()
            }
            setPadding(d(12), d(6), d(12), d(6))
            setOnClickListener {
                text = onCycle()
            }
        }
        row.addView(tv)
        row.addView(btn)
        return row
    }

    private fun spacer(heightDp: Int): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, d(heightDp))
        }
    }
}
