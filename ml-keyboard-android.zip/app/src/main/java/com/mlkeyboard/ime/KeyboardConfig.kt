package com.mlkeyboard.ime

import android.content.Context
import android.content.SharedPreferences

enum class KeyboardTheme { LIGHT, DARK, OLED }

enum class KeyHeightPreset(val rowHeightDp: Float) {
    COMPACT(44f),
    STANDARD(50f),
    TALL(56f)
}

data class KeyboardConfig(
    val theme: KeyboardTheme = KeyboardTheme.DARK,
    val keyHeight: KeyHeightPreset = KeyHeightPreset.STANDARD,
    val numberRow: Boolean = false,
    val soundOnKeypress: Boolean = true,
    val hapticFeedback: Boolean = true,
    val keypressPopup: Boolean = true,
    val autoCapitalize: Boolean = true,
    val doubleSpacePeriod: Boolean = true,
    val autoCorrect: Boolean = true
) {
    companion object {
        private const val PREFS_NAME = "ml_keyboard_prefs"
        private const val KEY_THEME = "theme"
        private const val KEY_HEIGHT = "key_height"
        private const val KEY_NUMBER_ROW = "number_row"
        private const val KEY_SOUND = "sound_on_keypress"
        private const val KEY_HAPTIC = "haptic_feedback"
        private const val KEY_POPUP = "keypress_popup"
        private const val KEY_AUTO_CAP = "auto_capitalize"
        private const val KEY_DOUBLE_SPACE = "double_space_period"
        private const val KEY_AUTO_CORRECT = "auto_correct"

        fun load(context: Context): KeyboardConfig {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val theme = runCatching {
                KeyboardTheme.valueOf(prefs.getString(KEY_THEME, KeyboardTheme.DARK.name) ?: KeyboardTheme.DARK.name)
            }.getOrDefault(KeyboardTheme.DARK)

            val height = runCatching {
                KeyHeightPreset.valueOf(prefs.getString(KEY_HEIGHT, KeyHeightPreset.STANDARD.name) ?: KeyHeightPreset.STANDARD.name)
            }.getOrDefault(KeyHeightPreset.STANDARD)

            return KeyboardConfig(
                theme = theme,
                keyHeight = height,
                numberRow = prefs.getBoolean(KEY_NUMBER_ROW, false),
                soundOnKeypress = prefs.getBoolean(KEY_SOUND, true),
                hapticFeedback = prefs.getBoolean(KEY_HAPTIC, true),
                keypressPopup = prefs.getBoolean(KEY_POPUP, true),
                autoCapitalize = prefs.getBoolean(KEY_AUTO_CAP, true),
                doubleSpacePeriod = prefs.getBoolean(KEY_DOUBLE_SPACE, true),
                autoCorrect = prefs.getBoolean(KEY_AUTO_CORRECT, true)
            )
        }

        fun save(context: Context, config: KeyboardConfig) {
            val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(KEY_THEME, config.theme.name)
                .putString(KEY_HEIGHT, config.keyHeight.name)
                .putBoolean(KEY_NUMBER_ROW, config.numberRow)
                .putBoolean(KEY_SOUND, config.soundOnKeypress)
                .putBoolean(KEY_HAPTIC, config.hapticFeedback)
                .putBoolean(KEY_POPUP, config.keypressPopup)
                .putBoolean(KEY_AUTO_CAP, config.autoCapitalize)
                .putBoolean(KEY_DOUBLE_SPACE, config.doubleSpacePeriod)
                .putBoolean(KEY_AUTO_CORRECT, config.autoCorrect)
                .apply()
        }
    }
}
