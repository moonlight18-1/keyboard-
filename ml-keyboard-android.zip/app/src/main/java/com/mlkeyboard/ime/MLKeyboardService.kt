package com.mlkeyboard.ime

import android.content.Context
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

class MLKeyboardService : InputMethodService(), MLKeyboardView.Listener {

    private lateinit var rootLayout: LinearLayout
    private lateinit var suggestionBar: LinearLayout
    private lateinit var keyboardView: MLKeyboardView
    private val suggestionViews = ArrayList<TextView>(3)

    private var config: KeyboardConfig = KeyboardConfig()
    private var shiftState: MLKeyboardView.ShiftState = MLKeyboardView.ShiftState.ONCE
    private var currentLayer: MLKeyboardView.Layer = MLKeyboardView.Layer.LETTERS
    private var lastSpaceMs: Long = 0L

    private var audioManager: AudioManager? = null
    private var vibrator: Vibrator? = null

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    override fun onCreateInputView(): View {
        config = KeyboardConfig.load(this)
        val density = resources.displayMetrics.density

        rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        suggestionBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                (38f * density).toInt()
            )
        }

        suggestionViews.clear()
        for (i in 0 until 3) {
            val tv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                isSingleLine = true
                ellipsize = TextUtils.TruncateAt.END
                setOnClickListener {
                    val chosen = text?.toString()?.trim().orEmpty()
                    if (chosen.isNotEmpty()) {
                        commitSuggestion(chosen)
                    }
                }
            }
            suggestionViews.add(tv)
            suggestionBar.addView(tv)
        }

        keyboardView = MLKeyboardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            listener = this@MLKeyboardService
            updateConfig(config)
            setShiftState(shiftState)
        }

        rootLayout.addView(suggestionBar)
        rootLayout.addView(keyboardView)
        applySuggestionBarTheme()
        refreshSuggestions()

        return rootLayout
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        config = KeyboardConfig.load(this)
        if (::keyboardView.isInitialized) {
            keyboardView.updateConfig(config)
            applySuggestionBarTheme()
            currentLayer = MLKeyboardView.Layer.LETTERS
            keyboardView.setLayer(currentLayer)
            updateAutoShift()
            refreshSuggestions()
        }
    }

    private fun applySuggestionBarTheme() {
        val barBg: Int
        val textColor: Int
        when (config.theme) {
            KeyboardTheme.LIGHT -> {
                barBg = Color.parseColor("#E2E8F0")
                textColor = Color.parseColor("#0F172A")
            }
            KeyboardTheme.DARK -> {
                barBg = Color.parseColor("#0F172A")
                textColor = Color.parseColor("#E2E8F0")
            }
            KeyboardTheme.OLED -> {
                barBg = Color.BLACK
                textColor = Color.WHITE
            }
        }
        suggestionBar.setBackgroundColor(barBg)
        suggestionViews.forEachIndexed { index, tv ->
            tv.setTextColor(if (index == 0) Color.parseColor("#60A5FA").takeIf { config.theme != KeyboardTheme.LIGHT } ?: Color.parseColor("#2563EB") else textColor)
        }
    }

    private fun currentWordPrefix(): String {
        val ic = currentInputConnection ?: return ""
        val before = ic.getTextBeforeCursor(32, 0)?.toString() ?: return ""
        var idx = before.length
        while (idx > 0 && (before[idx - 1].isLetter() || before[idx - 1] == '\'')) {
            idx--
        }
        return before.substring(idx)
    }

    private fun refreshSuggestions() {
        val prefix = currentWordPrefix()
        val suggestions = EnglishDictionary.getSuggestions(prefix, 3)
        for (i in 0 until 3) {
            suggestionViews[i].text = suggestions.getOrElse(i) { "" }
        }
    }

    private fun commitSuggestion(word: String) {
        val ic = currentInputConnection ?: return
        val prefix = currentWordPrefix()
        if (prefix.isNotEmpty()) {
            ic.deleteSurroundingText(prefix.length, 0)
        }
        ic.commitText("$word ", 1)
        lastSpaceMs = 0L
        updateAutoShift()
        refreshSuggestions()
    }

    override fun onKeyChar(char: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(char, 1)
        lastSpaceMs = 0L

        if (shiftState == MLKeyboardView.ShiftState.ONCE && char.length == 1 && char[0].isLetter()) {
            shiftState = MLKeyboardView.ShiftState.OFF
            keyboardView.setShiftState(shiftState)
        } else {
            updateAutoShift()
        }
        refreshSuggestions()
    }

    override fun onSpace() {
        val ic = currentInputConnection ?: return
        val now = System.currentTimeMillis()
        val before = ic.getTextBeforeCursor(2, 0)?.toString().orEmpty()

        if (config.doubleSpacePeriod &&
            now - lastSpaceMs <= 420L &&
            before.length == 2 &&
            before[1] == ' ' &&
            before[0].isLetterOrDigit()
        ) {
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
            lastSpaceMs = 0L
            updateAutoShift()
            refreshSuggestions()
            return
        }

        if (config.autoCorrect) {
            val prefix = currentWordPrefix()
            val fixed = EnglishDictionary.getAutoCorrect(prefix)
            if (fixed != null && fixed != prefix) {
                ic.deleteSurroundingText(prefix.length, 0)
                ic.commitText(fixed, 1)
            }
        }

        ic.commitText(" ", 1)
        lastSpaceMs = now
        updateAutoShift()
        refreshSuggestions()
    }

    override fun onDelete() {
        val ic = currentInputConnection ?: return
        val selected = ic.getSelectedText(0)
        if (!selected.isNullOrEmpty()) {
            ic.commitText("", 1)
        } else {
            ic.deleteSurroundingText(1, 0)
        }
        lastSpaceMs = 0L
        updateAutoShift()
        refreshSuggestions()
    }

    override fun onEnter() {
        val ic = currentInputConnection ?: return
        val editorInfo = currentInputEditorInfo
        val imeAction = editorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        val isMultiLine = (editorInfo?.inputType ?: 0) and InputType.TYPE_TEXT_FLAG_MULTI_LINE != 0

        if (!isMultiLine && imeAction != EditorInfo.IME_ACTION_NONE && imeAction != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(imeAction)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
        lastSpaceMs = 0L
        updateAutoShift()
        refreshSuggestions()
    }

    override fun onShiftToggle() {
        shiftState = when (shiftState) {
            MLKeyboardView.ShiftState.OFF -> MLKeyboardView.ShiftState.ONCE
            MLKeyboardView.ShiftState.ONCE -> MLKeyboardView.ShiftState.CAPS
            MLKeyboardView.ShiftState.CAPS -> MLKeyboardView.ShiftState.OFF
        }
        keyboardView.setShiftState(shiftState)
    }

    override fun onSwitchLayer(layer: MLKeyboardView.Layer) {
        currentLayer = layer
        keyboardView.setLayer(layer)
    }

    override fun onKeyTapFeedback(isActionKey: Boolean) {
        if (config.soundOnKeypress) {
            val effect = if (isActionKey) AudioManager.FX_KEYPRESS_SPACEBAR else AudioManager.FX_KEYPRESS_STANDARD
            audioManager?.playSoundEffect(effect, -1f)
        }
        if (config.hapticFeedback) {
            if (::keyboardView.isInitialized) {
                keyboardView.performHapticFeedback(
                    HapticFeedbackConstants.KEYBOARD_TAP,
                    HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(12L, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        }
    }

    private fun updateAutoShift() {
        if (shiftState == MLKeyboardView.ShiftState.CAPS) return
        if (!config.autoCapitalize) {
            if (shiftState != MLKeyboardView.ShiftState.OFF) {
                shiftState = MLKeyboardView.ShiftState.OFF
                keyboardView.setShiftState(shiftState)
            }
            return
        }

        val ic = currentInputConnection
        val editorInfo = currentInputEditorInfo
        val capsMode = if (ic != null && editorInfo != null) {
            ic.getCursorCapsMode(editorInfo.inputType or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        } else {
            0
        }

        val nextShift = if (capsMode != 0) MLKeyboardView.ShiftState.ONCE else MLKeyboardView.ShiftState.OFF
        if (shiftState != nextShift) {
            shiftState = nextShift
            keyboardView.setShiftState(shiftState)
        }
    }
}
