package com.mlkeyboard.ime

import java.util.Locale

object EnglishDictionary {
    private val words: Array<String> = arrayOf(
        "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not", "on", "with", "he", "as", "you", "do", "at", "this", "but", "his", "by", "from", "they", "we", "say", "her", "she", "or", "an", "will", "my", "one", "all", "would", "there", "their", "what", "so", "up", "out", "if", "about", "who", "get", "which", "go", "me", "when", "make", "can", "like", "time", "no", "just", "him", "know", "take", "people", "into", "year", "your", "good", "some", "could", "them", "see", "other", "than", "then", "now", "look", "only", "come", "its", "over", "think", "also", "back", "after", "use", "two", "how", "our", "work", "first", "well", "way", "even", "new", "want", "because", "any", "these", "give", "day", "most", "us", "hello", "hey", "hi", "thanks", "thank", "please", "sorry", "yes", "yeah", "okay", "ok", "sure", "great", "awesome", "nice", "cool", "fine", "today", "tomorrow", "tonight", "morning", "afternoon", "evening", "night", "week", "month", "right", "left", "here", "where", "why", "how", "much", "many", "more", "very", "really", "actually", "probably", "maybe", "always", "never", "sometimes", "often", "already", "still", "yet", "soon", "need", "help", "call", "text", "message", "send", "sent", "read", "write", "type", "typing", "fast", "quick", "quickly", "keyboard", "phone", "android", "app", "screen", "home", "office", "school", "meeting", "lunch", "dinner", "coffee", "water", "food", "love", "miss", "hope", "feel", "feeling", "happy", "tired", "busy", "ready", "done", "start", "stop", "open", "close", "check", "update", "download", "upload", "build", "file", "code", "project", "github", "release", "version", "install", "settings", "enable", "change", "switch", "default", "system", "language", "english", "word", "words", "sentence", "letter", "letters", "space", "enter", "delete", "shift", "number", "symbol", "theme", "light", "dark", "black", "clean", "sharp", "smooth", "instant", "zero", "latency", "friend", "friends", "family", "team", "everyone", "someone", "anyone", "everything", "nothing", "something", "anything", "before", "during", "while", "since", "until", "though", "should", "must", "might", "may", "being", "been", "were", "was", "are", "is", "am", "had", "has", "having", "did", "does", "doing", "made", "making", "going", "goes", "went", "gone", "got", "getting", "gotten", "see", "seeing", "saw", "seen", "find", "found", "tell", "told", "ask", "asked", "try", "tried", "trying", "keep", "kept", "let", "put", "mean", "means", "meant", "leave", "left", "seem", "seems", "talk", "talking", "turn", "show", "play", "run", "running", "move", "live", "believe", "hold", "bring", "happen", "must", "provide", "sit", "stand", "lose", "pay", "meet", "include", "continue", "set", "learn", "lead", "understand", "watch", "follow", "create", "speak", "allow", "add", "spend", "grow", "walk", "win", "offer", "remember", "consider", "appear", "buy", "wait", "serve", "die", "stay", "fall", "cut", "reach", "remain", "suggest", "raise", "pass", "sell", "require", "report", "decide", "pull", "better", "best", "worse", "worst", "important", "different", "possible", "available", "clear", "easy", "hard", "simple", "special", "local", "late", "early", "high", "low", "long", "short", "large", "small", "next", "last", "same", "able", "real", "full", "free", "true", "false", "wrong", "email", "link", "photo", "video", "music", "sound", "volume", "battery", "wifi", "data", "minute", "minutes", "hour", "hours", "second", "seconds", "place", "world", "life", "hand", "part", "child", "eye", "woman", "man", "case", "point", "company", "group", "problem", "fact", "question", "answer", "idea", "reason", "story", "plan", "list", "note", "notes", "book", "page", "line", "name", "address", "password", "account", "welcome", "congrats", "cheers", "enjoy", "sounds", "looks", "works", "working", "I'm", "I've", "I'll", "I'd", "don't", "can't", "won't", "it's", "that's", "what's", "you're", "we're", "they're", "isn't", "aren't", "wasn't", "weren't", "haven't", "hasn't", "didn't", "doesn't", "wouldn't", "couldn't", "shouldn't", "let's", "there's", "here's"
    )

    private val wordSet: HashSet<String> = HashSet<String>(words.size).apply {
        for (w in words) add(w.lowercase(Locale.US))
    }

    private val commonTypos: Map<String, String> = mapOf(
        "teh" to "the",
        "adn" to "and",
        "taht" to "that",
        "waht" to "what",
        "wiht" to "with",
        "jsut" to "just",
        "becuase" to "because",
        "beacuse" to "because",
        "thier" to "their",
        "recieve" to "receive",
        "seperate" to "separate",
        "definately" to "definitely",
        "acheive" to "achieve",
        "occured" to "occurred",
        "untill" to "until",
        "langauge" to "language",
        "keybaord" to "keyboard",
        "keyborad" to "keyboard",
        "im" to "I'm",
        "ive" to "I've",
        "ill" to "I'll",
        "dont" to "don't",
        "cant" to "can't",
        "wont" to "won't",
        "didnt" to "didn't",
        "doesnt" to "doesn't",
        "isnt" to "isn't",
        "arent" to "aren't",
        "wasnt" to "wasn't",
        "wouldnt" to "wouldn't",
        "couldnt" to "couldn't",
        "shouldnt" to "shouldn't",
        "youre" to "you're",
        "theyre" to "they're",
        "thats" to "that's",
        "whats" to "what's",
        "hes" to "he's",
        "shes" to "she's",
        "lets" to "let's",
        "hellp" to "hello",
        "helo" to "hello",
        "thnaks" to "thanks",
        "thx" to "thanks",
        "pls" to "please",
        "plz" to "please",
        "tommorow" to "tomorrow",
        "tomorow" to "tomorrow",
        "realy" to "really",
        "truely" to "truly",
        "wierd" to "weird",
        "freind" to "friend",
        "alwyas" to "always",
        "probaly" to "probably",
        "probly" to "probably",
        "mesage" to "message",
        "andorid" to "android",
        "gihub" to "github",
        "quikc" to "quick",
        "fats" to "fast",
        "i" to "I"
    )

    fun getAutoCorrect(word: String): String? {
        if (word.isEmpty()) return null
        val lower = word.lowercase(Locale.US)
        val mapped = commonTypos[lower] ?: return null
        return matchCasing(word, mapped)
    }

    fun getSuggestions(prefix: String, limit: Int = 3): List<String> {
        if (prefix.isEmpty()) {
            return listOf("I", "The", "Hello").take(limit)
        }

        val lower = prefix.lowercase(Locale.US)
        val result = ArrayList<String>(limit)
        val seen = HashSet<String>(limit * 2)

        fun pushUnique(candidate: String) {
            val formatted = matchCasing(prefix, candidate)
            val key = formatted.lowercase(Locale.US)
            if (seen.add(key)) {
                result.add(formatted)
            }
        }

        commonTypos[lower]?.let { pushUnique(it) }

        if (wordSet.contains(lower)) {
            val exact = words.firstOrNull { it.equals(lower, ignoreCase = true) } ?: prefix
            pushUnique(exact)
        }

        for (word in words) {
            if (result.size >= limit) break
            if (word.lowercase(Locale.US).startsWith(lower)) {
                pushUnique(word)
            }
        }

        if (result.size < limit) {
            pushUnique(prefix)
        }

        return result.take(limit)
    }

    private fun matchCasing(template: String, candidate: String): String {
        if (template.isEmpty()) return candidate
        if (candidate.startsWith("I'")) return candidate
        if (candidate == "I") return "I"
        if (template.length > 1 && template == template.uppercase(Locale.US)) {
            return candidate.uppercase(Locale.US)
        }
        val first = template[0]
        if (first.isUpperCase()) {
            return candidate.replaceFirstChar {
                if (it.isLowerCase()) it.titlecase(Locale.US) else it.toString()
            }
        }
        return candidate
    }
}
