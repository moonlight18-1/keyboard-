package com.mlkeyboard.ime

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.util.SparseArray
import android.view.MotionEvent
import android.view.View

class MLKeyboardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onKeyChar(char: String)
        fun onDelete()
        fun onSpace()
        fun onEnter()
        fun onShiftToggle()
        fun onSwitchLayer(layer: Layer)
        fun onKeyTapFeedback(isActionKey: Boolean)
    }

    enum class Layer { LETTERS, SYMBOLS_1, SYMBOLS_2 }
    enum class ShiftState { OFF, ONCE, CAPS }

    private enum class KeyKind {
        CHAR, SHIFT, DELETE, LAYER_SYMBOLS_1, LAYER_SYMBOLS_2, LAYER_LETTERS, SPACE, ENTER
    }

    private data class KeyDef(
        val label: String,
        val output: String,
        val kind: KeyKind,
        val weight: Float = 1f,
        val isAccent: Boolean = false,
        val isSpecial: Boolean = false
    )

    private data class KeyRect(
        val def: KeyDef,
        val rect: RectF
    )

    var listener: Listener? = null
    private var config: KeyboardConfig = KeyboardConfig()
    private var currentLayer: Layer = Layer.LETTERS
    private var shiftState: ShiftState = ShiftState.ONCE

    private val density = resources.displayMetrics.density
    private val keyRects = ArrayList<KeyRect>(48)
    private val activePointers = SparseArray<KeyRect>()
    private var lastHighlightedKey: KeyRect? = null

    private val handler = Handler(Looper.getMainLooper())
    private var isRepeatingDelete = false
    private val deleteRepeatRunnable = object : Runnable {
        override fun run() {
            if (isRepeatingDelete) {
                listener?.onDelete()
                listener?.onKeyTapFeedback(true)
                handler.postDelayed(this, 45L)
            }
        }
    }

    // Pre-allocated Paints to guarantee zero GC allocations during onDraw()
    private val bgPaint = Paint()
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val specialKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val accentKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressedKeyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
    }
    private val specialLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val popupPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val popupTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val popupRect = RectF()

    private var colorBg = 0xFF0F172A.toInt()
    private var colorKey = 0xFF334155.toInt()
    private var colorSpecialKey = 0xFF1E293B.toInt()
    private var colorAccentKey = 0xFF2563EB.toInt()
    private var colorPressed = 0xFF475569.toInt()
    private var colorShadow = 0x40000000
    private var colorText = 0xFFF8FAFC.toInt()
    private var colorAccentText = 0xFFFFFFFF.toInt()

    init {
        isClickable = true
        applyThemeColors()
    }

    fun updateConfig(newConfig: KeyboardConfig) {
        if (config != newConfig) {
            config = newConfig
            applyThemeColors()
            rebuildLayout(width, height)
            requestLayout()
            invalidate()
        }
    }

    fun setShiftState(state: ShiftState) {
        if (shiftState != state) {
            shiftState = state
            invalidate()
        }
    }

    fun setLayer(layer: Layer) {
        if (currentLayer != layer) {
            currentLayer = layer
            rebuildLayout(width, height)
            invalidate()
        }
    }

    private fun applyThemeColors() {
        when (config.theme) {
            KeyboardTheme.LIGHT -> {
                colorBg = 0xFFE2E8F0.toInt()
                colorKey = 0xFFFFFFFF.toInt()
                colorSpecialKey = 0xFFCBD5E1.toInt()
                colorAccentKey = 0xFF2563EB.toInt()
                colorPressed = 0xFFDBEAFE.toInt()
                colorShadow = 0x260F172A
                colorText = 0xFF0F172A.toInt()
                colorAccentText = 0xFFFFFFFF.toInt()
            }
            KeyboardTheme.DARK -> {
                colorBg = 0xFF0F172A.toInt()
                colorKey = 0xFF334155.toInt()
                colorSpecialKey = 0xFF1E293B.toInt()
                colorAccentKey = 0xFF2563EB.toInt()
                colorPressed = 0xFF475569.toInt()
                colorShadow = 0x55000000
                colorText = 0xFFF8FAFC.toInt()
                colorAccentText = 0xFFFFFFFF.toInt()
            }
            KeyboardTheme.OLED -> {
                colorBg = 0xFF000000.toInt()
                colorKey = 0xFF1A1A1A.toInt()
                colorSpecialKey = 0xFF0F0F0F.toInt()
                colorAccentKey = 0xFF2563EB.toInt()
                colorPressed = 0xFF2E2E2E.toInt()
                colorShadow = 0x00000000
                colorText = 0xFFFFFFFF.toInt()
                colorAccentText = 0xFFFFFFFF.toInt()
            }
        }
        bgPaint.color = colorBg
        keyPaint.color = colorKey
        specialKeyPaint.color = colorSpecialKey
        accentKeyPaint.color = colorAccentKey
        pressedKeyPaint.color = colorPressed
        shadowPaint.color = colorShadow
        labelPaint.color = colorText
        specialLabelPaint.color = colorText
        popupPaint.color = colorAccentKey
        popupTextPaint.color = colorAccentText
    }

    private fun rowCount(): Int = if (config.numberRow) 5 else 4

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val width = MeasureSpec.getSize(widthMeasureSpec)
        val rowHeightPx = (config.keyHeight.rowHeightDp * density).toInt()
        val gapPx = (6f * density).toInt()
        val verticalPadPx = (14f * density).toInt()
        val rows = rowCount()
        val totalHeight = rows * rowHeightPx + (rows - 1) * gapPx + verticalPadPx
        setMeasuredDimension(width, totalHeight)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildLayout(w, h)
    }

    private fun buildRows(): List<List<KeyDef>> {
        val rows = ArrayList<List<KeyDef>>(5)
        if (config.numberRow) {
            rows.add(listOf("1","2","3","4","5","6","7","8","9","0").map {
                KeyDef(it, it, KeyKind.CHAR)
            })
        }

        when (currentLayer) {
            Layer.LETTERS -> {
                rows.add(listOf("q","w","e","r","t","y","u","i","o","p").map {
                    KeyDef(it, it, KeyKind.CHAR)
                })
                rows.add(listOf("a","s","d","f","g","h","j","k","l").map {
                    KeyDef(it, it, KeyKind.CHAR)
                })
                val row3 = ArrayList<KeyDef>(9)
                row3.add(KeyDef("SHIFT", "", KeyKind.SHIFT, 1.45f, isSpecial = true))
                listOf("z","x","c","v","b","n","m").forEach {
                    row3.add(KeyDef(it, it, KeyKind.CHAR))
                }
                row3.add(KeyDef("DEL", "", KeyKind.DELETE, 1.45f, isSpecial = true))
                rows.add(row3)

                rows.add(listOf(
                    KeyDef("?123", "", KeyKind.LAYER_SYMBOLS_1, 1.4f, isSpecial = true),
                    KeyDef(",", ",", KeyKind.CHAR, 0.9f, isSpecial = true),
                    KeyDef("English", " ", KeyKind.SPACE, 4.6f),
                    KeyDef(".", ".", KeyKind.CHAR, 0.9f, isSpecial = true),
                    KeyDef("↵", "", KeyKind.ENTER, 1.6f, isAccent = true)
                ))
            }
            Layer.SYMBOLS_1 -> {
                rows.add(listOf("@","#","$","_","&","-","+","(",")","/").map {
                    KeyDef(it, it, KeyKind.CHAR)
                })
                rows.add(listOf("*","\"","'",":",";","!","?","%","=").map {
                    KeyDef(it, it, KeyKind.CHAR)
                })
                val row3 = ArrayList<KeyDef>(9)
                row3.add(KeyDef("=\\<", "", KeyKind.LAYER_SYMBOLS_2, 1.45f, isSpecial = true))
                listOf("~","`","|","^","[","]","\\").forEach {
                    row3.add(KeyDef(it, it, KeyKind.CHAR))
                }
                row3.add(KeyDef("DEL", "", KeyKind.DELETE, 1.45f, isSpecial = true))
                rows.add(row3)

                rows.add(listOf(
                    KeyDef("ABC", "", KeyKind.LAYER_LETTERS, 1.4f, isSpecial = true),
                    KeyDef(",", ",", KeyKind.CHAR, 0.9f, isSpecial = true),
                    KeyDef("Space", " ", KeyKind.SPACE, 4.6f),
                    KeyDef(".", ".", KeyKind.CHAR, 0.9f, isSpecial = true),
                    KeyDef("↵", "", KeyKind.ENTER, 1.6f, isAccent = true)
                ))
            }
            Layer.SYMBOLS_2 -> {
                rows.add(listOf("€","£","¥","¢","°","•","○","●","□","■").map {
                    KeyDef(it, it, KeyKind.CHAR)
                })
                rows.add(listOf("{","}","<",">","©","®","™","§","¶").map {
                    KeyDef(it, it, KeyKind.CHAR)
                })
                val row3 = ArrayList<KeyDef>(9)
                row3.add(KeyDef("?123", "", KeyKind.LAYER_SYMBOLS_1, 1.45f, isSpecial = true))
                listOf("¡","¿","«","»","÷","×","±").forEach {
                    row3.add(KeyDef(it, it, KeyKind.CHAR))
                }
                row3.add(KeyDef("DEL", "", KeyKind.DELETE, 1.45f, isSpecial = true))
                rows.add(row3)

                rows.add(listOf(
                    KeyDef("ABC", "", KeyKind.LAYER_LETTERS, 1.4f, isSpecial = true),
                    KeyDef(",", ",", KeyKind.CHAR, 0.9f, isSpecial = true),
                    KeyDef("Space", " ", KeyKind.SPACE, 4.6f),
                    KeyDef(".", ".", KeyKind.CHAR, 0.9f, isSpecial = true),
                    KeyDef("↵", "", KeyKind.ENTER, 1.6f, isAccent = true)
                ))
            }
        }
        return rows
    }

    private fun rebuildLayout(viewWidth: Int, viewHeight: Int) {
        keyRects.clear()
        if (viewWidth <= 0 || viewHeight <= 0) return

        val rows = buildRows()
        val hPad = 5f * density
        val vPadTop = 6f * density
        val vPadBottom = 8f * density
        val keyGapX = 4.5f * density
        val rowGapY = 6f * density

        val usableHeight = viewHeight - vPadTop - vPadBottom - (rows.size - 1) * rowGapY
        val rowHeight = usableHeight / rows.size.toFloat()

        rows.forEachIndexed { rowIndex, row ->
            val top = vPadTop + rowIndex * (rowHeight + rowGapY)
            val bottom = top + rowHeight
            val totalWeight = row.fold(0f) { acc, k -> acc + k.weight }
            val isNineLetterRow = currentLayer == Layer.LETTERS && row.size == 9
            val extraSidePad = if (isNineLetterRow) (viewWidth * 0.045f) else 0f
            val availableWidth = viewWidth - (hPad * 2) - (extraSidePad * 2) - ((row.size - 1) * keyGapX)

            var cursorX = hPad + extraSidePad
            row.forEach { keyDef ->
                val keyW = availableWidth * (keyDef.weight / totalWeight)
                val rect = RectF(cursorX, top, cursorX + keyW, bottom)
                keyRects.add(KeyRect(keyDef, rect))
                cursorX += keyW + keyGapX
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val cornerRadius = 7f * density
        val shadowOffset = 1.5f * density
        labelPaint.textSize = 20f * density
        specialLabelPaint.textSize = 14f * density
        popupTextPaint.textSize = 24f * density

        for (i in 0 until keyRects.size) {
            val item = keyRects[i]
            val rect = item.rect
            val isPressed = isKeyPressed(item)

            if (!isPressed && config.theme != KeyboardTheme.OLED) {
                canvas.drawRoundRect(
                    rect.left,
                    rect.top + shadowOffset,
                    rect.right,
                    rect.bottom + shadowOffset,
                    cornerRadius,
                    cornerRadius,
                    shadowPaint
                )
            }

            val fillPaint = when {
                item.def.isAccent -> accentKeyPaint
                isPressed -> pressedKeyPaint
                item.def.kind == KeyKind.SHIFT && shiftState != ShiftState.OFF -> pressedKeyPaint
                item.def.isSpecial -> specialKeyPaint
                else -> keyPaint
            }

            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, fillPaint)

            val displayText = when (item.def.kind) {
                KeyKind.CHAR -> if (currentLayer == Layer.LETTERS && shiftState != ShiftState.OFF && item.def.label.length == 1 && item.def.label[0].isLetter()) {
                    item.def.label.uppercase()
                } else {
                    item.def.label
                }
                KeyKind.SHIFT -> when (shiftState) {
                    ShiftState.OFF -> "⇧"
                    ShiftState.ONCE -> "⬆"
                    ShiftState.CAPS -> "⇪"
                }
                KeyKind.DELETE -> "⌫"
                else -> item.def.label
            }

            val paintToUse = if (item.def.isAccent) {
                specialLabelPaint.apply { color = colorAccentText }
            } else if (item.def.isSpecial || item.def.kind == KeyKind.SPACE) {
                specialLabelPaint.apply { color = colorText }
            } else {
                labelPaint
            }

            val textY = rect.centerY() - ((paintToUse.descent() + paintToUse.ascent()) / 2f)
            canvas.drawText(displayText, rect.centerX(), textY, paintToUse)
        }

        // Draw crisp keypress preview popup for non-special character keys
        if (config.keypressPopup) {
            val active = lastHighlightedKey
            if (active != null && active.def.kind == KeyKind.CHAR) {
                val r = active.rect
                val popupW = r.width() * 1.28f
                val popupH = r.height() * 1.1f
                val left = (r.centerX() - popupW / 2f).coerceIn(4f * density, width - popupW - 4f * density)
                val top = (r.top - popupH - 6f * density).coerceAtLeast(2f * density)
                popupRect.set(left, top, left + popupW, top + popupH)
                canvas.drawRoundRect(popupRect, 9f * density, 9f * density, popupPaint)

                val ch = if (currentLayer == Layer.LETTERS && shiftState != ShiftState.OFF) {
                    active.def.label.uppercase()
                } else {
                    active.def.label
                }
                val textY = popupRect.centerY() - ((popupTextPaint.descent() + popupTextPaint.ascent()) / 2f)
                canvas.drawText(ch, popupRect.centerX(), textY, popupTextPaint)
            }
        }
    }

    private fun isKeyPressed(target: KeyRect): Boolean {
        for (i in 0 until activePointers.size()) {
            if (activePointers.valueAt(i) === target) return true
        }
        return false
    }

    private fun findKeyAt(x: Float, y: Float): KeyRect? {
        for (i in 0 until keyRects.size) {
            if (keyRects[i].rect.contains(x, y)) return keyRects[i]
        }
        // Nearest key fallback within vertical band to eliminate missed edge taps
        var best: KeyRect? = null
        var bestDist = Float.MAX_VALUE
        for (i in 0 until keyRects.size) {
            val r = keyRects[i].rect
            if (y >= r.top - 6f * density && y <= r.bottom + 6f * density) {
                val dx = when {
                    x < r.left -> r.left - x
                    x > r.right -> x - r.right
                    else -> 0f
                }
                if (dx < bestDist && dx < 16f * density) {
                    bestDist = dx
                    best = keyRects[i]
                }
            }
        }
        return best
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val action = event.actionMasked
        val index = event.actionIndex
        val pointerId = event.getPointerId(index)

        when (action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val hit = findKeyAt(event.getX(index), event.getY(index))
                if (hit != null) {
                    activePointers.put(pointerId, hit)
                    lastHighlightedKey = hit
                    listener?.onKeyTapFeedback(hit.def.isSpecial || hit.def.isAccent || hit.def.kind == KeyKind.SPACE)
                    if (hit.def.kind == KeyKind.DELETE) {
                        listener?.onDelete()
                        isRepeatingDelete = true
                        handler.removeCallbacks(deleteRepeatRunnable)
                        handler.postDelayed(deleteRepeatRunnable, 340L)
                    }
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val id = event.getPointerId(i)
                    val prev = activePointers.get(id)
                    val hit = findKeyAt(event.getX(i), event.getY(i))
                    if (hit != null && hit !== prev) {
                        activePointers.put(id, hit)
                        if (prev?.def?.kind == KeyKind.DELETE && hit.def.kind != KeyKind.DELETE) {
                            stopDeleteRepeat()
                        }
                        lastHighlightedKey = hit
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val hit = activePointers.get(pointerId)
                activePointers.remove(pointerId)
                if (activePointers.size() == 0) {
                    lastHighlightedKey = null
                }
                stopDeleteRepeat()
                if (hit != null && hit.def.kind != KeyKind.DELETE) {
                    dispatchKey(hit.def)
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                activePointers.clear()
                lastHighlightedKey = null
                stopDeleteRepeat()
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun stopDeleteRepeat() {
        isRepeatingDelete = false
        handler.removeCallbacks(deleteRepeatRunnable)
    }

    private fun dispatchKey(def: KeyDef) {
        when (def.kind) {
            KeyKind.CHAR -> {
                val out = if (currentLayer == Layer.LETTERS && shiftState != ShiftState.OFF) {
                    def.output.uppercase()
                } else {
                    def.output
                }
                listener?.onKeyChar(out)
            }
            KeyKind.SHIFT -> listener?.onShiftToggle()
            KeyKind.SPACE -> listener?.onSpace()
            KeyKind.ENTER -> listener?.onEnter()
            KeyKind.LAYER_SYMBOLS_1 -> listener?.onSwitchLayer(Layer.SYMBOLS_1)
            KeyKind.LAYER_SYMBOLS_2 -> listener?.onSwitchLayer(Layer.SYMBOLS_2)
            KeyKind.LAYER_LETTERS -> listener?.onSwitchLayer(Layer.LETTERS)
            KeyKind.DELETE -> Unit
        }
    }
}
