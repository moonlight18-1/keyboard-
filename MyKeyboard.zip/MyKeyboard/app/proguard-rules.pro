# Giữ nguyên tên lớp/hàm để đọc lỗi dễ hơn; R8 vẫn thu gọn và tối ưu mã.
-dontobfuscate
-keepattributes SourceFile,LineNumberTable
