Đặt các video có sẵn (.mp4) vào thư mục này, mỗi file sẽ hiện thành một nút trong
Keyboard -> Background -> Video -> "Built-in videos". Tên file chính là tên nút
(dấu gạch dưới _ được đổi thành dấu cách).
