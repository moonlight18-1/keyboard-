package com.example.mykeyboard

data class Release(
    val version: String,
    val date: String,
    val title: String,
    val notes: List<String>
)

/**
 * NHẬT KÝ CẬP NHẬT.
 * Mỗi lần có bản mới: thêm một mục MỚI Ở ĐẦU danh sách này,
 * đồng thời tăng versionCode + đổi versionName trong app/build.gradle.kts.
 */
object Changelog {
    val releases = listOf(
        Release(
            "1.2.0", "2026-11-20", "New look",
            listOf(
                "App renamed to ML Keyboard, with a new icon",
                "Redesigned home screen with setup status",
                "Added What's New and full update history",
                "Builds now use a fixed signing key, so future updates install over this one",
                "Smoother typing, sharper icons and a faster emoji panel"
            )
        ),
        Release(
            "1.1.0", "2026-11-20", "Emoji, haptics & sound",
            listOf(
                "Emoji panel with 8 categories and recent emoji",
                "Vibration on key press with adjustable strength",
                "Key click sounds with volume control",
                "Key popup bubble that shows the pressed letter",
                "Keyboard language changed to English"
            )
        ),
        Release(
            "1.0.0", "2026-11-20", "First release",
            listOf(
                "Dark theme with rounded keys",
                "Always-visible number row and symbols page",
                "Shift with double-tap Caps Lock and auto-capitalization",
                "Hold backspace to delete quickly"
            )
        )
    )
}
