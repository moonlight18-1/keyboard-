package com.example.mykeyboard

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Một mục trong bộ nhớ tạm. */
data class Clip(val text: String, val pinned: Boolean, val time: Long)

/** Lưu / đọc lịch sử bộ nhớ tạm (chỉ nằm trên máy này). */
object ClipStore {
    fun load(p: SharedPreferences): MutableList<Clip> {
        val out = mutableListOf<Clip>()
        try {
            val arr = JSONArray(p.getString(Prefs.CLIPS, "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Clip(o.getString("t"), o.optBoolean("p", false), o.optLong("d", 0L)))
            }
        } catch (e: Exception) {
            // dữ liệu hỏng thì bỏ qua, bắt đầu lại từ danh sách rỗng
        }
        return out
    }

    fun save(p: SharedPreferences, list: List<Clip>) {
        val arr = JSONArray()
        for (c in list) {
            arr.put(JSONObject().put("t", c.text).put("p", c.pinned).put("d", c.time))
        }
        p.edit().putString(Prefs.CLIPS, arr.toString()).apply()
    }

    fun clear(p: SharedPreferences) {
        p.edit().remove(Prefs.CLIPS).apply()
    }
}
