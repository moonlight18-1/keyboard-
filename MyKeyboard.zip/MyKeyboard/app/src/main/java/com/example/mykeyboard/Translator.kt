package com.example.mykeyboard

import android.text.Html
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException

/** 10 ngôn ngữ hỗ trợ dịch (mã, tên hiển thị bằng chính ngôn ngữ đó). */
object Langs {
    val all: List<Pair<String, String>> = listOf(
        "vi" to "Tiếng Việt",
        "en" to "English",
        "zh-CN" to "中文",
        "ja" to "日本語",
        "ko" to "한국어",
        "es" to "Español",
        "fr" to "Français",
        "de" to "Deutsch",
        "th" to "ไทย",
        "ru" to "Русский"
    )

    fun name(code: String): String =
        if (code == "auto") "Auto" else (all.firstOrNull { it.first == code }?.second ?: code)
}

class TranslateResult(val text: String?, val error: String?)

/**
 * Dịch qua dịch vụ trực tuyến miễn phí (cần mạng). Muốn đổi sang dịch vụ khác (ví dụ có khóa API
 * chính thức) thì chỉ cần sửa file này.
 */
object Translator {

    fun translate(text: String, from: String, to: String): TranslateResult {
        val src = text.trim()
        if (src.isEmpty()) return TranslateResult(null, "Nothing to translate")
        if (from == to) return TranslateResult(src, null)

        var error = "Couldn't translate. Please try again."
        try {
            val r = viaGoogle(src, from, to)
            if (!r.isNullOrBlank()) return TranslateResult(r, null)
        } catch (e: UnknownHostException) {
            error = "No internet connection"
        } catch (e: Exception) {
            // thử dịch vụ dự phòng bên dưới
        }
        if (from != "auto" && src.length <= 450) {
            try {
                val r = viaMyMemory(src, from, to)
                if (!r.isNullOrBlank()) return TranslateResult(r, null)
            } catch (e: UnknownHostException) {
                error = "No internet connection"
            } catch (e: Exception) {
                // hết cách
            }
        }
        return TranslateResult(null, error)
    }

    private fun get(url: String): String? {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 6000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            if (conn.responseCode != 200) null else conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn?.disconnect()
        }
    }

    private fun viaGoogle(q: String, from: String, to: String): String? {
        val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + from +
            "&tl=" + to + "&dt=t&q=" + URLEncoder.encode(q, "UTF-8")
        val body = get(url) ?: return null
        val arr = JSONArray(body).getJSONArray(0)
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val seg = arr.optJSONArray(i) ?: continue
            if (seg.isNull(0)) continue
            sb.append(seg.getString(0))
        }
        return sb.toString()
    }

    private fun viaMyMemory(q: String, from: String, to: String): String? {
        val url = "https://api.mymemory.translated.net/get?q=" + URLEncoder.encode(q, "UTF-8") +
            "&langpair=" + URLEncoder.encode(from + "|" + to, "UTF-8")
        val body = get(url) ?: return null
        val j = JSONObject(body)
        if (j.optInt("responseStatus", 0) != 200) return null
        val t = j.getJSONObject("responseData").optString("translatedText", "")
        return Html.fromHtml(t, Html.FROM_HTML_MODE_LEGACY).toString()
    }
}
