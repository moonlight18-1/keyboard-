package com.example.mykeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.Bundle
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Toast

/**
 * Khung cắt: ảnh nằm dưới, khung sáng là phần bàn phím sẽ hiển thị.
 * Kéo để di chuyển, chụm hai ngón để thu phóng; có lưới 1/3 giúp chọn bố cục đẹp.
 */
private class CropView(
    ctx: Context,
    private val bmp: Bitmap,
    private val aspect: Float,
    private val density: Float
) : View(ctx) {
    private val mx = Matrix()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint().apply { color = Color.argb(160, 0, 0, 0) }
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 2f * density
    }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(110, 255, 255, 255)
        strokeWidth = 1f * density
    }
    private val frame = RectF()
    private var scale = 1f
    private var tx = 0f
    private var ty = 0f
    private var minScale = 1f
    private val maxZoom = 5f
    private var placed = false
    var onZoomChanged: ((Float) -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomAt(scale * detector.scaleFactor, detector.focusX, detector.focusY)
            return true
        }
    })

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            tx -= distanceX
            ty -= distanceY
            clamp()
            invalidate()
            return true
        }
    })

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val margin = 14f * density
        var fw = w - 2 * margin
        var fh = fw / aspect
        if (fh > h - 2 * margin) {
            fh = h - 2 * margin
            fw = fh * aspect
        }
        frame.set((w - fw) / 2f, (h - fh) / 2f, (w + fw) / 2f, (h + fh) / 2f)
        minScale = maxOf(frame.width() / bmp.width, frame.height() / bmp.height)
        if (!placed) {
            placed = true
            reset()
        } else {
            scale = scale.coerceAtLeast(minScale)
            clamp()
        }
    }

    private fun clamp() {
        val bw = bmp.width * scale
        val bh = bmp.height * scale
        tx = maxOf(minOf(tx, frame.left), frame.right - bw)
        ty = maxOf(minOf(ty, frame.top), frame.bottom - bh)
    }

    private fun zoomAt(newScale: Float, fx: Float, fy: Float) {
        val s = newScale.coerceIn(minScale, minScale * maxZoom)
        val k = s / scale
        tx = fx - (fx - tx) * k
        ty = fy - (fy - ty) * k
        scale = s
        clamp()
        onZoomChanged?.invoke(zoomFraction())
        invalidate()
    }

    private fun zoomFraction(): Float = ((scale / minScale) - 1f) / (maxZoom - 1f)

    fun setZoomFraction(f: Float) {
        zoomAt(minScale * (1f + f.coerceIn(0f, 1f) * (maxZoom - 1f)), frame.centerX(), frame.centerY())
    }

    fun reset() {
        scale = minScale
        tx = frame.centerX() - bmp.width * scale / 2f
        ty = frame.centerY() - bmp.height * scale / 2f
        clamp()
        onZoomChanged?.invoke(0f)
        invalidate()
    }

    /** mode: 0 trái, 1 giữa, 2 phải */
    fun alignH(mode: Int) {
        tx = when (mode) {
            0 -> frame.left
            1 -> frame.centerX() - bmp.width * scale / 2f
            else -> frame.right - bmp.width * scale
        }
        clamp()
        invalidate()
    }

    /** mode: 0 trên, 1 giữa, 2 dưới */
    fun alignV(mode: Int) {
        ty = when (mode) {
            0 -> frame.top
            1 -> frame.centerY() - bmp.height * scale / 2f
            else -> frame.bottom - bmp.height * scale
        }
        clamp()
        invalidate()
    }

    /** Cắt đúng phần trong khung, xuất ra ảnh rộng outW. */
    fun render(outW: Int): Bitmap {
        val outH = (outW / aspect).toInt().coerceAtLeast(1)
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val l = ((frame.left - tx) / scale).toInt().coerceIn(0, bmp.width - 1)
        val t = ((frame.top - ty) / scale).toInt().coerceIn(0, bmp.height - 1)
        val r = ((frame.right - tx) / scale).toInt().coerceIn(l + 1, bmp.width)
        val b = ((frame.bottom - ty) / scale).toInt().coerceIn(t + 1, bmp.height)
        Canvas(out).drawBitmap(bmp, Rect(l, t, r, b), Rect(0, 0, outW, outH), paint)
        return out
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        mx.reset()
        mx.postScale(scale, scale)
        mx.postTranslate(tx, ty)
        canvas.drawBitmap(bmp, mx, paint)

        canvas.drawRect(0f, 0f, w, frame.top, shade)
        canvas.drawRect(0f, frame.bottom, w, h, shade)
        canvas.drawRect(0f, frame.top, frame.left, frame.bottom, shade)
        canvas.drawRect(frame.right, frame.top, w, frame.bottom, shade)

        for (i in 1..2) {
            val x = frame.left + frame.width() * i / 3f
            val y = frame.top + frame.height() * i / 3f
            canvas.drawLine(x, frame.top, x, frame.bottom, grid)
            canvas.drawLine(frame.left, y, frame.right, y, grid)
        }
        canvas.drawRect(frame, border)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        gestures.onTouchEvent(e)
        return true
    }
}

class CropActivity : BaseActivity() {

    private lateinit var crop: CropView
    private lateinit var zoomBar: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val src = ImageUtil.loadFile(BackgroundStore.srcFile(this).path, 2048)
        if (src == null) {
            Toast.makeText(this, "Couldn't open the photo", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val aspect = resources.displayMetrics.widthPixels.toFloat() / BackgroundStore.keyboardHeightPx(this)
        crop = CropView(this, src, aspect, resources.displayMetrics.density)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(16))
        root.addView(backHeader("Crop & position"))
        root.addView(tv("Drag to move, pinch to zoom. The bright frame is what your keyboard will show.", 13f, Ui.dim).apply {
            setPadding(0, 0, 0, dp(8))
        })
        crop.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f)
        root.addView(crop)

        zoomBar = seek(100, 0) { crop.setZoomFraction(it / 100f) }
        crop.onZoomChanged = { f -> zoomBar.progress = (f * 100).toInt() }
        root.addView(tv("Zoom", 13f, Ui.dim).apply { setPadding(0, dp(10), 0, 0) })
        root.addView(zoomBar)
        root.addView(tv("Position", 13f, Ui.dim).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(actionRow(listOf("Left", "Center", "Right")) { crop.alignH(it) })
        root.addView(actionRow(listOf("Top", "Middle", "Bottom")) { crop.alignV(it) })

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        val reset = button("Reset", Ui.field, Ui.text) { crop.reset() }
        val lp1 = LinearLayout.LayoutParams(0, dp(46), 1f)
        lp1.topMargin = dp(12)
        lp1.rightMargin = dp(6)
        reset.layoutParams = lp1
        val apply = button("Apply", Ui.accent, Ui.onAccent) { applyCrop() }
        val lp2 = LinearLayout.LayoutParams(0, dp(46), 1f)
        lp2.topMargin = dp(12)
        lp2.leftMargin = dp(6)
        apply.layoutParams = lp2
        buttons.addView(reset)
        buttons.addView(apply)
        root.addView(buttons)

        setContentView(root)
    }

    private fun actionRow(labels: List<String>, onTap: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, dp(40))
        lp.topMargin = dp(6)
        row.layoutParams = lp
        labels.forEachIndexed { i, name ->
            val t = tv(name, 13f, Ui.text, true)
            t.gravity = Gravity.CENTER
            t.background = roundBg(Ui.field, 10)
            val tlp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            tlp.setMargins(dp(3), 0, dp(3), 0)
            t.layoutParams = tlp
            t.setOnClickListener { onTap(i) }
            row.addView(t)
        }
        return row
    }

    private fun applyCrop() {
        val outW = minOf(resources.displayMetrics.widthPixels, 1440)
        Toast.makeText(this, "Saving…", Toast.LENGTH_SHORT).show()
        Thread {
            val bmp = crop.render(outW)
            val ok = ImageUtil.saveJpeg(bmp, BackgroundStore.outFile(this), 90)
            runOnUiThread {
                if (ok) {
                    prefs.edit()
                        .putBoolean(Prefs.BG_ON, true)
                        .putBoolean(Prefs.VID_ON, false)
                        .putLong(Prefs.BG_VER, System.currentTimeMillis())
                        .apply()
                    setResult(RESULT_OK)
                    finish()
                } else {
                    Toast.makeText(this, "Couldn't save the image", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }
}
