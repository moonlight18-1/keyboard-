package com.example.mykeyboard

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/** Settings: phản hồi khi gõ, gõ thông minh, bộ nhớ tạm và dịch. */
class SettingsActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(24))
        }
        col.addView(backHeader("Settings"))
        col.addView(testCard())
        col.addView(feedbackCard())
        col.addView(smartCard())
        col.addView(clipboardCard())
        col.addView(translateCard())
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
        staggerIn(col)
    }

    private fun note(s: String) = tv(s, 12f, Ui.dim).apply { setPadding(0, 0, 0, dp(4)) }

    private fun testCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_edit, "Try it out"))
        c.addView(tv("Change a setting, then type here to feel it.", 13f, Ui.dim).apply {
            setPadding(0, dp(8), 0, dp(10))
        })
        c.addView(EditText(this).apply {
            hint = "Type here to test"
            setHintTextColor(Ui.dim)
            setTextColor(Ui.text)
            background = roundBg(Ui.field, 14)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        })
        return c
    }

    private fun feedbackCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_keyboard, "Typing feedback"))
        c.addView(switchRow("Vibration", Prefs.VIBRATE))
        c.addView(tv("Vibration strength", 13f, Ui.dim))
        c.addView(seek(9, prefs.getInt(Prefs.VIB_STRENGTH, 5) - 1) {
            prefs.edit().putInt(Prefs.VIB_STRENGTH, it + 1).apply()
        })
        c.addView(switchRow("Key sound", Prefs.SOUND))
        c.addView(tv("Sound level", 13f, Ui.dim))
        c.addView(seek(10, prefs.getInt(Prefs.SOUND_VOLUME, 5)) {
            prefs.edit().putInt(Prefs.SOUND_VOLUME, it).apply()
        })
        c.addView(switchRow("Key popup bubble", Prefs.POPUP))
        c.addView(switchRow("Keyboard appear animation", Prefs.ANIM))
        return c
    }

    private fun smartCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_edit, "Smart typing"))
        c.addView(switchRow("Hold a key for accents & symbols", Prefs.LONG_PRESS))
        c.addView(note("Hold a, e, o, c, n, . - ' $ and more for extra characters. Slide to choose."))
        c.addView(switchRow("Slide on space bar to move cursor", Prefs.SPACE_SWIPE))
        c.addView(note("Drag your finger left or right on the space bar."))
        c.addView(switchRow("Double-space adds a period", Prefs.DOUBLE_SPACE))
        c.addView(note("Tap space twice after a word to end the sentence."))
        return c
    }

    private fun translateCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_translate, "Translate"))
        c.addView(switchRow("Show translate button", Prefs.TR_ON))
        c.addView(tv("Type in the translate box on the keyboard, then tap Translate to turn it into another language (10 languages). Your text is sent to an online translation service only when you tap Translate, and never from password fields.", 13f, Ui.dim))
        return c
    }

    private fun clipboardCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_clipboard, "Clipboard"))
        c.addView(switchRow("Save clipboard history", Prefs.CLIP_ENABLED))
        c.addView(tv("Copied text stays on this device only. Pinned items are kept until you remove them.", 13f, Ui.dim))
        c.addView(button("Clear clipboard history", Ui.field, Ui.text) {
            AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Clear clipboard history?")
                .setMessage("All saved items will be deleted, including pinned ones. This can't be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    ClipStore.clear(prefs)
                    Toast.makeText(this, "Clipboard history cleared", Toast.LENGTH_SHORT).show()
                }
                .show()
        })
        return c
    }
}
