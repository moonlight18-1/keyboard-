package com.example.mykeyboard

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/** Settings: rung, âm thanh, bong bóng chữ và bộ nhớ tạm. */
class SettingsActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        col.addView(header())
        col.addView(testCard())
        col.addView(feedbackCard())
        col.addView(clipboardCard())
        col.addView(translateCard())
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
    }

    private fun header(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(16) }
        }
        val back = tv("‹", 34f, Ui.text)
        back.setPadding(dp(4), 0, dp(18), dp(4))
        back.setOnClickListener { finish() }
        row.addView(back)
        row.addView(tv("Settings", 26f, Ui.text, true))
        return row
    }

    private fun testCard(): View {
        val c = card()
        c.addView(tv("Try it out", 18f, Ui.text, true))
        c.addView(tv("Change a setting, then type here to feel it.", 13f, Ui.dim).apply {
            setPadding(0, dp(4), 0, dp(10))
        })
        c.addView(EditText(this).apply {
            hint = "Type here to test"
            setHintTextColor(Ui.dim)
            setTextColor(Ui.text)
            background = roundBg(Ui.field, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        })
        return c
    }

    private fun feedbackCard(): View {
        val c = card()
        c.addView(tv("Typing feedback", 18f, Ui.text, true))
        c.addView(switchRow("Vibration", Prefs.VIBRATE))
        c.addView(tv("Vibration strength", 13f, Ui.dim))
        c.addView(seek(9, prefs.getInt(Prefs.VIB_STRENGTH, 5) - 1) {
            prefs.edit().putInt(Prefs.VIB_STRENGTH, it + 1).apply()
        })
        c.addView(switchRow("Key sound", Prefs.SOUND))
        c.addView(tv("Sound level", 13f, Ui.dim))
        c.addView(seek(10, prefs.getInt(Prefs.SOUND_VOLUME, 5)) {
            prefs.edit().putInt(Prefs.SOUND_VOLUME, it).apply()
        })
        c.addView(switchRow("Key popup bubble", Prefs.POPUP))
        c.addView(switchRow("Keyboard appear animation", Prefs.ANIM))
        return c
    }

    private fun translateCard(): View {
        val c = card()
        c.addView(tv("Translate", 18f, Ui.text, true))
        c.addView(switchRow("Show translate button", Prefs.TR_ON))
        c.addView(tv("Type in one language, then tap Translate on the keyboard to turn it into another (10 languages). Your text is sent to an online translation service only when you tap Translate, and never from password fields.", 13f, Ui.dim))
        return c
    }

    private fun clipboardCard(): View {
        val c = card()
        c.addView(tv("Clipboard", 18f, Ui.text, true))
        c.addView(switchRow("Save clipboard history", Prefs.CLIP_ENABLED))
        c.addView(tv("Copied text stays on this device only. Pinned items are kept until you remove them.", 13f, Ui.dim))
        c.addView(button("Clear clipboard history", Ui.field, Ui.text) {
            AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("Clear clipboard history?")
                .setMessage("All saved items will be deleted, including pinned ones. This can't be undone.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Clear") { _, _ ->
                    ClipStore.clear(prefs)
                    Toast.makeText(this, "Clipboard history cleared", Toast.LENGTH_SHORT).show()
                }
                .show()
        })
        return c
    }
}
