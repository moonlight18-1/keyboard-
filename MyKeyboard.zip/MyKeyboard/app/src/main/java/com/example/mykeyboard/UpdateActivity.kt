package com.example.mykeyboard

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast

/** Hiện khi bản đang cài đã cũ: không thể dùng app cho đến khi cập nhật. */
class UpdateActivity : BaseActivity() {

    override val guardUpdate: Boolean get() = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Ui.bg, Ui.bg2))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(28), dp(28), dp(28), dp(28))

        val icon = ImageView(this)
        icon.setImageResource(R.mipmap.ic_launcher)
        icon.layoutParams = LinearLayout.LayoutParams(dp(96), dp(96))
        col.addView(icon)

        col.addView(tv("Update required", 26f, Ui.text, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(8))
        })

        val latest = UpdateChecker.latestName(this)
        val msg = "This version of ML Keyboard (${versionName()}) can't be used any more." +
            (if (latest.isNotBlank()) "\nPlease install version $latest to continue." else "\nPlease install the latest version to continue.")
        col.addView(tv(msg, 15f, Ui.dim).apply { gravity = Gravity.CENTER })

        val notes = UpdateChecker.notes(this)
        if (notes.isNotBlank()) {
            col.addView(tv("What's new: $notes", 13f, Ui.text).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, 0)
            })
        }

        col.addView(button("Update now", Ui.accent, Ui.onAccent) { openDownload() }.apply {
            (layoutParams as LinearLayout.LayoutParams).topMargin = dp(28)
        })
        col.addView(button("Close", Ui.field, Ui.text) { finishAffinity() })

        root.addView(col, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.CENTER))
        setContentView(root)
    }

    private fun openDownload() {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(UpdateChecker.downloadUrl(this))))
        } catch (e: Exception) {
            Toast.makeText(this, "Couldn't open the download page", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        finishAffinity()
    }
}
