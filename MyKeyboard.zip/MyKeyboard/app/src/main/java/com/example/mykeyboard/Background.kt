package com.example.mykeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlin.math.max

/** Nơi lưu ảnh nền bàn phím (nằm trong bộ nhớ riêng của app). */
object BackgroundStore {
    fun srcFile(ctx: Context) = File(ctx.filesDir, "kb_bg_src.jpg")   // ảnh gốc đã thu nhỏ
    fun outFile(ctx: Context) = File(ctx.filesDir, "kb_bg.jpg")       // ảnh đã cắt khớp bàn phím
    fun hasSource(ctx: Context) = srcFile(ctx).exists()
    fun hasBackground(ctx: Context) = outFile(ctx).exists()

    fun videoFile(ctx: Context) = File(ctx.filesDir, "kb_video.mp4")
    fun videoThumb(ctx: Context) = File(ctx.filesDir, "kb_video_thumb.jpg")
    fun hasVideo(ctx: Context) = videoFile(ctx).exists()

    fun removeVideo(ctx: Context) {
        videoFile(ctx).delete()
        videoThumb(ctx).delete()
        Prefs.of(ctx).edit()
            .putBoolean(Prefs.VID_ON, false)
            .putLong(Prefs.VID_VER, System.currentTimeMillis())
            .apply()
    }

    /** Chiều cao bàn phím (px) theo cỡ phím đang chọn, để cắt ảnh đúng tỉ lệ. */
    fun keyboardHeightPx(ctx: Context): Int {
        val h = Prefs.of(ctx).getInt(Prefs.KEY_HEIGHT, 1).coerceIn(0, 2)
        val dp = 4 + 44 + KbLayout.numDp[h] + 4 * KbLayout.rowDp[h] + 8
        return (dp * ctx.resources.displayMetrics.density).toInt()
    }

    fun remove(ctx: Context) {
        srcFile(ctx).delete()
        outFile(ctx).delete()
        Prefs.of(ctx).edit()
            .putBoolean(Prefs.BG_ON, false)
            .putLong(Prefs.BG_VER, System.currentTimeMillis())
            .apply()
    }
}

object ImageUtil {
    /** Đọc ảnh từ thư viện, tự xoay đúng chiều và thu nhỏ để cạnh dài nhất <= maxSide. */
    fun load(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            val deg = ctx.contentResolver.openInputStream(uri)?.use { exifDegrees(it) } ?: 0
            bmp = fit(bmp, maxSide, deg)
            bmp
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    fun loadFile(path: String, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = BitmapFactory.decodeFile(path, opts) ?: return null
            fit(bmp, maxSide, 0)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    private fun fit(bmp: Bitmap, maxSide: Int, degrees: Int): Bitmap {
        val longest = max(bmp.width, bmp.height)
        val scale = if (longest > maxSide) maxSide / longest.toFloat() else 1f
        if (scale >= 1f && degrees == 0) return bmp
        val m = Matrix()
        m.postScale(scale, scale)
        if (degrees != 0) m.postRotate(degrees.toFloat())
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun exifDegrees(input: InputStream): Int = try {
        when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    fun saveJpeg(bmp: Bitmap, file: File, quality: Int): Boolean = try {
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    } catch (e: Exception) {
        false
    }
}

/** Nhập video làm nền: chép vào bộ nhớ riêng của app và lấy khung hình đầu làm ảnh xem trước. */
object VideoUtil {
    const val MAX_BYTES = 80L * 1024 * 1024

    private fun finish(ctx: Context, out: File, ok: Boolean): Boolean {
        if (!ok || !makeThumb(ctx, out)) {
            out.delete()
            return false
        }
        // Chọn video thì tắt nền ảnh (chỉ dùng một trong hai)
        Prefs.of(ctx).edit()
            .putBoolean(Prefs.VID_ON, true)
            .putBoolean(Prefs.BG_ON, false)
            .putLong(Prefs.VID_VER, System.currentTimeMillis())
            .apply()
        return true
    }

    /** Chép video từ thư viện (tối đa 80 MB). */
    fun importFromUri(ctx: Context, uri: Uri): Boolean {
        val out = BackgroundStore.videoFile(ctx)
        val ok = try {
            copy(ctx.contentResolver.openInputStream(uri), out)
        } catch (e: Exception) {
            false
        }
        return finish(ctx, out, ok)
    }

    /** Dùng video có sẵn trong app (thư mục assets/videos). */
    fun importFromAsset(ctx: Context, name: String): Boolean {
        val out = BackgroundStore.videoFile(ctx)
        val ok = try {
            copy(ctx.assets.open("videos/" + name), out)
        } catch (e: Exception) {
            false
        }
        return finish(ctx, out, ok)
    }

    private fun copy(input: InputStream?, out: File): Boolean {
        if (input == null) return false
        var total = 0L
        input.use { src ->
            FileOutputStream(out).use { dst ->
                val buf = ByteArray(64 * 1024)
                while (true) {
                    val n = src.read(buf)
                    if (n <= 0) break
                    total += n
                    if (total > MAX_BYTES) return false
                    dst.write(buf, 0, n)
                }
            }
        }
        return total > 0
    }

    private fun makeThumb(ctx: Context, file: File): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.path)
            if (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) != "yes") return false
            val frame = r.getFrameAtTime(500_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(0)
                ?: return false
            val big = max(frame.width, frame.height)
            val scaled = if (big > 1080) {
                Bitmap.createScaledBitmap(frame, frame.width * 1080 / big, frame.height * 1080 / big, true)
            } else {
                frame
            }
            ImageUtil.saveJpeg(scaled, BackgroundStore.videoThumb(ctx), 88)
        } catch (e: Exception) {
            false
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
                // bỏ qua
            }
        }
    }
}
