package com.example.mykeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlin.math.max

/** Nơi lưu ảnh nền bàn phím (nằm trong bộ nhớ riêng của app). */
object BackgroundStore {
    fun srcFile(ctx: Context) = File(ctx.filesDir, "kb_bg_src.jpg")   // ảnh gốc đã thu nhỏ
    fun outFile(ctx: Context) = File(ctx.filesDir, "kb_bg.jpg")       // ảnh đã cắt khớp bàn phím
    fun hasSource(ctx: Context) = srcFile(ctx).exists()
    fun hasBackground(ctx: Context) = outFile(ctx).exists()

    /** Chiều cao bàn phím (px) theo cỡ phím đang chọn, để cắt ảnh đúng tỉ lệ. */
    fun keyboardHeightPx(ctx: Context): Int {
        val h = Prefs.of(ctx).getInt(Prefs.KEY_HEIGHT, 1).coerceIn(0, 2)
        val dp = 4 + 44 + KbLayout.numDp[h] + 4 * KbLayout.rowDp[h] + 8
        return (dp * ctx.resources.displayMetrics.density).toInt()
    }

    fun remove(ctx: Context) {
        srcFile(ctx).delete()
        outFile(ctx).delete()
        Prefs.of(ctx).edit()
            .putBoolean(Prefs.BG_ON, false)
            .putLong(Prefs.BG_VER, System.currentTimeMillis())
            .apply()
    }
}

object ImageUtil {
    /** Đọc ảnh từ thư viện, tự xoay đúng chiều và thu nhỏ để cạnh dài nhất <= maxSide. */
    fun load(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return null
            val deg = ctx.contentResolver.openInputStream(uri)?.use { exifDegrees(it) } ?: 0
            bmp = fit(bmp, maxSide, deg)
            bmp
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    fun loadFile(path: String, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = BitmapFactory.decodeFile(path, opts) ?: return null
            fit(bmp, maxSide, 0)
        } catch (e: Exception) {
            null
        } catch (e: OutOfMemoryError) {
            null
        }
    }

    private fun fit(bmp: Bitmap, maxSide: Int, degrees: Int): Bitmap {
        val longest = max(bmp.width, bmp.height)
        val scale = if (longest > maxSide) maxSide / longest.toFloat() else 1f
        if (scale >= 1f && degrees == 0) return bmp
        val m = Matrix()
        m.postScale(scale, scale)
        if (degrees != 0) m.postRotate(degrees.toFloat())
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    private fun exifDegrees(input: InputStream): Int = try {
        when (ExifInterface(input).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    } catch (e: Exception) {
        0
    }

    fun saveJpeg(bmp: Bitmap, file: File, quality: Int): Boolean = try {
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
    } catch (e: Exception) {
        false
    }
}
