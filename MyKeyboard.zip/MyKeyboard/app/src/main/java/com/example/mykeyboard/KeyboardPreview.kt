package com.example.mykeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.View

/** Một phím trong bản xem trước. style: 0 phím thường, 1 phím đặc biệt, 2 nhấn, 3 chỗ trống, 4 chip, 5 nút thanh công cụ. */
private class PK(val w: Float, val label: String, val style: Int)

/** Bản xem trước thu nhỏ của bàn phím: đúng màu, phông chữ, bố cục và ảnh nền đang chọn. */
class KeyboardPreview(ctx: Context, private val density: Float) : View(ctx) {
    private var c: KbColors = Themes.colors(Themes.all[0], 0)
    private var hIdx = 1
    private var sIdx = 1
    private var gIdx = 1
    private var oIdx = 0
    private var bg: Bitmap? = null
    private var dimAlpha = 0
    private var keyAlpha = 255
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = KbFonts.key(0)
    }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint()
    private val clip = Path()
    private val rect = RectF()
    private val src = Rect()
    private val dst = Rect()

    fun update(colors: KbColors, height: Int, shape: Int, spacing: Int, hand: Int, font: Int) {
        c = colors
        hIdx = height.coerceIn(0, 2)
        sIdx = shape.coerceIn(0, 2)
        gIdx = spacing.coerceIn(0, 2)
        oIdx = hand.coerceIn(0, 2)
        txt.typeface = KbFonts.key(font)
        requestLayout()
        invalidate()
    }

    /** dim: 0..7 (độ tối của ảnh), keyOpacity: 3..10 (độ đặc của phím). */
    fun setBackgroundImage(b: Bitmap?, dim: Int, keyOpacity: Int) {
        bg = b
        dimAlpha = dim * 255 / 10
        keyAlpha = if (b != null) (keyOpacity * 25).coerceIn(0, 255) else 255
        invalidate()
    }

    private fun px(dp: Float): Float = dp * density * 0.62f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = px(4f + 44f + KbLayout.numDp[hIdx] + 4f * KbLayout.rowDp[hIdx] + 8f)
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h.toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        fill.color = c.background
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, px(16f), px(16f), fill)

        val b = bg
        if (b != null) {
            canvas.save()
            clip.reset()
            clip.addRoundRect(rect, px(16f), px(16f), Path.Direction.CW)
            canvas.clipPath(clip)
            val sc = maxOf(w / b.width, h / b.height)
            val sw = (w / sc).toInt()
            val sh = (h / sc).toInt()
            src.set((b.width - sw) / 2, (b.height - sh) / 2, (b.width + sw) / 2, (b.height + sh) / 2)
            dst.set(0, 0, width, height)
            canvas.drawBitmap(b, src, dst, bmpPaint)
            if (dimAlpha > 0) {
                dimPaint.color = Color.argb(dimAlpha, 0, 0, 0)
                canvas.drawRect(dst, dimPaint)
            }
            canvas.restore()
        }

        val kbW = if (oIdx == 0) w else w * 0.8f
        val x0 = if (oIdx == 2) w - kbW else 0f
        val rowH = px(KbLayout.rowDp[hIdx].toFloat())
        val numH = px(KbLayout.numDp[hIdx].toFloat())
        val tbH = px(44f)
        val m = px(KbLayout.marginDp[gIdx].toFloat())
        val r = px(KbLayout.cornerDp[sIdx].toFloat())
        var y = px(4f)

        val toolbar = listOf(PK(1f, "", 5), PK(1f, "", 5), PK(1f, "", 5), PK(1f, "", 5), PK(4.2f, "", 4), PK(1f, "", 5))
        drawRow(canvas, x0, y, kbW, tbH, m, px(19f), toolbar, 0f, false)
        y += tbH
        drawRow(canvas, x0, y, kbW, numH, m, r, "1234567890".map { PK(1f, it.toString(), 0) }, px(15f), true)
        y += numH
        drawRow(canvas, x0, y, kbW, rowH, m, r, "qwertyuiop".map { PK(1f, it.toString(), 0) }, px(22f), false)
        y += rowH
        val home = listOf(PK(0.5f, "", 3)) + "asdfghjkl".map { PK(1f, it.toString(), 0) } + PK(0.5f, "", 3)
        drawRow(canvas, x0, y, kbW, rowH, m, r, home, px(22f), false)
        y += rowH
        val bottomLetters = listOf(PK(1.5f, "", 1)) + "zxcvbnm".map { PK(1f, it.toString(), 0) } + PK(1.5f, "", 1)
        drawRow(canvas, x0, y, kbW, rowH, m, r, bottomLetters, px(22f), false)
        y += rowH
        val bottom = listOf(PK(1.5f, "?123", 1), PK(1f, ",", 0), PK(5f, "", 0), PK(1f, ".", 0), PK(1.5f, "", 2))
        drawRow(canvas, x0, y, kbW, rowH, m, r, bottom, px(14f), false)
    }

    private fun drawRow(
        canvas: Canvas, x0: Float, y: Float, width: Float, h: Float,
        m: Float, r: Float, items: List<PK>, textPx: Float, dim: Boolean
    ) {
        var total = 0f
        for (k in items) total += k.w
        val avail = width - px(8f)
        var x = x0 + px(4f)
        for (k in items) {
            val kw = avail * k.w / total
            if (k.style != 3) {
                rect.set(x + m, y + m, x + kw - m, y + h - m)
                val base = when (k.style) {
                    2 -> c.accent
                    1, 4, 5 -> c.special
                    else -> c.key
                }
                fill.color = if (k.style == 2) base else ((base and 0x00FFFFFF) or (keyAlpha shl 24))
                canvas.drawRoundRect(rect, r, r, fill)
                if (k.style == 4) {
                    line.color = c.accent
                    line.alpha = 130
                    line.strokeWidth = px(1.2f)
                    canvas.drawRoundRect(rect, r, r, line)
                }
                if (k.label.isNotEmpty()) {
                    txt.textSize = textPx
                    txt.color = when {
                        k.style == 2 -> c.onAccent
                        dim -> c.dim
                        else -> c.text
                    }
                    canvas.drawText(k.label, rect.centerX(), rect.centerY() - (txt.ascent() + txt.descent()) / 2f, txt)
                }
            }
            x += kw
        }
    }
}
