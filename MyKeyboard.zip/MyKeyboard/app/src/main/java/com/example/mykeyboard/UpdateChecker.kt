package com.example.mykeyboard

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Kiểm tra bản cập nhật.
 * Đặt file version.json ở thư mục gốc repo GitHub (repo phải công khai):
 *   {"version_code": 12, "version_name": "1.5.5", "force": true, "url": "...", "notes": "..."}
 * Nếu version_code lớn hơn bản đang cài và force = true thì app + bàn phím bị khóa cho đến khi cập nhật.
 */
object UpdateChecker {
    const val VERSION_URL = "https://raw.githubusercontent.com/moonlight18-1/keyboard-/main/version.json"
    const val DEFAULT_DOWNLOAD_URL = "https://github.com/moonlight18-1/keyboard-/releases/latest"
    private const val RECHECK_MS = 6 * 60 * 60 * 1000L   // bàn phím tự kiểm tra lại mỗi 6 giờ

    @Suppress("DEPRECATION")
    fun installedCode(ctx: Context): Int = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionCode
    } catch (e: Exception) {
        0
    }

    /** Hỏi máy chủ phiên bản mới nhất (gọi ở luồng nền). Hỏi không được thì giữ kết quả lần trước. */
    fun check(ctx: Context): Boolean {
        val prefs = Prefs.of(ctx)
        prefs.edit().putLong(Prefs.UPD_TIME, System.currentTimeMillis()).apply()
        var conn: HttpURLConnection? = null
        return try {
            conn = URL(VERSION_URL + "?t=" + System.currentTimeMillis()).openConnection() as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.useCaches = false
            if (conn.responseCode != 200) return false
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val j = JSONObject(body)
            prefs.edit()
                .putInt(Prefs.UPD_CODE, j.optInt("version_code", 0))
                .putString(Prefs.UPD_NAME, j.optString("version_name", ""))
                .putString(Prefs.UPD_URL, j.optString("url", DEFAULT_DOWNLOAD_URL))
                .putBoolean(Prefs.UPD_FORCE, j.optBoolean("force", true))
                .putString(Prefs.UPD_NOTES, j.optString("notes", ""))
                .apply()
            true
        } catch (e: Exception) {
            false
        } finally {
            conn?.disconnect()
        }
    }

    fun isOutdated(ctx: Context): Boolean =
        Prefs.of(ctx).getInt(Prefs.UPD_CODE, 0) > installedCode(ctx)

    /** Bị khóa = có bản mới hơn và bản mới đó bắt buộc cập nhật. */
    fun isBlocked(ctx: Context): Boolean =
        isOutdated(ctx) && Prefs.of(ctx).getBoolean(Prefs.UPD_FORCE, true)

    fun shouldRecheck(ctx: Context): Boolean =
        System.currentTimeMillis() - Prefs.of(ctx).getLong(Prefs.UPD_TIME, 0L) > RECHECK_MS

    fun latestName(ctx: Context): String = Prefs.of(ctx).getString(Prefs.UPD_NAME, "") ?: ""

    fun notes(ctx: Context): String = Prefs.of(ctx).getString(Prefs.UPD_NOTES, "") ?: ""

    fun downloadUrl(ctx: Context): String {
        val u = Prefs.of(ctx).getString(Prefs.UPD_URL, "") ?: ""
        return if (u.isBlank()) DEFAULT_DOWNLOAD_URL else u
    }
}
