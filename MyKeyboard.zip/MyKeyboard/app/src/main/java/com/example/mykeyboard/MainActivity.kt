package com.example.mykeyboard

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Màn hình chính: banner trạng thái, hướng dẫn cài đặt, các ô chức năng. */
class MainActivity : BaseActivity() {

    private lateinit var heroChip: TextView
    private lateinit var setupCard: View
    private lateinit var enablePill: TextView
    private lateinit var selectPill: TextView
    private lateinit var languageSub: TextView

    // Hiện chỉ có tiếng Anh; thêm ngôn ngữ mới ở đây sau này
    private val languages = listOf("en" to "English")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(24))
        }
        col.addView(hero())
        setupCard = setupCard()
        col.addView(setupCard)
        col.addView(tiles())
        col.addView(tryCard())
        col.addView(tv("ML Keyboard v${versionName()}  ·  English (QWERTY)", 12f, Ui.dim).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        })
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
        refreshStatus()
        staggerIn(col)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshStatus()
    }

    /* ================= BANNER ================= */
    private fun hero(): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#4A3BD0"), Color.parseColor("#0D8F9A"))
        ).apply { cornerRadius = dp(26).toFloat() }
        c.setPadding(dp(20), dp(20), dp(20), dp(20))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.bottomMargin = dp(14)
        c.layoutParams = lp

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val icon = ImageView(this)
        icon.setImageResource(R.mipmap.ic_launcher)
        icon.layoutParams = LinearLayout.LayoutParams(dp(68), dp(68)).apply { rightMargin = dp(16) }
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(tv("ML Keyboard", 26f, Color.WHITE, true))
        titles.addView(tv("Version ${versionName()}", 13f, Color.argb(200, 255, 255, 255)))
        row.addView(icon)
        row.addView(titles)
        c.addView(row)

        c.addView(tv("Type smooth. Look great.", 14f, Color.argb(225, 255, 255, 255)).apply {
            setPadding(0, dp(14), 0, 0)
        })

        heroChip = tv("", 12f, Ui.good, true)
        heroChip.setPadding(dp(14), dp(6), dp(14), dp(6))
        val chipLp = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT)
        chipLp.topMargin = dp(14)
        heroChip.layoutParams = chipLp
        c.addView(heroChip)
        return c
    }

    /* ================= HƯỚNG DẪN CÀI ĐẶT ================= */
    private fun setupCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_keyboard, "Finish setup"))
        enablePill = step(c, 1, "Enable keyboard", "Turn on ML Keyboard in settings", "Open keyboard settings") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        selectPill = step(c, 2, "Select keyboard", "Choose ML Keyboard as your input method", "Choose keyboard") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        return c
    }

    /* ================= CÁC Ô CHỨC NĂNG ================= */
    private fun tiles(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.addView(
            tileRow(
                tile(R.drawable.ic_keyboard, "Keyboard", "Colors, fonts, layout", Ui.grad1, Ui.grad2, null) {
                    go(Intent(this, KeyboardActivity::class.java))
                },
                tile(R.drawable.ic_image, "Background", "Photo or video", Color.parseColor("#D946EF"), Color.parseColor("#6A5CF0"), null) {
                    go(Intent(this, BackgroundActivity::class.java))
                }
            )
        )
        box.addView(
            tileRow(
                tile(R.drawable.ic_settings, "Settings", "Feedback, clipboard", Color.parseColor("#14B8A6"), Color.parseColor("#22C55E"), null) {
                    go(Intent(this, SettingsActivity::class.java))
                },
                tile(R.drawable.ic_globe, "Language", currentLanguageName(), Color.parseColor("#F59E0B"), Color.parseColor("#EF4444"), { languageSub = it }) {
                    showLanguageDialog()
                }
            )
        )
        return box
    }

    private fun tileRow(a: View, b: View): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        row.layoutParams = lp
        val la = LinearLayout.LayoutParams(0, dp(128), 1f)
        la.rightMargin = dp(6)
        val lb = LinearLayout.LayoutParams(0, dp(128), 1f)
        lb.leftMargin = dp(6)
        row.addView(a, la)
        row.addView(b, lb)
        return row
    }

    private fun tile(
        iconRes: Int, title: String, sub: String, c1: Int, c2: Int,
        onSub: ((TextView) -> Unit)?, onClick: () -> Unit
    ): View {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.BOTTOM
        t.setPadding(dp(16), dp(14), dp(16), dp(14))
        t.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
            .apply { cornerRadius = dp(24).toFloat() }

        val icon = ImageView(this)
        icon.setImageResource(iconRes)
        icon.setColorFilter(Color.WHITE)
        val pad = dp(9)
        icon.setPadding(pad, pad, pad, pad)
        icon.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(60, 255, 255, 255))
        }
        val ilp = LinearLayout.LayoutParams(dp(42), dp(42))
        ilp.bottomMargin = dp(12)
        icon.layoutParams = ilp
        t.addView(icon)
        t.addView(tv(title, 17f, Color.WHITE, true))
        val subView = tv(sub, 12f, Color.argb(215, 255, 255, 255))
        t.addView(subView)
        onSub?.invoke(subView)

        t.setOnClickListener { onClick() }
        pressable(t)
        return t
    }

    private fun tryCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_edit, "Try your keyboard"))
        c.addView(EditText(this).apply {
            hint = "Tap here and start typing…"
            setHintTextColor(Ui.dim)
            setTextColor(Ui.text)
            background = roundBg(Ui.field, 14)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }
        })
        return c
    }

    /* ================= Language ================= */
    private fun currentLanguageName(): String {
        val code = prefs.getString(Prefs.LANGUAGE, "en") ?: "en"
        return languages.firstOrNull { it.first == code }?.second ?: "English"
    }

    private fun showLanguageDialog() {
        val current = prefs.getString(Prefs.LANGUAGE, "en") ?: "en"
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(8))
        val dialog = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Language")
            .setView(box)
            .setNegativeButton("Close", null)
            .create()
        languages.forEach { (code, name) ->
            val selected = code == current
            val row = tv(if (selected) "$name   ✓" else name, 17f, if (selected) Ui.accent else Ui.text, selected)
            row.setPadding(0, dp(12), 0, dp(12))
            row.setOnClickListener {
                prefs.edit().putString(Prefs.LANGUAGE, code).apply()
                languageSub.text = name
                dialog.dismiss()
            }
            box.addView(row)
        }
        box.addView(tv("More languages are coming soon.", 13f, Ui.dim).apply { setPadding(0, dp(8), 0, dp(4)) })
        dialog.show()
    }

    /* ================= TRẠNG THÁI CÀI ĐẶT ================= */
    private fun refreshStatus() {
        if (!::enablePill.isInitialized) return
        val enabled = isEnabled()
        val selected = isSelected()
        setPill(enablePill, enabled)
        setPill(selectPill, selected)
        val ready = enabled && selected
        heroChip.text = if (ready) "●  Ready to type" else "●  Finish setup below"
        heroChip.setTextColor(if (ready) Ui.good else Ui.warn)
        heroChip.background = roundBg(Color.argb(55, 0, 0, 0), 20)
        setupCard.visibility = if (ready) View.GONE else View.VISIBLE
    }

    private fun isEnabled(): Boolean {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun isSelected(): Boolean {
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return cur.startsWith("$packageName/")
    }

    private fun setPill(v: TextView, done: Boolean) {
        v.text = if (done) "Done" else "To do"
        v.setTextColor(if (done) Ui.onAccent else Ui.dim)
        v.background = roundBg(if (done) Ui.accent else Ui.field, 20)
    }

    /** Một bước hướng dẫn; trả về nhãn trạng thái (Done / To do). */
    private fun step(parent: LinearLayout, n: Int, title: String, sub: String, btn: String, onClick: () -> Unit): TextView {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val hlp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        hlp.topMargin = dp(16)
        head.layoutParams = hlp

        val badge = tv(n.toString(), 14f, Color.WHITE, true)
        badge.gravity = Gravity.CENTER
        badge.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(Ui.grad1, Ui.grad2)
        ).apply { shape = GradientDrawable.OVAL }
        val blp = LinearLayout.LayoutParams(dp(30), dp(30))
        blp.rightMargin = dp(12)
        badge.layoutParams = blp

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        titles.addView(tv(title, 16f, Ui.text, true))
        titles.addView(tv(sub, 13f, Ui.dim))

        val pill = tv("", 12f, Ui.dim, true)
        pill.setPadding(dp(12), dp(4), dp(12), dp(4))

        head.addView(badge)
        head.addView(titles)
        head.addView(pill)
        parent.addView(head)
        parent.addView(button(btn, Ui.accent, Ui.onAccent, onClick))
        return pill
    }
}
