package com.example.mykeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

/** Màn hình hướng dẫn bật bàn phím. */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "Bàn phím của tôi"
            textSize = 26f
            setPadding(0, 0, 0, pad)
        })
        layout.addView(Button(this).apply {
            text = "1. Bật bàn phím"
            setOnClickListener {
                this@MainActivity.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Chọn làm bàn phím đang dùng"
            setOnClickListener {
                val imm = this@MainActivity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        layout.addView(EditText(this).apply { hint = "3. Gõ thử ở đây" })
        setContentView(layout)
    }
}
