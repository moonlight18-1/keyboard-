package com.example.mykeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

/** Màn hình bật bàn phím và chỉnh cài đặt. */
class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs.of(this)
        val pad = dp(20)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        fun label(s: String, size: Float, top: Int = 0) = TextView(this).apply {
            text = s
            textSize = size
            setPadding(0, dp(top), 0, dp(6))
        }

        col.addView(label("My Keyboard", 26f))
        col.addView(Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener {
                this@MainActivity.startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })
        col.addView(Button(this).apply {
            text = "2. Select keyboard"
            setOnClickListener {
                val imm = this@MainActivity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        })
        col.addView(EditText(this).apply { hint = "3. Type here to test" })

        col.addView(label("Settings", 20f, 24))

        col.addView(Switch(this).apply {
            text = "Vibration"
            isChecked = prefs.getBoolean(Prefs.VIBRATE, true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(Prefs.VIBRATE, on).apply() }
        })
        col.addView(label("Vibration strength", 14f, 8))
        col.addView(seek(9, prefs.getInt(Prefs.VIB_STRENGTH, 5) - 1) {
            prefs.edit().putInt(Prefs.VIB_STRENGTH, it + 1).apply()
        })

        col.addView(Switch(this).apply {
            text = "Key sound"
            isChecked = prefs.getBoolean(Prefs.SOUND, true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(Prefs.SOUND, on).apply() }
        })
        col.addView(label("Sound volume", 14f, 8))
        col.addView(seek(10, prefs.getInt(Prefs.SOUND_VOLUME, 5)) {
            prefs.edit().putInt(Prefs.SOUND_VOLUME, it).apply()
        })

        col.addView(Switch(this).apply {
            text = "Key popup bubble"
            isChecked = prefs.getBoolean(Prefs.POPUP, true)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(Prefs.POPUP, on).apply() }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun seek(max: Int, init: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        this.max = max
        progress = init
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
