package com.example.mykeyboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

private object Ui {
    val card = Color.parseColor("#1B1F2E")
    val field = Color.parseColor("#252A3B")
    val accent = Color.parseColor("#4FD1C5")
    val onAccent = Color.parseColor("#06201D")
    val text = Color.parseColor("#E8EAF2")
    val dim = Color.parseColor("#8E94AD")
}

/** Màn hình chính: hướng dẫn cài đặt, What's New và cài đặt rung / âm thanh. */
class MainActivity : Activity() {

    private val prefs by lazy { Prefs.of(this) }
    private lateinit var enablePill: TextView
    private lateinit var selectPill: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        col.addView(header())
        col.addView(setupCard())
        col.addView(whatsNewCard())
        col.addView(feedbackCard())
        col.addView(tv("ML Keyboard v${versionName()}  ·  English (QWERTY)", 12f, Ui.dim).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        })
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
        refreshStatus()

        // Lần đầu mở sau mỗi lần cập nhật: tự hiện What's New
        val cur = versionName()
        if (prefs.getString(Prefs.LAST_SEEN_VERSION, "") != cur) {
            prefs.edit().putString(Prefs.LAST_SEEN_VERSION, cur).apply()
            showWhatsNew(false)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshStatus()
    }

    /* ================= CÁC KHỐI GIAO DIỆN ================= */
    private fun header(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(20) }
        }
        val icon = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(60), dp(60)).apply { rightMargin = dp(14) }
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("ML Keyboard", 26f, Ui.text, true))
            addView(tv("Version ${versionName()}", 13f, Ui.dim))
        }
        row.addView(icon)
        row.addView(titles)
        return row
    }

    private fun setupCard(): View {
        val c = card()
        c.addView(tv("Get started", 18f, Ui.text, true))
        enablePill = step(c, 1, "Enable keyboard", "Turn on ML Keyboard in settings", "Open keyboard settings") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        selectPill = step(c, 2, "Select keyboard", "Choose ML Keyboard as your input method", "Choose keyboard") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        c.addView(tv("Try it out", 14f, Ui.dim).apply { setPadding(0, dp(18), 0, dp(6)) })
        c.addView(EditText(this).apply {
            hint = "Type here to test"
            setHintTextColor(Ui.dim)
            setTextColor(Ui.text)
            background = roundBg(Ui.field, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        })
        return c
    }

    private fun whatsNewCard(): View {
        val latest = Changelog.releases.first()
        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(tv("What's New", 18f, Ui.text, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        })
        head.addView(tv("v${latest.version}", 12f, Ui.onAccent, true).apply {
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = roundBg(Ui.accent, 20)
        })
        c.addView(head)
        c.addView(tv(latest.title, 15f, Ui.accent, true).apply { setPadding(0, dp(8), 0, dp(6)) })
        latest.notes.forEach { note ->
            c.addView(tv("•  $note", 14f, Ui.text).apply { setPadding(0, dp(3), 0, dp(3)) })
        }
        c.addView(button("See all updates", Ui.field, Ui.text) { showWhatsNew(true) })
        return c
    }

    private fun feedbackCard(): View {
        val c = card()
        c.addView(tv("Typing feedback", 18f, Ui.text, true))
        c.addView(switchRow("Vibration", Prefs.VIBRATE))
        c.addView(tv("Vibration strength", 13f, Ui.dim))
        c.addView(seek(9, prefs.getInt(Prefs.VIB_STRENGTH, 5) - 1) {
            prefs.edit().putInt(Prefs.VIB_STRENGTH, it + 1).apply()
        })
        c.addView(switchRow("Key sound", Prefs.SOUND))
        c.addView(tv("Sound volume", 13f, Ui.dim))
        c.addView(seek(10, prefs.getInt(Prefs.SOUND_VOLUME, 5)) {
            prefs.edit().putInt(Prefs.SOUND_VOLUME, it).apply()
        })
        c.addView(switchRow("Key popup bubble", Prefs.POPUP))
        return c
    }

    /* ================= What's New ================= */
    private fun showWhatsNew(all: Boolean) {
        val list = if (all) Changelog.releases else listOf(Changelog.releases.first())
        val msg = list.joinToString("\n\n") { r ->
            "v${r.version}  ·  ${r.date}\n${r.title}\n" + r.notes.joinToString("\n") { "•  $it" }
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(if (all) "All updates" else "What's New in v${list[0].version}")
            .setMessage(msg)
            .setPositiveButton("Got it", null)
            .show()
    }

    /* ================= TRẠNG THÁI CÀI ĐẶT ================= */
    private fun refreshStatus() {
        if (!::enablePill.isInitialized) return
        setPill(enablePill, isEnabled())
        setPill(selectPill, isSelected())
    }

    private fun isEnabled(): Boolean {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun isSelected(): Boolean {
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return cur.startsWith("$packageName/")
    }

    private fun setPill(v: TextView, done: Boolean) {
        v.text = if (done) "Done" else "To do"
        v.setTextColor(if (done) Ui.onAccent else Ui.dim)
        v.background = roundBg(if (done) Ui.accent else Ui.field, 20)
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    /* ================= HÀM TIỆN ÍCH ================= */
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
    }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(Ui.card, 16)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    private fun button(label: String, bg: Int, fg: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(fg)
        b.background = roundBg(bg, 12)
        b.stateListAnimator = null
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, dp(46))
        lp.topMargin = dp(12)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    /** Một bước hướng dẫn; trả về nhãn trạng thái (Done / To do). */
    private fun step(parent: LinearLayout, n: Int, title: String, sub: String, btn: String, onClick: () -> Unit): TextView {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val hlp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        hlp.topMargin = dp(16)
        head.layoutParams = hlp

        val badge = tv(n.toString(), 14f, Ui.onAccent, true)
        badge.gravity = Gravity.CENTER
        badge.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Ui.accent)
        }
        val blp = LinearLayout.LayoutParams(dp(28), dp(28))
        blp.rightMargin = dp(12)
        badge.layoutParams = blp

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        titles.addView(tv(title, 16f, Ui.text, true))
        titles.addView(tv(sub, 13f, Ui.dim))

        val pill = tv("", 12f, Ui.dim, true)
        pill.setPadding(dp(10), dp(3), dp(10), dp(3))

        head.addView(badge)
        head.addView(titles)
        head.addView(pill)
        parent.addView(head)
        parent.addView(button(btn, Ui.accent, Ui.onAccent, onClick))
        return pill
    }

    private fun switchRow(label: String, key: String): Switch {
        val s = Switch(this)
        s.text = label
        s.textSize = 16f
        s.setTextColor(Ui.text)
        s.setPadding(0, dp(12), 0, dp(10))
        s.isChecked = prefs.getBoolean(key, true)
        s.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        return s
    }

    private fun seek(max: Int, init: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = max
        s.progress = init
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }
}
