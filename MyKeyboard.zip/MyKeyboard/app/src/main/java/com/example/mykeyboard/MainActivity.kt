package com.example.mykeyboard

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Màn hình chính: hướng dẫn cài đặt, Settings, Language và What's New. */
class MainActivity : BaseActivity() {

    private lateinit var enablePill: TextView
    private lateinit var selectPill: TextView
    private lateinit var languageValue: TextView

    // Hiện chỉ có tiếng Anh; thêm ngôn ngữ mới ở đây sau này
    private val languages = listOf("en" to "English")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        col.addView(header())
        col.addView(setupCard())
        col.addView(menuCard())
        col.addView(whatsNewCard())
        col.addView(tv("ML Keyboard v${versionName()}  ·  English (QWERTY)", 12f, Ui.dim).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        })
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
        refreshStatus()

        // Lần đầu mở sau mỗi lần cập nhật: tự hiện What's New
        val cur = versionName()
        if (prefs.getString(Prefs.LAST_SEEN_VERSION, "") != cur) {
            prefs.edit().putString(Prefs.LAST_SEEN_VERSION, cur).apply()
            showWhatsNew(false)
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshStatus()
    }

    /* ================= CÁC KHỐI GIAO DIỆN ================= */
    private fun header(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { bottomMargin = dp(20) }
        }
        val icon = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(60), dp(60)).apply { rightMargin = dp(14) }
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("ML Keyboard", 26f, Ui.text, true))
            addView(tv("Version ${versionName()}", 13f, Ui.dim))
        }
        row.addView(icon)
        row.addView(titles)
        return row
    }

    private fun setupCard(): View {
        val c = card()
        c.addView(tv("Get started", 18f, Ui.text, true))
        enablePill = step(c, 1, "Enable keyboard", "Turn on ML Keyboard in settings", "Open keyboard settings") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        selectPill = step(c, 2, "Select keyboard", "Choose ML Keyboard as your input method", "Choose keyboard") {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
        c.addView(tv("Try it out", 14f, Ui.dim).apply { setPadding(0, dp(18), 0, dp(6)) })
        c.addView(EditText(this).apply {
            hint = "Type here to test"
            setHintTextColor(Ui.dim)
            setTextColor(Ui.text)
            background = roundBg(Ui.field, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        })
        return c
    }

    /** Mục Settings và Language. */
    private fun menuCard(): View {
        val c = card()
        c.setPadding(dp(12), dp(6), dp(12), dp(6))
        c.addView(menuRow(R.drawable.ic_settings, "Settings", "Vibration, sound level, popup, clipboard", null) {
            startActivity(Intent(this, SettingsActivity::class.java))
        })
        val divider = View(this)
        divider.setBackgroundColor(Ui.field)
        divider.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 1)
        c.addView(divider)
        languageValue = tv(currentLanguageName(), 14f, Ui.dim)
        c.addView(menuRow(R.drawable.ic_globe, "Language", "Keyboard and app language", languageValue) {
            showLanguageDialog()
        })
        return c
    }

    private fun menuRow(iconRes: Int, title: String, sub: String, valueView: TextView?, onClick: () -> Unit): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(14), dp(4), dp(14))
        row.background = RippleDrawable(
            ColorStateList.valueOf(Color.argb(40, 255, 255, 255)), null, roundBg(Color.WHITE, 12)
        )
        row.setOnClickListener { onClick() }

        val icon = ImageView(this)
        icon.setImageResource(iconRes)
        icon.setColorFilter(Ui.accent)
        val ilp = LinearLayout.LayoutParams(dp(24), dp(24))
        ilp.rightMargin = dp(14)
        icon.layoutParams = ilp
        row.addView(icon)

        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        texts.addView(tv(title, 16f, Ui.text, true))
        texts.addView(tv(sub, 13f, Ui.dim))
        row.addView(texts)

        if (valueView != null) {
            valueView.setPadding(dp(8), 0, dp(6), 0)
            row.addView(valueView)
        }
        row.addView(tv("›", 24f, Ui.dim))
        return row
    }

    private fun whatsNewCard(): View {
        val latest = Changelog.releases.first()
        val c = card()
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(tv("What's New", 18f, Ui.text, true).apply {
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        })
        head.addView(tv("v${latest.version}", 12f, Ui.onAccent, true).apply {
            setPadding(dp(10), dp(3), dp(10), dp(3))
            background = roundBg(Ui.accent, 20)
        })
        c.addView(head)
        c.addView(tv(latest.title, 15f, Ui.accent, true).apply { setPadding(0, dp(8), 0, dp(6)) })
        latest.notes.forEach { note ->
            c.addView(tv("•  $note", 14f, Ui.text).apply { setPadding(0, dp(3), 0, dp(3)) })
        }
        c.addView(button("See all updates", Ui.field, Ui.text) { showWhatsNew(true) })
        return c
    }

    /* ================= Language ================= */
    private fun currentLanguageName(): String {
        val code = prefs.getString(Prefs.LANGUAGE, "en") ?: "en"
        return languages.firstOrNull { it.first == code }?.second ?: "English"
    }

    private fun showLanguageDialog() {
        val current = prefs.getString(Prefs.LANGUAGE, "en") ?: "en"
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(24), dp(8), dp(24), dp(8))
        val dialog = AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Language")
            .setView(box)
            .setNegativeButton("Close", null)
            .create()
        languages.forEach { (code, name) ->
            val selected = code == current
            val row = tv(if (selected) "$name   ✓" else name, 17f, if (selected) Ui.accent else Ui.text, selected)
            row.setPadding(0, dp(12), 0, dp(12))
            row.setOnClickListener {
                prefs.edit().putString(Prefs.LANGUAGE, code).apply()
                languageValue.text = name
                dialog.dismiss()
            }
            box.addView(row)
        }
        box.addView(tv("More languages are coming soon.", 13f, Ui.dim).apply { setPadding(0, dp(8), 0, dp(4)) })
        dialog.show()
    }

    /* ================= What's New ================= */
    private fun showWhatsNew(all: Boolean) {
        val list = if (all) Changelog.releases else listOf(Changelog.releases.first())
        val msg = list.joinToString("\n\n") { r ->
            "v${r.version}  ·  ${r.date}\n${r.title}\n" + r.notes.joinToString("\n") { "•  $it" }
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(if (all) "All updates" else "What's New in v${list[0].version}")
            .setMessage(msg)
            .setPositiveButton("Got it", null)
            .show()
    }

    /* ================= TRẠNG THÁI CÀI ĐẶT ================= */
    private fun refreshStatus() {
        if (!::enablePill.isInitialized) return
        setPill(enablePill, isEnabled())
        setPill(selectPill, isSelected())
    }

    private fun isEnabled(): Boolean {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        return imm.enabledInputMethodList.any { it.packageName == packageName }
    }

    private fun isSelected(): Boolean {
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD) ?: return false
        return cur.startsWith("$packageName/")
    }

    private fun setPill(v: TextView, done: Boolean) {
        v.text = if (done) "Done" else "To do"
        v.setTextColor(if (done) Ui.onAccent else Ui.dim)
        v.background = roundBg(if (done) Ui.accent else Ui.field, 20)
    }

    /** Một bước hướng dẫn; trả về nhãn trạng thái (Done / To do). */
    private fun step(parent: LinearLayout, n: Int, title: String, sub: String, btn: String, onClick: () -> Unit): TextView {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val hlp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        hlp.topMargin = dp(16)
        head.layoutParams = hlp

        val badge = tv(n.toString(), 14f, Ui.onAccent, true)
        badge.gravity = Gravity.CENTER
        badge.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Ui.accent)
        }
        val blp = LinearLayout.LayoutParams(dp(28), dp(28))
        blp.rightMargin = dp(12)
        badge.layoutParams = blp

        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        titles.addView(tv(title, 16f, Ui.text, true))
        titles.addView(tv(sub, 13f, Ui.dim))

        val pill = tv("", 12f, Ui.dim, true)
        pill.setPadding(dp(10), dp(3), dp(10), dp(3))

        head.addView(badge)
        head.addView(titles)
        head.addView(pill)
        parent.addView(head)
        parent.addView(button(btn, Ui.accent, Ui.onAccent, onClick))
        return pill
    }
}
