package com.example.mykeyboard

import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface

/** Một bộ màu có sẵn. */
class Palette(
    val id: String,
    val name: String,
    val background: Int,
    val key: Int,
    val special: Int,
    val keyPressed: Int,
    val text: Int,
    val dim: Int,
    val accent: Int,
    val bubble: Int
)

/** Bộ màu đầy đủ đã tính xong (đã áp màu nhấn người dùng chọn). */
class KbColors(
    val background: Int,
    val key: Int,
    val special: Int,
    val keyPressed: Int,
    val text: Int,
    val dim: Int,
    val accent: Int,
    val accentPressed: Int,
    val onAccent: Int,
    val shiftOn: Int,
    val bubble: Int
)

object Themes {
    private fun c(s: String): Int = Color.parseColor(s)

    val all: List<Palette> = listOf(
        Palette("midnight", "Midnight", c("#12141C"), c("#252A3B"), c("#1B1F2E"), c("#3B4363"), c("#E8EAF2"), c("#8E94AD"), c("#4FD1C5"), c("#4A5380")),
        Palette("aurora", "Aurora", c("#0C0F24"), c("#1E2350"), c("#151A3C"), c("#343C7A"), c("#EEF0FF"), c("#9AA0C8"), c("#22D3C5"), c("#4B45B8")),
        Palette("amoled", "AMOLED", c("#000000"), c("#17191F"), c("#0C0D10"), c("#2D313C"), c("#F2F3F7"), c("#7D8393"), c("#8AB4FF"), c("#2C3350")),
        Palette("ocean", "Ocean", c("#0B1F2E"), c("#153247"), c("#0F2738"), c("#24506E"), c("#E6F4FF"), c("#8FB0C7"), c("#4DB8FF"), c("#2A6A94")),
        Palette("forest", "Forest", c("#0F1D17"), c("#1B3328"), c("#14271F"), c("#2C5240"), c("#E8F5EC"), c("#8DB09B"), c("#6FD98A"), c("#2F6B4A")),
        Palette("sunset", "Sunset", c("#20141A"), c("#3A2230"), c("#2B1A24"), c("#5A3549"), c("#FFEDE8"), c("#C79BA0"), c("#FF8A65"), c("#8A4A5A")),
        Palette("rose", "Rose", c("#1E1218"), c("#34202B"), c("#271720"), c("#4D2F40"), c("#FCE8F0"), c("#C69AB0"), c("#FF6FB1"), c("#7A3556")),
        Palette("light", "Light", c("#E9ECF3"), c("#FFFFFF"), c("#D5DAE6"), c("#C3CAD9"), c("#1B1F2E"), c("#6B7287"), c("#2F7CF6"), c("#2F3A5C"))
    )

    val accents: List<Pair<String, Int>> = listOf(
        "Teal" to c("#4FD1C5"), "Blue" to c("#4DA3FF"), "Purple" to c("#A78BFA"), "Pink" to c("#FF6FB1"),
        "Orange" to c("#FF8A65"), "Green" to c("#6FD98A"), "Yellow" to c("#FFD166"), "Red" to c("#FF6B6B")
    )

    fun byId(id: String?): Palette = all.firstOrNull { it.id == id } ?: all[0]

    fun colors(p: Palette, accentOverride: Int): KbColors {
        val accent = if (accentOverride != 0) accentOverride else p.accent
        return KbColors(
            p.background, p.key, p.special, p.keyPressed, p.text, p.dim,
            accent, scale(accent, 0.78f), onColorFor(accent), mix(p.special, accent, 0.4f), p.bubble
        )
    }

    fun colors(prefs: SharedPreferences): KbColors =
        colors(byId(prefs.getString(Prefs.THEME, "midnight")), prefs.getInt(Prefs.ACCENT, 0))

    private fun scale(color: Int, f: Float): Int = Color.rgb(
        (Color.red(color) * f).toInt(),
        (Color.green(color) * f).toInt(),
        (Color.blue(color) * f).toInt()
    )

    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )

    /** Chữ trên nền màu nhấn: tối nếu nền sáng, trắng nếu nền tối. */
    private fun onColorFor(color: Int): Int {
        val lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0
        return if (lum > 0.6) Color.parseColor("#0B1F1D") else Color.WHITE
    }
}

/** Các kiểu chữ có sẵn trên Android (không cần tải thêm). */
object KbFonts {
    val names = listOf("Default", "Light", "Medium", "Condensed", "Serif", "Mono", "Casual", "Cursive", "Black")
    private val families = listOf(
        "sans-serif", "sans-serif-light", "sans-serif-medium", "sans-serif-condensed",
        "serif", "monospace", "casual", "cursive", "sans-serif-black"
    )

    private fun family(i: Int): String = families[i.coerceIn(0, families.size - 1)]
    fun key(i: Int): Typeface = Typeface.create(family(i), Typeface.NORMAL)
    fun label(i: Int): Typeface = Typeface.create(family(i), Typeface.BOLD)
}

/** Các mức chỉnh bố cục bàn phím (chỉ số 0, 1, 2 lưu trong cài đặt). */
object KbLayout {
    val heightNames = listOf("Compact", "Normal", "Large")
    val rowDp = intArrayOf(44, 50, 56)
    val numDp = intArrayOf(36, 40, 44)

    val shapeNames = listOf("Square", "Rounded", "Round")
    val cornerDp = intArrayOf(4, 10, 16)

    val spacingNames = listOf("Tight", "Normal", "Wide")
    val marginDp = intArrayOf(2, 3, 4)

    val handNames = listOf("Off", "Left", "Right")
}
