package com.example.mykeyboard

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

object Ui {
    val card = Color.parseColor("#1B1F2E")
    val field = Color.parseColor("#252A3B")
    val accent = Color.parseColor("#4FD1C5")
    val onAccent = Color.parseColor("#06201D")
    val text = Color.parseColor("#E8EAF2")
    val dim = Color.parseColor("#8E94AD")
}

/** Các hàm dựng giao diện dùng chung cho màn hình chính và màn hình Settings. */
open class BaseActivity : Activity() {

    protected val prefs by lazy { Prefs.of(this) }

    protected fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    protected fun roundBg(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
    }

    protected fun tv(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    protected fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = roundBg(Ui.card, 16)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.bottomMargin = dp(12)
        c.layoutParams = lp
        return c
    }

    protected fun button(label: String, bg: Int, fg: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(fg)
        b.background = roundBg(bg, 12)
        b.stateListAnimator = null
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, dp(46))
        lp.topMargin = dp(12)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    protected fun switchRow(label: String, key: String): Switch {
        val s = Switch(this)
        s.text = label
        s.textSize = 16f
        s.setTextColor(Ui.text)
        s.setPadding(0, dp(12), 0, dp(10))
        s.isChecked = prefs.getBoolean(key, true)
        s.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        return s
    }

    protected fun seek(max: Int, init: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = max
        s.progress = init
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    /** Tiêu đề màn hình con: nút quay lại + tên màn hình. */
    protected fun backHeader(title: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.bottomMargin = dp(16)
        row.layoutParams = lp
        val back = tv("‹", 34f, Ui.text)
        back.setPadding(dp(4), 0, dp(18), dp(4))
        back.setOnClickListener { finish() }
        row.addView(back)
        row.addView(tv(title, 26f, Ui.text, true))
        return row
    }

    /** Nhãn nhỏ bo tròn, ví dụ "Coming soon". */
    protected fun pill(s: String): TextView {
        val t = tv(s, 12f, Ui.accent, true)
        t.setPadding(dp(10), dp(3), dp(10), dp(3))
        t.background = roundBg(Ui.field, 20)
        return t
    }

    protected fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }
}
