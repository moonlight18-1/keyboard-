package com.example.mykeyboard

import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView

object Ui {
    val bg = Color.parseColor("#0C0F24")
    val bg2 = Color.parseColor("#171A44")
    val card = Color.parseColor("#161A38")
    val field = Color.parseColor("#212650")
    val stroke = Color.parseColor("#262C5E")
    val accent = Color.parseColor("#22D3C5")
    val accent2 = Color.parseColor("#7C6CFF")
    val grad1 = Color.parseColor("#6A5CF0")
    val grad2 = Color.parseColor("#2E9BF0")
    val good = Color.parseColor("#3DDC97")
    val warn = Color.parseColor("#FFB020")
    val onAccent = Color.parseColor("#04201E")
    val text = Color.parseColor("#EEF0FF")
    val dim = Color.parseColor("#9AA0C8")
}

/** Các hàm dựng giao diện dùng chung cho mọi màn hình: thẻ, nút, công tắc, hiệu ứng chuyển động. */
open class BaseActivity : Activity() {

    protected val prefs by lazy { Prefs.of(this) }

    protected fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    protected fun roundBg(color: Int, radiusDp: Int) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
    }

    protected fun gradient(
        c1: Int, c2: Int, radiusDp: Int,
        orientation: GradientDrawable.Orientation = GradientDrawable.Orientation.TL_BR
    ) = GradientDrawable(orientation, intArrayOf(c1, c2)).apply {
        cornerRadius = dp(radiusDp).toFloat()
    }

    protected fun tv(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    /* ================= HIỆU ỨNG CHUYỂN ĐỘNG ================= */

    /** Nhấn vào thì thu nhỏ nhẹ, nhả ra thì bật lại. */
    protected fun <V : View> pressable(v: V): V {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90L).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(160L).start()
            }
            false
        }
        return v
    }

    /** Các khối trong màn hình lần lượt trượt lên và hiện dần khi mở. */
    protected fun staggerIn(group: ViewGroup, startDelay: Long = 0L) {
        val dy = dp(22).toFloat()
        for (i in 0 until group.childCount) {
            val c = group.getChildAt(i)
            c.alpha = 0f
            c.translationY = dy
            c.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(startDelay + i * 55L)
                .setDuration(380L)
                .setInterpolator(DecelerateInterpolator(1.8f))
                .start()
        }
    }

    /** Mở màn hình khác với hiệu ứng trượt. */
    protected fun go(i: Intent) {
        startActivity(i)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    /* ================= THÀNH PHẦN GIAO DIỆN ================= */

    protected fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(Ui.card)
            setStroke(dp(1), Ui.stroke)
        }
        c.setPadding(dp(18), dp(18), dp(18), dp(18))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.bottomMargin = dp(14)
        c.layoutParams = lp
        return c
    }

    /** Nút: bg = Ui.accent thì thành nút chính (gradient tím → xanh, chữ trắng). */
    protected fun button(label: String, bg: Int, fg: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.typeface = Typeface.DEFAULT_BOLD
        val primary = bg == Ui.accent
        b.setTextColor(if (primary) Color.WHITE else fg)
        b.background = if (primary) {
            gradient(Ui.grad1, Ui.grad2, 14, GradientDrawable.Orientation.LEFT_RIGHT)
        } else {
            roundBg(bg, 14)
        }
        b.stateListAnimator = null
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, dp(48))
        lp.topMargin = dp(12)
        b.layoutParams = lp
        pressable(b)
        b.setOnClickListener { onClick() }
        return b
    }

    protected fun switchRow(label: String, key: String): Switch {
        val s = Switch(this)
        s.text = label
        s.textSize = 15f
        s.setTextColor(Ui.text)
        s.setPadding(0, dp(12), 0, dp(10))
        s.isChecked = prefs.getBoolean(key, true)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        s.thumbTintList = ColorStateList(states, intArrayOf(Ui.accent, Ui.dim))
        s.trackTintList = ColorStateList(
            states, intArrayOf((Ui.accent and 0x00FFFFFF) or (0x66 shl 24), Ui.field)
        )
        s.setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
        return s
    }

    protected fun seek(max: Int, init: Int, onChange: (Int) -> Unit): SeekBar {
        val s = SeekBar(this)
        s.max = max
        s.progress = init
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        return s
    }

    /** Hàng nút chọn một trong nhiều mức (Compact / Normal / Large...). */
    protected fun segment(options: List<String>, selected: Int, onSelect: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.background = roundBg(Ui.field, 14)
        row.setPadding(dp(3), dp(3), dp(3), dp(3))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, dp(44))
        lp.topMargin = dp(4)
        row.layoutParams = lp
        val cells = ArrayList<TextView>()
        fun paint(sel: Int) {
            cells.forEachIndexed { i, t ->
                val on = i == sel
                t.setTextColor(if (on) Color.WHITE else Ui.dim)
                t.background = if (on) {
                    gradient(Ui.grad1, Ui.grad2, 12, GradientDrawable.Orientation.LEFT_RIGHT)
                } else {
                    null
                }
            }
        }
        options.forEachIndexed { i, name ->
            val t = tv(name, 14f, Ui.text, true)
            t.gravity = Gravity.CENTER
            t.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            t.setOnClickListener {
                paint(i)
                onSelect(i)
            }
            cells.add(t)
            row.addView(t)
        }
        paint(selected)
        return row
    }

    /** Nhãn nhỏ bo tròn, ví dụ "Coming soon". */
    protected fun pill(s: String): TextView {
        val t = tv(s, 12f, Ui.accent, true)
        t.setPadding(dp(10), dp(3), dp(10), dp(3))
        t.background = roundBg(Ui.field, 20)
        return t
    }

    /** Biểu tượng trắng trong vòng tròn gradient. */
    protected fun iconBadge(iconRes: Int, c1: Int, c2: Int, sizeDp: Int): ImageView {
        val iv = ImageView(this)
        iv.setImageResource(iconRes)
        iv.setColorFilter(Color.WHITE)
        val pad = dp(sizeDp / 4)
        iv.setPadding(pad, pad, pad, pad)
        val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
        g.shape = GradientDrawable.OVAL
        iv.background = g
        iv.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        return iv
    }

    /** Tiêu đề của một khối: biểu tượng + tên. */
    protected fun sectionTitle(iconRes: Int, text: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(iconBadge(iconRes, Ui.grad1, Ui.grad2, 32))
        val t = tv(text, 18f, Ui.text, true)
        t.setPadding(dp(12), 0, 0, 0)
        row.addView(t)
        return row
    }

    /** Tiêu đề màn hình con: nút quay lại + tên màn hình. */
    protected fun backHeader(title: String): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.bottomMargin = dp(18)
        row.layoutParams = lp
        val back = tv("‹", 28f, Ui.text)
        back.gravity = Gravity.CENTER
        back.background = roundBg(Ui.field, 20)
        val blp = LinearLayout.LayoutParams(dp(42), dp(42))
        blp.rightMargin = dp(14)
        back.layoutParams = blp
        back.setOnClickListener { finish() }
        pressable(back)
        row.addView(back)
        row.addView(tv(title, 26f, Ui.text, true))
        return row
    }

    protected fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }
}
