package com.example.mykeyboard

import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout

/** Thanh tiến trình nhỏ: nền mờ + phần đã tải tô gradient tím -> ngọc. */
private class LoadingBar(ctx: Context) : View(ctx) {
    var progress = 0f
        set(v) {
            field = v
            invalidate()
        }
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.field }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        fill.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, Ui.accent2, Ui.accent, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val r = height / 2f
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, r, r, track)
        val w = width * progress
        if (w > 0f) {
            rect.set(0f, 0f, w, height.toFloat())
            canvas.drawRoundRect(rect, r, r, fill)
        }
    }
}

/** Màn hình chờ khi mở app: logo hiện dần, thanh loading chạy rồi chuyển sang màn hình chính. */
class SplashActivity : BaseActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var opened = false
    private var loader: ValueAnimator? = null
    private val goNext = Runnable { openMain() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Ui.bg, Ui.bg2))

        val center = LinearLayout(this)
        center.orientation = LinearLayout.VERTICAL
        center.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(center, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.CENTER))

        val icon = ImageView(this)
        icon.setImageResource(R.mipmap.ic_launcher)
        icon.layoutParams = LinearLayout.LayoutParams(dp(120), dp(120))
        center.addView(icon)

        val title = tv("ML Keyboard", 28f, Ui.text, true)
        title.letterSpacing = 0.03f
        title.setPadding(0, dp(20), 0, 0)
        center.addView(title)

        val tagline = tv("Type smooth. Look great.", 14f, Ui.dim)
        tagline.setPadding(0, dp(6), 0, 0)
        center.addView(tagline)

        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.VERTICAL
        bottom.gravity = Gravity.CENTER_HORIZONTAL
        bottom.addView(tv("Loading…", 12f, Ui.dim))
        val bar = LoadingBar(this)
        val barLp = LinearLayout.LayoutParams(dp(160), dp(4))
        barLp.topMargin = dp(10)
        bar.layoutParams = barLp
        bottom.addView(bar)
        val bottomLp = FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        bottomLp.bottomMargin = dp(72)
        root.addView(bottom, bottomLp)

        root.setOnClickListener { openMain() }   // chạm để bỏ qua
        setContentView(root)

        // Hiệu ứng xuất hiện
        icon.alpha = 0f
        icon.scaleX = 0.6f
        icon.scaleY = 0.6f
        icon.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(600).setInterpolator(OvershootInterpolator(1.3f)).start()
        title.alpha = 0f
        title.translationY = dp(14).toFloat()
        title.animate().alpha(1f).translationY(0f)
            .setStartDelay(250).setDuration(420).setInterpolator(DecelerateInterpolator()).start()
        tagline.alpha = 0f
        tagline.translationY = dp(10).toFloat()
        tagline.animate().alpha(1f).translationY(0f)
            .setStartDelay(380).setDuration(420).setInterpolator(DecelerateInterpolator()).start()
        bottom.alpha = 0f
        bottom.animate().alpha(1f).setStartDelay(300).setDuration(300).start()

        val anim = ValueAnimator.ofFloat(0f, 1f)
        anim.duration = 950
        anim.startDelay = 300
        anim.interpolator = AccelerateDecelerateInterpolator()
        anim.addUpdateListener { bar.progress = it.animatedValue as Float }
        anim.start()
        loader = anim

        handler.postDelayed(goNext, 1450)
    }

    private fun openMain() {
        if (opened) return
        opened = true
        startActivity(Intent(this, MainActivity::class.java))
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacks(goNext)
        loader?.cancel()
        super.onDestroy()
    }
}
