package com.example.mykeyboard

import android.content.Context
import android.content.SharedPreferences

/** Cài đặt dùng chung giữa app cài đặt và bàn phím. */
object Prefs {
    const val VIBRATE = "vibrate"
    const val VIB_STRENGTH = "vib_strength"   // 1..10
    const val SOUND = "sound"
    const val SOUND_VOLUME = "sound_volume"   // 0..10
    const val POPUP = "popup"
    const val RECENT = "recent_emoji"
    const val CLIPS = "clips"
    const val CLIP_ENABLED = "clip_enabled"
    const val LANGUAGE = "language"
    const val THEME = "theme_id"
    const val ACCENT = "accent_color"          // 0 = theo bộ màu
    const val KEY_HEIGHT = "key_height"        // 0..2
    const val KEY_SHAPE = "key_shape"          // 0..2
    const val KEY_SPACING = "key_spacing"      // 0..2
    const val ONE_HAND = "one_hand"            // 0 tắt, 1 trái, 2 phải

    fun of(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("kb_prefs", Context.MODE_PRIVATE)
}
