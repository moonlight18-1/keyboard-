package com.example.mykeyboard

import android.content.Context
import android.content.SharedPreferences

/** Cài đặt dùng chung giữa app cài đặt và bàn phím. */
object Prefs {
    const val VIBRATE = "vibrate"
    const val VIB_STRENGTH = "vib_strength"   // 1..10
    const val SOUND = "sound"
    const val SOUND_VOLUME = "sound_volume"   // 0..10
    const val POPUP = "popup"
    const val RECENT = "recent_emoji"
    const val CLIPS = "clips"
    const val CLIP_ENABLED = "clip_enabled"
    const val LANGUAGE = "language"
    const val TR_ON = "tr_on"                  // hiện nút dịch trên thanh công cụ
    const val TR_FROM = "tr_from"
    const val TR_TO = "tr_to"
    const val FONT = "key_font"                // 0..8
    const val VID_ON = "vid_on"                // dùng video làm nền
    const val VID_VER = "vid_ver"
    const val VID_ALIGN = "vid_align"          // 0 trên, 1 giữa, 2 dưới
    const val BG_ON = "bg_on"                  // dùng ảnh nền
    const val BG_VER = "bg_ver"                // đổi mỗi khi có ảnh mới
    const val BG_DIM = "bg_dim"                // 0..7
    const val BG_KEY_ALPHA = "bg_key_alpha"    // 3..10
    const val THEME = "theme_id"
    const val ACCENT = "accent_color"          // 0 = theo bộ màu
    const val KEY_HEIGHT = "key_height"        // 0..2
    const val KEY_SHAPE = "key_shape"          // 0..2
    const val KEY_SPACING = "key_spacing"      // 0..2
    const val ANIM = "appear_anim"             // hiệu ứng khi bàn phím hiện
    const val ONE_HAND = "one_hand"            // 0 tắt, 1 trái, 2 phải

    fun of(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("kb_prefs", Context.MODE_PRIVATE)
}
