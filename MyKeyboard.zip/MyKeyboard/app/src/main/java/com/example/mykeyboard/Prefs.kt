package com.example.mykeyboard

import android.content.Context
import android.content.SharedPreferences

/** Cài đặt dùng chung giữa app cài đặt và bàn phím. */
object Prefs {
    const val VIBRATE = "vibrate"
    const val VIB_STRENGTH = "vib_strength"   // 1..10
    const val SOUND = "sound"
    const val SOUND_VOLUME = "sound_volume"   // 0..10
    const val POPUP = "popup"
    const val RECENT = "recent_emoji"
    const val CLIPS = "clips"
    const val CLIP_ENABLED = "clip_enabled"
    const val LANGUAGE = "language"

    fun of(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("kb_prefs", Context.MODE_PRIVATE)
}
