package com.example.mykeyboard

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Ô chọn bộ màu: nền, vài phím mẫu, chấm màu nhấn và tên. */
private class SwatchView(ctx: Context, val palette: Palette, private val density: Float) : View(ctx) {
    var chosen = false
        set(v) {
            field = v
            invalidate()
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f * density
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 12f * density
        fill.color = palette.background
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, fill)

        val gap = 5f * density
        val kw = (w - 16f * density - 2f * gap) / 3f
        var x = 8f * density
        val ky = 9f * density
        val kh = 14f * density
        for (i in 0 until 3) {
            fill.color = if (i == 2) palette.accent else palette.key
            rect.set(x, ky, x + kw, ky + kh)
            canvas.drawRoundRect(rect, 4f * density, 4f * density, fill)
            x += kw + gap
        }
        label.color = palette.text
        canvas.drawText(palette.name, 8f * density, h - 9f * density, label)

        if (chosen) {
            val half = ring.strokeWidth / 2f
            ring.color = Ui.accent
            rect.set(half, half, w - half, h - half)
            canvas.drawRoundRect(rect, r, r, ring)
        }
    }
}

/** Chấm tròn chọn màu nhấn. */
private class DotView(ctx: Context, val color: Int, private val density: Float) : View(ctx) {
    var chosen = false
        set(v) {
            field = v
            invalidate()
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val rad = minOf(width, height) / 2f - 6f * density
        fill.color = color
        canvas.drawCircle(cx, cy, rad, fill)
        if (chosen) {
            ring.color = Ui.text
            canvas.drawCircle(cx, cy, rad + 3.5f * density, ring)
        }
    }
}

/** Keyboard: kiểu nhanh, màu, kiểu phím, phông chữ, bố cục. */
class KeyboardActivity : BaseActivity() {

    private class Preset(
        val name: String, val theme: String, val accent: Int,
        val height: Int, val shape: Int, val spacing: Int, val font: Int, val style: Int, val text: Int
    )

    private val presets = listOf(
        Preset("Classic", "midnight", 0, 1, 1, 1, 0, 0, 1),
        Preset("Neon", "aurora", 0, 1, 2, 2, 2, 2, 1),
        Preset("Minimal", "light", 0, 1, 0, 0, 1, 0, 1),
        Preset("Cute", "rose", 0, 1, 2, 2, 6, 0, 2),
        Preset("Hacker", "amoled", Themes.accents[5].second, 1, 0, 0, 5, 1, 1),
        Preset("Glass", "ocean", 0, 1, 1, 1, 0, 2, 1)
    )

    private lateinit var preview: KeyboardPreview
    private lateinit var autoPill: TextView
    private val swatches = mutableListOf<SwatchView>()
    private val dots = mutableListOf<DotView>()
    private val fontCells = mutableListOf<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build(true)
    }

    private fun build(animate: Boolean) {
        swatches.clear()
        dots.clear()
        fontCells.clear()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(28), dp(16), dp(24))
        }
        col.addView(backHeader("Keyboard"))
        col.addView(previewCard())
        col.addView(presetsCard())
        col.addView(backgroundEntry())
        col.addView(colorsCard())
        col.addView(styleCard())
        col.addView(fontCard())
        col.addView(layoutCard())
        col.addView(button("Reset to default", Ui.field, Ui.text) {
            prefs.edit()
                .remove(Prefs.THEME)
                .remove(Prefs.ACCENT)
                .remove(Prefs.KEY_HEIGHT)
                .remove(Prefs.KEY_SHAPE)
                .remove(Prefs.KEY_SPACING)
                .remove(Prefs.ONE_HAND)
                .remove(Prefs.FONT)
                .remove(Prefs.KEY_STYLE)
                .remove(Prefs.KEY_TEXT)
                .apply()
            build(false)
        })
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
        refreshPreview()
        if (animate) staggerIn(col)
    }

    private fun label(s: String): TextView = tv(s, 13f, Ui.dim).apply { setPadding(0, dp(14), 0, dp(4)) }

    private fun setInt(key: String, v: Int) {
        prefs.edit().putInt(key, v).apply()
        refreshPreview()
    }

    /* ================= XEM TRƯỚC ================= */
    private fun previewCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_keyboard, "Preview"))
        preview = KeyboardPreview(this, resources.displayMetrics.density)
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.topMargin = dp(12)
        preview.layoutParams = lp
        c.addView(preview)
        c.addView(tv("Open the keyboard below to try your changes for real.", 13f, Ui.dim).apply {
            setPadding(0, dp(10), 0, dp(8))
        })
        c.addView(EditText(this).apply {
            hint = "Type here to test"
            setHintTextColor(Ui.dim)
            setTextColor(Ui.text)
            background = roundBg(Ui.field, 14)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        })
        return c
    }

    private fun refreshPreview() {
        preview.update(
            Themes.colors(prefs),
            prefs.getInt(Prefs.KEY_HEIGHT, 1),
            prefs.getInt(Prefs.KEY_SHAPE, 1),
            prefs.getInt(Prefs.KEY_SPACING, 1),
            prefs.getInt(Prefs.ONE_HAND, 0),
            prefs.getInt(Prefs.FONT, 0),
            prefs.getInt(Prefs.KEY_STYLE, 0),
            prefs.getInt(Prefs.KEY_TEXT, 1)
        )
        preview.alpha = 0.55f
        preview.animate().alpha(1f).setDuration(220L).start()
    }

    /* ================= KIỂU NHANH ================= */
    private fun presetsCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_emoji, "Quick styles"))
        c.addView(tv("One tap sets colors, font, shape and key style together.", 13f, Ui.dim).apply {
            setPadding(0, dp(8), 0, dp(12))
        })
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        presets.forEach { p ->
            val pal = Themes.byId(p.theme)
            val accent = if (p.accent != 0) p.accent else pal.accent
            val chip = TextView(this)
            chip.text = p.name
            chip.gravity = Gravity.CENTER
            chip.textSize = 14f
            chip.typeface = Typeface.DEFAULT_BOLD
            val light = p.theme == "light"
            chip.setTextColor(if (light) Color.parseColor("#1B1F2E") else Color.WHITE)
            chip.background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(if (light) pal.key else pal.background, accent)
            ).apply { cornerRadius = dp(16).toFloat() }
            val lp = LinearLayout.LayoutParams(dp(104), dp(64))
            lp.rightMargin = dp(10)
            chip.layoutParams = lp
            chip.setOnClickListener { applyPreset(p) }
            pressable(chip)
            row.addView(chip)
        }
        scroll.addView(row)
        c.addView(scroll)
        return c
    }

    private fun applyPreset(p: Preset) {
        prefs.edit()
            .putString(Prefs.THEME, p.theme)
            .putInt(Prefs.ACCENT, p.accent)
            .putInt(Prefs.KEY_HEIGHT, p.height)
            .putInt(Prefs.KEY_SHAPE, p.shape)
            .putInt(Prefs.KEY_SPACING, p.spacing)
            .putInt(Prefs.FONT, p.font)
            .putInt(Prefs.KEY_STYLE, p.style)
            .putInt(Prefs.KEY_TEXT, p.text)
            .apply()
        build(false)
    }

    /* ================= ẢNH / VIDEO NỀN ================= */
    private fun backgroundEntry(): View {
        val c = card()
        c.setOnClickListener { go(Intent(this, BackgroundActivity::class.java)) }
        pressable(c)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(iconBadge(R.drawable.ic_image, Color.parseColor("#D946EF"), Color.parseColor("#6A5CF0"), 44))
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.setPadding(dp(14), 0, 0, 0)
        texts.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        texts.addView(tv("Background", 18f, Ui.text, true))
        texts.addView(tv("Photo or video from your gallery", 13f, Ui.dim))
        row.addView(texts)
        row.addView(tv("›", 26f, Ui.dim))
        c.addView(row)
        return c
    }

    /* ================= MÀU ================= */
    private fun colorsCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_emoji, "Colors"))
        c.addView(label("Theme"))
        c.addView(themeGrid())
        c.addView(label("Accent color"))
        c.addView(accentRow())
        return c
    }

    private fun themeGrid(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val current = prefs.getString(Prefs.THEME, "midnight") ?: "midnight"
        val perRow = 4
        val density = resources.displayMetrics.density
        Themes.all.chunked(perRow).forEach { rowItems ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            rowItems.forEach { p ->
                val sw = SwatchView(this, p, density)
                sw.chosen = p.id == current
                val lp = LinearLayout.LayoutParams(0, dp(64), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                sw.layoutParams = lp
                sw.setOnClickListener {
                    prefs.edit().putString(Prefs.THEME, p.id).apply()
                    swatches.forEach { s -> s.chosen = s.palette.id == p.id }
                    refreshPreview()
                }
                pressable(sw)
                swatches.add(sw)
                row.addView(sw)
            }
            repeat(perRow - rowItems.size) {
                val filler = View(this)
                filler.layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f)
                row.addView(filler)
            }
            box.addView(row)
        }
        return box
    }

    private fun accentRow(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(42))

        autoPill = tv("Auto", 12f, Ui.text, true)
        autoPill.gravity = Gravity.CENTER
        autoPill.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1.4f)
        autoPill.setOnClickListener { setAccent(0) }
        row.addView(autoPill)

        val density = resources.displayMetrics.density
        Themes.accents.forEach { (_, color) ->
            val d = DotView(this, color, density)
            d.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            d.setOnClickListener { setAccent(color) }
            dots.add(d)
            row.addView(d)
        }
        paintAccent(prefs.getInt(Prefs.ACCENT, 0))
        return row
    }

    private fun setAccent(color: Int) {
        prefs.edit().putInt(Prefs.ACCENT, color).apply()
        paintAccent(color)
        refreshPreview()
    }

    private fun paintAccent(current: Int) {
        autoPill.setTextColor(if (current == 0) Color.WHITE else Ui.text)
        autoPill.background = if (current == 0) {
            gradient(Ui.grad1, Ui.grad2, 20, GradientDrawable.Orientation.LEFT_RIGHT)
        } else {
            roundBg(Ui.field, 20)
        }
        dots.forEach { it.chosen = it.color == current }
    }

    /* ================= KIỂU PHÍM ================= */
    private fun styleCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_keyboard, "Key style"))
        c.addView(label("Look"))
        c.addView(segment(listOf("Solid", "Outline", "Glass"), prefs.getInt(Prefs.KEY_STYLE, 0)) {
            setInt(Prefs.KEY_STYLE, it)
        })
        c.addView(label("Letter size"))
        c.addView(segment(listOf("Small", "Normal", "Large"), prefs.getInt(Prefs.KEY_TEXT, 1)) {
            setInt(Prefs.KEY_TEXT, it)
        })
        return c
    }

    /* ================= PHÔNG CHỮ ================= */
    private fun fontCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_edit, "Font"))
        c.addView(label("Key font style"))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        KbFonts.names.chunked(3).forEachIndexed { r, rowNames ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            rowNames.forEachIndexed { k, name ->
                val idx = r * 3 + k
                val cell = TextView(this)
                cell.gravity = Gravity.CENTER
                cell.text = fontLabel(name)
                cell.typeface = KbFonts.key(idx)
                val lp = LinearLayout.LayoutParams(0, dp(66), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                cell.layoutParams = lp
                cell.setOnClickListener {
                    prefs.edit().putInt(Prefs.FONT, idx).apply()
                    paintFonts(idx)
                    refreshPreview()
                }
                pressable(cell)
                fontCells.add(cell)
                row.addView(cell)
            }
            box.addView(row)
        }
        paintFonts(prefs.getInt(Prefs.FONT, 0))
        c.addView(box)
        return c
    }

    private fun fontLabel(name: String): CharSequence {
        val sb = SpannableStringBuilder("Aa\n" + name)
        sb.setSpan(AbsoluteSizeSpan(22, true), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(AbsoluteSizeSpan(11, true), 3, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun paintFonts(sel: Int) {
        fontCells.forEachIndexed { i, t ->
            val on = i == sel
            t.setTextColor(if (on) Color.WHITE else Ui.text)
            t.background = if (on) {
                gradient(Ui.grad1, Ui.grad2, 14, GradientDrawable.Orientation.TL_BR)
            } else {
                roundBg(Ui.field, 14)
            }
        }
    }

    /* ================= BỐ CỤC ================= */
    private fun layoutCard(): View {
        val c = card()
        c.addView(sectionTitle(R.drawable.ic_settings, "Layout"))
        c.addView(label("Key height"))
        c.addView(segment(KbLayout.heightNames, prefs.getInt(Prefs.KEY_HEIGHT, 1)) { setInt(Prefs.KEY_HEIGHT, it) })
        c.addView(label("Key shape"))
        c.addView(segment(KbLayout.shapeNames, prefs.getInt(Prefs.KEY_SHAPE, 1)) { setInt(Prefs.KEY_SHAPE, it) })
        c.addView(label("Key spacing"))
        c.addView(segment(KbLayout.spacingNames, prefs.getInt(Prefs.KEY_SPACING, 1)) { setInt(Prefs.KEY_SPACING, it) })
        c.addView(label("One-handed mode"))
        c.addView(segment(KbLayout.handNames, prefs.getInt(Prefs.ONE_HAND, 0)) { setInt(Prefs.ONE_HAND, it) })
        return c
    }
}
