package com.example.mykeyboard

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Ô chọn bộ màu: nền, vài phím mẫu, chấm màu nhấn và tên. */
private class SwatchView(ctx: Context, val palette: Palette, private val density: Float) : View(ctx) {
    var chosen = false
        set(v) {
            field = v
            invalidate()
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f * density
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 12f * density
        fill.color = palette.background
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, fill)

        val gap = 5f * density
        val kw = (w - 16f * density - 2f * gap) / 3f
        var x = 8f * density
        val ky = 9f * density
        val kh = 14f * density
        for (i in 0 until 3) {
            fill.color = if (i == 2) palette.accent else palette.key
            rect.set(x, ky, x + kw, ky + kh)
            canvas.drawRoundRect(rect, 4f * density, 4f * density, fill)
            x += kw + gap
        }
        label.color = palette.text
        canvas.drawText(palette.name, 8f * density, h - 9f * density, label)

        if (chosen) {
            val half = ring.strokeWidth / 2f
            ring.color = Ui.accent
            rect.set(half, half, w - half, h - half)
            canvas.drawRoundRect(rect, r, r, ring)
        }
    }
}

/** Chấm tròn chọn màu nhấn. */
private class DotView(ctx: Context, val color: Int, private val density: Float) : View(ctx) {
    var chosen = false
        set(v) {
            field = v
            invalidate()
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val rad = minOf(width, height) / 2f - 6f * density
        fill.color = color
        canvas.drawCircle(cx, cy, rad, fill)
        if (chosen) {
            ring.color = Ui.text
            canvas.drawCircle(cx, cy, rad + 3.5f * density, ring)
        }
    }
}

/** Keyboard: chọn màu, đổi kích thước phím, kiểu phím và chế độ một tay. */
class KeyboardActivity : BaseActivity() {

    private lateinit var preview: KeyboardPreview
    private lateinit var autoPill: TextView
    private val swatches = mutableListOf<SwatchView>()
    private val dots = mutableListOf<DotView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        col.addView(backHeader("Keyboard"))
        col.addView(previewCard())
        col.addView(backgroundEntry())
        col.addView(colorsCard())
        col.addView(fontCard())
        col.addView(layoutCard())
        col.addView(button("Reset to default", Ui.field, Ui.text) {
            prefs.edit()
                .remove(Prefs.THEME)
                .remove(Prefs.ACCENT)
                .remove(Prefs.KEY_HEIGHT)
                .remove(Prefs.KEY_SHAPE)
                .remove(Prefs.KEY_SPACING)
                .remove(Prefs.ONE_HAND)
                .remove(Prefs.FONT)
                .apply()
            recreate()
        })
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
        refreshPreview()
    }

    private fun previewCard(): View {
        val c = card()
        c.addView(tv("Preview", 18f, Ui.text, true))
        preview = KeyboardPreview(this, resources.displayMetrics.density)
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        preview.layoutParams = lp
        c.addView(preview)
        c.addView(tv("Open the keyboard below to try your changes for real.", 13f, Ui.dim).apply {
            setPadding(0, dp(10), 0, dp(8))
        })
        c.addView(EditText(this).apply {
            hint = "Type here to test"
            setHintTextColor(Ui.dim)
            setTextColor(Ui.text)
            background = roundBg(Ui.field, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        })
        return c
    }

    private fun refreshPreview() {
        preview.update(
            Themes.colors(prefs),
            prefs.getInt(Prefs.KEY_HEIGHT, 1),
            prefs.getInt(Prefs.KEY_SHAPE, 1),
            prefs.getInt(Prefs.KEY_SPACING, 1),
            prefs.getInt(Prefs.ONE_HAND, 0),
            prefs.getInt(Prefs.FONT, 0)
        )
    }

    /* ================= MÀU ================= */
    private fun colorsCard(): View {
        val c = card()
        c.addView(tv("Colors", 18f, Ui.text, true))
        c.addView(label("Theme"))
        c.addView(themeGrid())
        c.addView(label("Accent color"))
        c.addView(accentRow())
        return c
    }

    private fun label(s: String): TextView = tv(s, 13f, Ui.dim).apply { setPadding(0, dp(12), 0, dp(4)) }

    private fun themeGrid(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val current = prefs.getString(Prefs.THEME, "midnight") ?: "midnight"
        val perRow = 4
        val density = resources.displayMetrics.density
        Themes.all.chunked(perRow).forEach { rowItems ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            rowItems.forEach { p ->
                val sw = SwatchView(this, p, density)
                sw.chosen = p.id == current
                val lp = LinearLayout.LayoutParams(0, dp(62), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                sw.layoutParams = lp
                sw.setOnClickListener {
                    prefs.edit().putString(Prefs.THEME, p.id).apply()
                    swatches.forEach { s -> s.chosen = s.palette.id == p.id }
                    refreshPreview()
                }
                swatches.add(sw)
                row.addView(sw)
            }
            repeat(perRow - rowItems.size) {
                val filler = View(this)
                filler.layoutParams = LinearLayout.LayoutParams(0, dp(62), 1f)
                row.addView(filler)
            }
            box.addView(row)
        }
        return box
    }

    private fun accentRow(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(40))

        autoPill = tv("Auto", 12f, Ui.text, true)
        autoPill.gravity = Gravity.CENTER
        autoPill.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1.4f)
        autoPill.setOnClickListener { setAccent(0) }
        row.addView(autoPill)

        val density = resources.displayMetrics.density
        Themes.accents.forEach { (_, color) ->
            val d = DotView(this, color, density)
            d.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            d.setOnClickListener { setAccent(color) }
            dots.add(d)
            row.addView(d)
        }
        paintAccent(prefs.getInt(Prefs.ACCENT, 0))
        return row
    }

    private fun setAccent(color: Int) {
        prefs.edit().putInt(Prefs.ACCENT, color).apply()
        paintAccent(color)
        refreshPreview()
    }

    private fun paintAccent(current: Int) {
        autoPill.setTextColor(if (current == 0) Ui.onAccent else Ui.text)
        autoPill.background = roundBg(if (current == 0) Ui.accent else Ui.field, 20)
        dots.forEach { it.chosen = it.color == current }
    }

    /* ================= ẢNH NỀN (mục riêng) ================= */
    private fun backgroundEntry(): View {
        val c = card()
        c.setOnClickListener { startActivity(Intent(this, BackgroundActivity::class.java)) }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        texts.addView(tv("Background", 18f, Ui.text, true))
        texts.addView(tv("Photo from your gallery · Video coming soon", 13f, Ui.dim))
        row.addView(texts)
        row.addView(tv("›", 26f, Ui.dim))
        c.addView(row)
        return c
    }

    /* ================= PHÔNG CHỮ ================= */
    private val fontCells = mutableListOf<TextView>()

    private fun fontCard(): View {
        val c = card()
        c.addView(tv("Font", 18f, Ui.text, true))
        c.addView(label("Key font style"))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        KbFonts.names.chunked(3).forEachIndexed { r, rowNames ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            rowNames.forEachIndexed { k, name ->
                val idx = r * 3 + k
                val cell = TextView(this)
                cell.gravity = Gravity.CENTER
                cell.text = fontLabel(name)
                cell.typeface = KbFonts.key(idx)
                val lp = LinearLayout.LayoutParams(0, dp(64), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                cell.layoutParams = lp
                cell.setOnClickListener {
                    prefs.edit().putInt(Prefs.FONT, idx).apply()
                    paintFonts(idx)
                    refreshPreview()
                }
                fontCells.add(cell)
                row.addView(cell)
            }
            box.addView(row)
        }
        paintFonts(prefs.getInt(Prefs.FONT, 0))
        c.addView(box)
        return c
    }

    private fun fontLabel(name: String): CharSequence {
        val sb = SpannableStringBuilder("Aa\n" + name)
        sb.setSpan(AbsoluteSizeSpan(22, true), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.setSpan(AbsoluteSizeSpan(11, true), 3, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return sb
    }

    private fun paintFonts(sel: Int) {
        fontCells.forEachIndexed { i, t ->
            val on = i == sel
            t.setTextColor(if (on) Ui.onAccent else Ui.text)
            t.background = roundBg(if (on) Ui.accent else Ui.field, 12)
        }
    }

    /* ================= BỐ CỤC ================= */
    private fun layoutCard(): View {
        val c = card()
        c.addView(tv("Layout", 18f, Ui.text, true))
        c.addView(label("Key height"))
        c.addView(segment(KbLayout.heightNames, prefs.getInt(Prefs.KEY_HEIGHT, 1)) { setInt(Prefs.KEY_HEIGHT, it) })
        c.addView(label("Key shape"))
        c.addView(segment(KbLayout.shapeNames, prefs.getInt(Prefs.KEY_SHAPE, 1)) { setInt(Prefs.KEY_SHAPE, it) })
        c.addView(label("Key spacing"))
        c.addView(segment(KbLayout.spacingNames, prefs.getInt(Prefs.KEY_SPACING, 1)) { setInt(Prefs.KEY_SPACING, it) })
        c.addView(label("One-handed mode"))
        c.addView(segment(KbLayout.handNames, prefs.getInt(Prefs.ONE_HAND, 0)) { setInt(Prefs.ONE_HAND, it) })
        return c
    }

    private fun setInt(key: String, v: Int) {
        prefs.edit().putInt(key, v).apply()
        refreshPreview()
    }
}
