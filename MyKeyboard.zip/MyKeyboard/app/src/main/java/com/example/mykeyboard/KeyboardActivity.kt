package com.example.mykeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Một phím trong bản xem trước. style: 0 phím thường, 1 phím đặc biệt, 2 nhấn, 3 chỗ trống, 4 chip, 5 nút thanh công cụ. */
private class PK(val w: Float, val label: String, val style: Int)

/** Bản xem trước thu nhỏ của bàn phím, vẽ theo đúng màu và bố cục đang chọn. */
private class KeyboardPreview(ctx: Context, private val density: Float) : View(ctx) {
    private var c: KbColors = Themes.colors(Themes.all[0], 0)
    private var hIdx = 1
    private var sIdx = 1
    private var gIdx = 1
    private var oIdx = 0
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val rect = RectF()

    fun update(colors: KbColors, height: Int, shape: Int, spacing: Int, hand: Int) {
        c = colors
        hIdx = height.coerceIn(0, 2)
        sIdx = shape.coerceIn(0, 2)
        gIdx = spacing.coerceIn(0, 2)
        oIdx = hand.coerceIn(0, 2)
        requestLayout()
        invalidate()
    }

    private fun px(dp: Float): Float = dp * density * 0.62f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = px(4f + 44f + KbLayout.numDp[hIdx] + 4f * KbLayout.rowDp[hIdx] + 8f)
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), h.toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        fill.color = c.background
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, px(16f), px(16f), fill)

        val kbW = if (oIdx == 0) w else w * 0.8f
        val x0 = if (oIdx == 2) w - kbW else 0f
        val rowH = px(KbLayout.rowDp[hIdx].toFloat())
        val numH = px(KbLayout.numDp[hIdx].toFloat())
        val tbH = px(44f)
        val m = px(KbLayout.marginDp[gIdx].toFloat())
        val r = px(KbLayout.cornerDp[sIdx].toFloat())
        var y = px(4f)

        val toolbar = listOf(PK(1f, "", 5), PK(1f, "", 5), PK(1f, "", 5), PK(1f, "", 5), PK(4.2f, "", 4), PK(1f, "", 5))
        drawRow(canvas, x0, y, kbW, tbH, m, px(19f), toolbar, 0f, false)
        y += tbH
        drawRow(canvas, x0, y, kbW, numH, m, r, "1234567890".map { PK(1f, it.toString(), 0) }, px(15f), true)
        y += numH
        drawRow(canvas, x0, y, kbW, rowH, m, r, "qwertyuiop".map { PK(1f, it.toString(), 0) }, px(22f), false)
        y += rowH
        val home = listOf(PK(0.5f, "", 3)) + "asdfghjkl".map { PK(1f, it.toString(), 0) } + PK(0.5f, "", 3)
        drawRow(canvas, x0, y, kbW, rowH, m, r, home, px(22f), false)
        y += rowH
        val bottomLetters = listOf(PK(1.5f, "", 1)) + "zxcvbnm".map { PK(1f, it.toString(), 0) } + PK(1.5f, "", 1)
        drawRow(canvas, x0, y, kbW, rowH, m, r, bottomLetters, px(22f), false)
        y += rowH
        val bottom = listOf(PK(1.5f, "?123", 1), PK(1f, ",", 0), PK(5f, "", 0), PK(1f, ".", 0), PK(1.5f, "", 2))
        drawRow(canvas, x0, y, kbW, rowH, m, r, bottom, px(14f), false)
    }

    private fun drawRow(
        canvas: Canvas, x0: Float, y: Float, width: Float, h: Float,
        m: Float, r: Float, items: List<PK>, textPx: Float, dim: Boolean
    ) {
        var total = 0f
        for (k in items) total += k.w
        val avail = width - px(8f)
        var x = x0 + px(4f)
        for (k in items) {
            val kw = avail * k.w / total
            if (k.style != 3) {
                rect.set(x + m, y + m, x + kw - m, y + h - m)
                fill.color = when (k.style) {
                    2 -> c.accent
                    1, 4, 5 -> c.special
                    else -> c.key
                }
                canvas.drawRoundRect(rect, r, r, fill)
                if (k.style == 4) {
                    line.color = c.accent
                    line.alpha = 130
                    line.strokeWidth = px(1.2f)
                    canvas.drawRoundRect(rect, r, r, line)
                }
                if (k.label.isNotEmpty()) {
                    txt.textSize = textPx
                    txt.color = when {
                        k.style == 2 -> c.onAccent
                        dim -> c.dim
                        else -> c.text
                    }
                    canvas.drawText(k.label, rect.centerX(), rect.centerY() - (txt.ascent() + txt.descent()) / 2f, txt)
                }
            }
            x += kw
        }
    }
}

/** Ô chọn bộ màu: nền, vài phím mẫu, chấm màu nhấn và tên. */
private class SwatchView(ctx: Context, val palette: Palette, private val density: Float) : View(ctx) {
    var chosen = false
        set(v) {
            field = v
            invalidate()
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f * density
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 12f * density
        fill.color = palette.background
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, fill)

        val gap = 5f * density
        val kw = (w - 16f * density - 2f * gap) / 3f
        var x = 8f * density
        val ky = 9f * density
        val kh = 14f * density
        for (i in 0 until 3) {
            fill.color = if (i == 2) palette.accent else palette.key
            rect.set(x, ky, x + kw, ky + kh)
            canvas.drawRoundRect(rect, 4f * density, 4f * density, fill)
            x += kw + gap
        }
        label.color = palette.text
        canvas.drawText(palette.name, 8f * density, h - 9f * density, label)

        if (chosen) {
            val half = ring.strokeWidth / 2f
            ring.color = Ui.accent
            rect.set(half, half, w - half, h - half)
            canvas.drawRoundRect(rect, r, r, ring)
        }
    }
}

/** Chấm tròn chọn màu nhấn. */
private class DotView(ctx: Context, val color: Int, private val density: Float) : View(ctx) {
    var chosen = false
        set(v) {
            field = v
            invalidate()
        }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val rad = minOf(width, height) / 2f - 6f * density
        fill.color = color
        canvas.drawCircle(cx, cy, rad, fill)
        if (chosen) {
            ring.color = Ui.text
            canvas.drawCircle(cx, cy, rad + 3.5f * density, ring)
        }
    }
}

/** Keyboard: chọn màu, đổi kích thước phím, kiểu phím và chế độ một tay. */
class KeyboardActivity : BaseActivity() {

    private lateinit var preview: KeyboardPreview
    private lateinit var autoPill: TextView
    private val swatches = mutableListOf<SwatchView>()
    private val dots = mutableListOf<DotView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        col.addView(backHeader("Keyboard"))
        col.addView(previewCard())
        col.addView(colorsCard())
        col.addView(layoutCard())
        col.addView(button("Reset to default", Ui.field, Ui.text) {
            prefs.edit()
                .remove(Prefs.THEME)
                .remove(Prefs.ACCENT)
                .remove(Prefs.KEY_HEIGHT)
                .remove(Prefs.KEY_SHAPE)
                .remove(Prefs.KEY_SPACING)
                .remove(Prefs.ONE_HAND)
                .apply()
            recreate()
        })
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
        refreshPreview()
    }

    private fun previewCard(): View {
        val c = card()
        c.addView(tv("Preview", 18f, Ui.text, true))
        preview = KeyboardPreview(this, resources.displayMetrics.density)
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        preview.layoutParams = lp
        c.addView(preview)
        c.addView(tv("Open the keyboard below to try your changes for real.", 13f, Ui.dim).apply {
            setPadding(0, dp(10), 0, dp(8))
        })
        c.addView(EditText(this).apply {
            hint = "Type here to test"
            setHintTextColor(Ui.dim)
            setTextColor(Ui.text)
            background = roundBg(Ui.field, 12)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        })
        return c
    }

    private fun refreshPreview() {
        preview.update(
            Themes.colors(prefs),
            prefs.getInt(Prefs.KEY_HEIGHT, 1),
            prefs.getInt(Prefs.KEY_SHAPE, 1),
            prefs.getInt(Prefs.KEY_SPACING, 1),
            prefs.getInt(Prefs.ONE_HAND, 0)
        )
    }

    /* ================= MÀU ================= */
    private fun colorsCard(): View {
        val c = card()
        c.addView(tv("Colors", 18f, Ui.text, true))
        c.addView(label("Theme"))
        c.addView(themeGrid())
        c.addView(label("Accent color"))
        c.addView(accentRow())
        return c
    }

    private fun label(s: String): TextView = tv(s, 13f, Ui.dim).apply { setPadding(0, dp(12), 0, dp(4)) }

    private fun themeGrid(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val current = prefs.getString(Prefs.THEME, "midnight") ?: "midnight"
        val perRow = 4
        val density = resources.displayMetrics.density
        Themes.all.chunked(perRow).forEach { rowItems ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            rowItems.forEach { p ->
                val sw = SwatchView(this, p, density)
                sw.chosen = p.id == current
                val lp = LinearLayout.LayoutParams(0, dp(62), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                sw.layoutParams = lp
                sw.setOnClickListener {
                    prefs.edit().putString(Prefs.THEME, p.id).apply()
                    swatches.forEach { s -> s.chosen = s.palette.id == p.id }
                    refreshPreview()
                }
                swatches.add(sw)
                row.addView(sw)
            }
            repeat(perRow - rowItems.size) {
                val filler = View(this)
                filler.layoutParams = LinearLayout.LayoutParams(0, dp(62), 1f)
                row.addView(filler)
            }
            box.addView(row)
        }
        return box
    }

    private fun accentRow(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(40))

        autoPill = tv("Auto", 12f, Ui.text, true)
        autoPill.gravity = Gravity.CENTER
        autoPill.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1.4f)
        autoPill.setOnClickListener { setAccent(0) }
        row.addView(autoPill)

        val density = resources.displayMetrics.density
        Themes.accents.forEach { (_, color) ->
            val d = DotView(this, color, density)
            d.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            d.setOnClickListener { setAccent(color) }
            dots.add(d)
            row.addView(d)
        }
        paintAccent(prefs.getInt(Prefs.ACCENT, 0))
        return row
    }

    private fun setAccent(color: Int) {
        prefs.edit().putInt(Prefs.ACCENT, color).apply()
        paintAccent(color)
        refreshPreview()
    }

    private fun paintAccent(current: Int) {
        autoPill.setTextColor(if (current == 0) Ui.onAccent else Ui.text)
        autoPill.background = roundBg(if (current == 0) Ui.accent else Ui.field, 20)
        dots.forEach { it.chosen = it.color == current }
    }

    /* ================= BỐ CỤC ================= */
    private fun layoutCard(): View {
        val c = card()
        c.addView(tv("Layout", 18f, Ui.text, true))
        c.addView(label("Key height"))
        c.addView(segment(KbLayout.heightNames, prefs.getInt(Prefs.KEY_HEIGHT, 1)) { setInt(Prefs.KEY_HEIGHT, it) })
        c.addView(label("Key shape"))
        c.addView(segment(KbLayout.shapeNames, prefs.getInt(Prefs.KEY_SHAPE, 1)) { setInt(Prefs.KEY_SHAPE, it) })
        c.addView(label("Key spacing"))
        c.addView(segment(KbLayout.spacingNames, prefs.getInt(Prefs.KEY_SPACING, 1)) { setInt(Prefs.KEY_SPACING, it) })
        c.addView(label("One-handed mode"))
        c.addView(segment(KbLayout.handNames, prefs.getInt(Prefs.ONE_HAND, 0)) { setInt(Prefs.ONE_HAND, it) })
        return c
    }

    private fun setInt(key: String, v: Int) {
        prefs.edit().putInt(key, v).apply()
        refreshPreview()
    }
}
