package com.example.mykeyboard

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ScrollView

/** Keyboard: nơi chỉnh sửa bàn phím và đổi màu. Hiện đang ở trạng thái "Coming soon". */
class KeyboardActivity : BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        col.addView(backHeader("Keyboard"))
        col.addView(banner())
        col.addView(featureCard("Layout", "Edit keys, rows and key sizes"))
        col.addView(featureCard("Colors", "Change the keyboard colors and themes"))
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
    }

    private fun banner(): View {
        val c = card()
        c.addView(tv("Coming soon!", 22f, Ui.accent, true))
        c.addView(
            tv("This is where you will edit the keyboard and change its colors. We are working on it.", 14f, Ui.dim)
                .apply { setPadding(0, dp(6), 0, 0) }
        )
        return c
    }

    /** Thẻ tính năng đang làm dở: làm mờ và gắn nhãn Coming soon. */
    private fun featureCard(title: String, sub: String): View {
        val c = card()
        c.alpha = 0.6f
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        texts.addView(tv(title, 17f, Ui.text, true))
        texts.addView(tv(sub, 13f, Ui.dim))
        row.addView(texts)
        row.addView(pill("Coming soon"))
        c.addView(row)
        return c
    }
}
