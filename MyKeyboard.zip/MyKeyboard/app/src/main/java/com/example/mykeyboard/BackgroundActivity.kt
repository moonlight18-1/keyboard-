package com.example.mykeyboard

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/** Nền bàn phím: ảnh từ thư viện (có cắt/đặt vị trí) hoặc video (phát lặp, tắt tiếng). */
class BackgroundActivity : BaseActivity() {

    private val reqPickImage = 101
    private val reqCrop = 102
    private val reqPickVideo = 103
    private lateinit var preview: KeyboardPreview
    private var previewBmp: Bitmap? = null

    private fun imageActive() = prefs.getBoolean(Prefs.BG_ON, false) && BackgroundStore.hasBackground(this)
    private fun videoActive() = prefs.getBoolean(Prefs.VID_ON, false) && BackgroundStore.hasVideo(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    private fun build() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        col.addView(backHeader("Background"))
        col.addView(previewCard())
        col.addView(photoCard())
        col.addView(videoCard())
        if (imageActive() || videoActive()) col.addView(blendCard())
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
    }

    /* ================= XEM TRƯỚC ================= */
    private fun previewCard(): View {
        val c = card()
        c.addView(tv("Preview", 18f, Ui.text, true))
        preview = KeyboardPreview(this, resources.displayMetrics.density)
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.topMargin = dp(10)
        preview.layoutParams = lp
        preview.update(
            Themes.colors(prefs),
            prefs.getInt(Prefs.KEY_HEIGHT, 1),
            prefs.getInt(Prefs.KEY_SHAPE, 1),
            prefs.getInt(Prefs.KEY_SPACING, 1),
            prefs.getInt(Prefs.ONE_HAND, 0),
            prefs.getInt(Prefs.FONT, 0),
            prefs.getInt(Prefs.KEY_STYLE, 0),
            prefs.getInt(Prefs.KEY_TEXT, 1)
        )
        previewBmp = when {
            videoActive() -> ImageUtil.loadFile(BackgroundStore.videoThumb(this).path, 900)
            imageActive() -> ImageUtil.loadFile(BackgroundStore.outFile(this).path, 900)
            else -> null
        }
        applyPreviewBg()
        c.addView(preview)
        if (videoActive()) {
            c.addView(tv("Preview shows the first frame. On the keyboard the video plays.", 12f, Ui.dim).apply {
                setPadding(0, dp(8), 0, 0)
            })
        }
        return c
    }

    private fun applyPreviewBg() {
        preview.setBackgroundImage(
            previewBmp,
            prefs.getInt(Prefs.BG_DIM, 2).coerceIn(0, 7),
            prefs.getInt(Prefs.BG_KEY_ALPHA, 6).coerceIn(3, 10),
            if (videoActive()) prefs.getInt(Prefs.VID_ALIGN, 1).coerceIn(0, 2) else 1
        )
    }

    /* ================= ẢNH ================= */
    private fun photoCard(): View {
        val c = card()
        c.addView(tv("Photo", 18f, Ui.text, true))
        c.addView(tv("Pick a photo from your gallery, then crop and position it to fit the keyboard.", 13f, Ui.dim).apply {
            setPadding(0, dp(4), 0, 0)
        })
        c.addView(button("Choose photo from gallery", Ui.accent, Ui.onAccent) { pickImage() })
        if (BackgroundStore.hasSource(this)) {
            c.addView(button("Adjust crop and position", Ui.field, Ui.text) { openCrop() })
        }
        if (imageActive()) {
            c.addView(button("Remove photo background", Ui.field, Ui.text) {
                confirm("Remove photo background?", "Your keyboard will go back to its normal colors.") {
                    BackgroundStore.remove(this)
                    build()
                }
            })
        }
        return c
    }

    /* ================= VIDEO ================= */
    private fun presetNames(): List<String> {
        val all = try {
            assets.list("videos")
        } catch (e: Exception) {
            null
        }
        return (all ?: emptyArray()).filter { it.endsWith(".mp4", ignoreCase = true) }.sorted()
    }

    private fun videoCard(): View {
        val c = card()
        c.addView(tv("Video", 18f, Ui.text, true))
        c.addView(
            tv("Use a video as your keyboard background. It loops without sound and only plays while the keyboard is open (max 80 MB).", 13f, Ui.dim)
                .apply { setPadding(0, dp(4), 0, 0) }
        )
        c.addView(button("Choose video from gallery", Ui.accent, Ui.onAccent) { pickVideo() })

        val presets = presetNames()
        if (presets.isNotEmpty()) {
            c.addView(tv("Built-in videos", 13f, Ui.dim).apply { setPadding(0, dp(16), 0, 0) })
            presets.forEach { name ->
                val label = name.substringBeforeLast('.').replace('_', ' ')
                c.addView(button(label, Ui.field, Ui.text) { importPreset(name) })
            }
        }

        if (videoActive()) {
            c.addView(tv("Which part of the video to show", 13f, Ui.dim).apply { setPadding(0, dp(16), 0, 0) })
            c.addView(segment(listOf("Top", "Center", "Bottom"), prefs.getInt(Prefs.VID_ALIGN, 1).coerceIn(0, 2)) {
                prefs.edit().putInt(Prefs.VID_ALIGN, it).apply()
                applyPreviewBg()
            })
            c.addView(button("Remove video background", Ui.field, Ui.text) {
                confirm("Remove video background?", "Your keyboard will go back to its normal colors.") {
                    BackgroundStore.removeVideo(this)
                    build()
                }
            })
        }
        return c
    }

    /* ================= ĐỘ TỐI + ĐỘ TRONG CỦA PHÍM ================= */
    private fun blendCard(): View {
        val c = card()
        c.addView(tv("Blend", 18f, Ui.text, true))
        c.addView(tv("Image dimming (keeps letters easy to read)", 13f, Ui.dim).apply { setPadding(0, dp(8), 0, 0) })
        c.addView(seek(7, prefs.getInt(Prefs.BG_DIM, 2).coerceIn(0, 7)) {
            prefs.edit().putInt(Prefs.BG_DIM, it).apply()
            applyPreviewBg()
        })
        c.addView(tv("Key opacity (lower = see more of your photo or video)", 13f, Ui.dim).apply { setPadding(0, dp(10), 0, 0) })
        c.addView(seek(7, prefs.getInt(Prefs.BG_KEY_ALPHA, 6).coerceIn(3, 10) - 3) {
            prefs.edit().putInt(Prefs.BG_KEY_ALPHA, it + 3).apply()
            applyPreviewBg()
        })
        return c
    }

    private fun confirm(title: String, message: String, onYes: () -> Unit) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setMessage(message)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Remove") { _, _ -> onYes() }
            .show()
    }

    /* ================= CHỌN FILE ================= */
    private fun pick(type: String, request: Int, noApp: String) {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = type
        i.addCategory(Intent.CATEGORY_OPENABLE)
        try {
            startActivityForResult(i, request)
        } catch (e: Exception) {
            Toast.makeText(this, noApp, Toast.LENGTH_SHORT).show()
        }
    }

    private fun pickImage() = pick("image/*", reqPickImage, "No gallery app found")

    private fun pickVideo() = pick("video/*", reqPickVideo, "No video picker found")

    private fun openCrop() {
        startActivityForResult(Intent(this, CropActivity::class.java), reqCrop)
    }

    private fun importImage(uri: Uri) {
        Toast.makeText(this, "Loading photo…", Toast.LENGTH_SHORT).show()
        Thread {
            val bmp = ImageUtil.load(this, uri, 2048)
            val saved = bmp != null && ImageUtil.saveJpeg(bmp, BackgroundStore.srcFile(this), 92)
            runOnUiThread {
                if (saved) {
                    openCrop()
                } else {
                    Toast.makeText(this, "Couldn't open this photo", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun importVideo(uri: Uri) {
        Toast.makeText(this, "Loading video…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = VideoUtil.importFromUri(this, uri)
            runOnUiThread {
                if (ok) build() else Toast.makeText(this, "Couldn't use this video (max 80 MB)", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun importPreset(name: String) {
        Toast.makeText(this, "Loading video…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = VideoUtil.importFromAsset(this, name)
            runOnUiThread {
                if (ok) build() else Toast.makeText(this, "Couldn't load this video", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            reqPickImage -> data?.data?.let { importImage(it) }
            reqPickVideo -> data?.data?.let { importVideo(it) }
            reqCrop -> build()
        }
    }
}
