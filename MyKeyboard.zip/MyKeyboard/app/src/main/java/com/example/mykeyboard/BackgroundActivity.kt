package com.example.mykeyboard

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

/** Ảnh nền bàn phím: chọn ảnh từ thư viện, cắt, chỉnh độ tối. Video: sắp có. */
class BackgroundActivity : BaseActivity() {

    private val reqPick = 101
    private val reqCrop = 102
    private lateinit var preview: KeyboardPreview
    private var previewBmp: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    private fun build() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(24))
        }
        col.addView(backHeader("Background"))
        col.addView(previewCard())
        col.addView(photoCard())
        col.addView(videoCard())
        setContentView(ScrollView(this).apply {
            clipToPadding = false
            addView(col)
        })
    }

    private fun previewCard(): View {
        val c = card()
        c.addView(tv("Preview", 18f, Ui.text, true))
        preview = KeyboardPreview(this, resources.displayMetrics.density)
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.topMargin = dp(10)
        preview.layoutParams = lp
        preview.update(
            Themes.colors(prefs),
            prefs.getInt(Prefs.KEY_HEIGHT, 1),
            prefs.getInt(Prefs.KEY_SHAPE, 1),
            prefs.getInt(Prefs.KEY_SPACING, 1),
            prefs.getInt(Prefs.ONE_HAND, 0),
            prefs.getInt(Prefs.FONT, 0)
        )
        val hasBg = BackgroundStore.hasBackground(this) && prefs.getBoolean(Prefs.BG_ON, false)
        previewBmp = if (hasBg) ImageUtil.loadFile(BackgroundStore.outFile(this).path, 900) else null
        applyPreviewBg()
        c.addView(preview)
        return c
    }

    private fun applyPreviewBg() {
        preview.setBackgroundImage(
            previewBmp,
            prefs.getInt(Prefs.BG_DIM, 2).coerceIn(0, 7),
            prefs.getInt(Prefs.BG_KEY_ALPHA, 6).coerceIn(3, 10)
        )
    }

    private fun photoCard(): View {
        val c = card()
        c.addView(tv("Photo", 18f, Ui.text, true))
        c.addView(tv("Pick a photo from your gallery, then crop and position it to fit the keyboard.", 13f, Ui.dim).apply {
            setPadding(0, dp(4), 0, 0)
        })
        c.addView(button("Choose from gallery", Ui.accent, Ui.onAccent) { pickImage() })
        if (BackgroundStore.hasSource(this)) {
            c.addView(button("Adjust crop and position", Ui.field, Ui.text) { openCrop() })
        }
        if (previewBmp != null) {
            c.addView(tv("Image dimming (keeps letters easy to read)", 13f, Ui.dim).apply { setPadding(0, dp(16), 0, 0) })
            c.addView(seek(7, prefs.getInt(Prefs.BG_DIM, 2).coerceIn(0, 7)) {
                prefs.edit().putInt(Prefs.BG_DIM, it).apply()
                applyPreviewBg()
            })
            c.addView(tv("Key opacity (lower = see more of your photo)", 13f, Ui.dim).apply { setPadding(0, dp(10), 0, 0) })
            c.addView(seek(7, prefs.getInt(Prefs.BG_KEY_ALPHA, 6).coerceIn(3, 10) - 3) {
                prefs.edit().putInt(Prefs.BG_KEY_ALPHA, it + 3).apply()
                applyPreviewBg()
            })
            c.addView(button("Remove background", Ui.field, Ui.text) {
                AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Remove background?")
                    .setMessage("Your keyboard will go back to its normal colors.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Remove") { _, _ ->
                        BackgroundStore.remove(this)
                        build()
                    }
                    .show()
            })
        }
        return c
    }

    /** Video: đang làm, hiện ở trạng thái Coming soon. */
    private fun videoCard(): View {
        val c = card()
        c.alpha = 0.6f
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        texts.addView(tv("Video", 18f, Ui.text, true))
        texts.addView(tv("Play a video behind your keys. Coming soon!", 13f, Ui.dim))
        row.addView(texts)
        row.addView(pill("Coming soon"))
        c.addView(row)
        return c
    }

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        try {
            startActivityForResult(i, reqPick)
        } catch (e: Exception) {
            Toast.makeText(this, "No gallery app found", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCrop() {
        startActivityForResult(Intent(this, CropActivity::class.java), reqCrop)
    }

    private fun importImage(uri: Uri) {
        Toast.makeText(this, "Loading photo…", Toast.LENGTH_SHORT).show()
        Thread {
            val bmp = ImageUtil.load(this, uri, 2048)
            val saved = bmp != null && ImageUtil.saveJpeg(bmp, BackgroundStore.srcFile(this), 92)
            runOnUiThread {
                if (saved) {
                    openCrop()
                } else {
                    Toast.makeText(this, "Couldn't open this photo", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        when (requestCode) {
            reqPick -> data?.data?.let { importImage(it) }
            reqCrop -> build()
        }
    }
}
