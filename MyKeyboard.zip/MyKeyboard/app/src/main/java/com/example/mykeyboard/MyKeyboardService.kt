package com.example.mykeyboard

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.ViewConfiguration
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.OverScroller
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt

/* ================= GIAO DIỆN: chỉnh màu / kích thước ở đây ================= */
private object Theme {
    var background = Color.parseColor("#12141C")
    var key = Color.parseColor("#252A3B")
    var keyPressed = Color.parseColor("#3B4363")
    var special = Color.parseColor("#1B1F2E")
    var shiftOn = Color.parseColor("#3D4A7A")
    var accent = Color.parseColor("#4FD1C5")
    var accentPressed = Color.parseColor("#2FA89D")
    var bubble = Color.parseColor("#4A5380")
    var text = Color.parseColor("#E8EAF2")
    var dim = Color.parseColor("#8E94AD")
    var onAccent = Color.parseColor("#06201D")
    val danger = Color.parseColor("#D64545")
    var CORNER_DP = 10
    var KEY_MARGIN_DP = 3
    var ROW_DP = 50
    var NUMBER_ROW_DP = 40
    const val TOOLBAR_DP = 44
    const val BUBBLE_DP = 46
    var EMOJI_GRID_DP = 190
    const val EMOJI_CELL_DP = 44
    const val EMOJI_COLS = 8

    fun applyColors(c: KbColors) {
        background = c.background
        key = c.key
        keyPressed = c.keyPressed
        special = c.special
        shiftOn = c.shiftOn
        accent = c.accent
        accentPressed = c.accentPressed
        bubble = c.bubble
        text = c.text
        dim = c.dim
        onAccent = c.onAccent
    }

    private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    /** Khi có ảnh nền: phím trong suốt một phần để nhìn thấy ảnh. */
    fun applyTranslucency(a: Int) {
        key = withAlpha(key, a)
        special = withAlpha(special, a)
        keyPressed = withAlpha(keyPressed, a + 70)
        shiftOn = withAlpha(shiftOn, a + 50)
    }

    fun applyMetrics(height: Int, shape: Int, spacing: Int) {
        ROW_DP = KbLayout.rowDp[height]
        NUMBER_ROW_DP = KbLayout.numDp[height]
        CORNER_DP = KbLayout.cornerDp[shape]
        KEY_MARGIN_DP = KbLayout.marginDp[spacing]
        EMOJI_GRID_DP = NUMBER_ROW_DP + 3 * ROW_DP   // để các bảng cao bằng nhau
    }
}

/* ================= EMOJI: thêm / bớt ở đây (cách nhau bằng dấu cách) ================= */
private val EMOJI_TABS = listOf("🕘", "😀", "👋", "🐶", "🍔", "⚽", "🚗", "💡", "❤️")
private val EMOJI_RAW = listOf(
    "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾",
    "👋 🤚 ✋ 🖖 👌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦵 🦶 👂 👃 🧠 🦷 👀 👅 👄 💋 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 🙍 🙎 🙅 🙆 💁 🙋 🙇 🤦 🤷 👮 💂 👷 🤴 👸 👼 🎅 🤶 🦸 🦹 🧙 🧚 🧛 🧜 🧝 🧞 🧟 💃 🕺",
    "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦏 🐪 🦒 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🦚 🦜 🦢 🐇 🐁 🐀 🌵 🎄 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🍃 🍄 🌷 🌹 🌺 🌸 🌼 🌻 🌞 🌝 🌙 ⭐ 🌟 ✨ ⚡ 🔥 🌈 ☀️ ☁️ ❄️ 💧 🌊",
    "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌽 🥕 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 🥞 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 ☕ 🍵 🥤 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🍾",
    "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🏒 🥊 🥋 ⛳ 🎣 🎿 🎯 🎮 🎲 🧩 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🏆 🥇 🥈 🥉 🏅 🎫 🎪 🎉 🎊 🎈 🎁 🎀 🏋️ 🤸 🏊 🚴 🧘",
    "🚗 🚕 🚙 🚌 🚎 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛵 🏍️ 🚲 🛴 🚨 🚔 🚍 🚘 🚖 🚃 🚄 🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🚀 🛸 🚁 🛶 ⛵ 🚤 🚢 ⚓ ⛽ 🚧 🚦 🗽 🗼 🏰 🏯 🎡 🎢 🎠 ⛲ 🌋 🏠 🏡 🏢 🏥 🏦 🏨 🏫 🏭 ⛪ 🕌",
    "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 💽 💾 💿 📷 📸 📹 🎥 📞 ☎️ 📺 📻 ⏰ ⏳ 📡 🔋 🔌 💡 🔦 🛒 💰 💵 💴 💶 💷 💳 💎 🔧 🔨 🔩 ⚙️ 🧲 🔫 💣 🔪 🔮 🔭 🔬 💊 💉 🧬 🧪 🧹 🧺 🚽 🚿 🛁 🔑 🚪 🛋️ 🛏️ 🧸 📦 ✉️ 📝 📅 📌 📎 ✂️ 🔒 🔓 📚 📖",
    "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 💕 💞 💓 💗 💖 💘 💝 ☮️ ✝️ ☪️ ☸️ ✡️ ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓ ✅ ❌ ❎ ❓ ❔ ❕ ❗ ‼️ ⁉️ 💯 🔞 ⭕ ⛔ 🚫 ⚠️ ♻️ ➕ ➖ ✖️ ➗ 💲 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🔶 🔷 🔺 🔻 ▶️ ⏸️ ⏹️ 🔀 🔁 🔄 ⬆️ ⬇️ ⬅️ ➡️ ☑️ ✔️ 🔔 🔕 🔊 🔇 💬 💭"
)

private enum class T {
    CHAR, SPACER, SHIFT, DELETE, ENTER, MODE, EMOJI, GLOBE, SPACE,
    SETTINGS, HIDE, CLIPBOARD, CHIP, CLIP_CLEAR, CLIP_CANCEL, TRANSLATE, TR_GO
}
private enum class Shift { OFF, ON, CAPS }
private enum class Mode { LETTERS, SYMBOLS, EMOJI, CLIPBOARD, TRANSLATE }
private enum class RowKind { TOOLBAR, NUMBER, NORMAL }

private const val MAX_CLIP_CHARS = 2000        // bỏ qua đoạn chữ dài hơn
private const val MAX_UNPINNED = 40            // số mục tối đa (chưa ghim)
private const val CHIP_TTL_MS = 180_000L       // chip dán nhanh hiện trong 3 phút
private val WS_REGEX = Regex("\\s+")
private data class Key(
    val label: String,
    val type: T = T.CHAR,
    val weight: Float = 1f,
    val iconRes: Int = 0
)

/** Phím tự vẽ: vẽ thẳng bằng Canvas (không qua Drawable nền) nên mỗi lần vẽ lại rất nhẹ. */
private class KeyView(ctx: Context, val key: Key, private val radiusPx: Float, fillColor: Int) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fillColor }
    private var strokePaint: Paint? = null
    private val rect = RectF()
    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    val isLetter = key.type == T.CHAR && key.label.length == 1 && key.label[0].isLetter()
    var iconSizePx = 0
    private var shown = ""
    private var baseline = Float.NaN
    var label: String = key.label
        set(v) {
            if (field != v) {
                field = v
                recomputeShown()
                invalidate()
            }
        }
    var icon: Drawable? = null
        set(v) {
            field = v
            invalidate()
        }

    init {
        if (key.type == T.CHIP) paint.textAlign = Paint.Align.LEFT
    }

    fun setFill(color: Int) {
        if (fill.color == color) return
        fill.color = color
        invalidate()
    }

    fun setStroke(widthPx: Int, color: Int) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = widthPx.toFloat()
        p.color = color
        strokePaint = p
        invalidate()
    }

    /** Độ lệch để chữ nằm giữa theo chiều dọc; tính một lần rồi nhớ lại. */
    private fun textBaseline(): Float {
        if (baseline.isNaN()) {
            val fm = paint.fontMetrics
            baseline = -(fm.ascent + fm.descent) / 2f
        }
        return baseline
    }

    private fun chipPad() = height * 0.35f

    private fun recomputeShown() {
        if (key.type != T.CHIP || width <= 0) return
        val pad = chipPad()
        val textX = pad + (if (icon != null) iconSizePx + pad * 0.6f else 0f)
        val avail = (width - textX - pad).coerceAtLeast(0f)
        shown = TextUtils.ellipsize(label, paint, avail, TextUtils.TruncateAt.END).toString()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recomputeShown()
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, radiusPx, radiusPx, fill)
        val sp = strokePaint
        if (sp != null) {
            val half = sp.strokeWidth / 2f
            rect.inset(half, half)
            canvas.drawRoundRect(rect, radiusPx - half, radiusPx - half, sp)
        }
        if (key.type == T.CHIP) {
            if (label.isEmpty()) return
            val pad = chipPad()
            var x = pad
            val chipIcon = icon
            if (chipIcon != null) {
                val t = (height - iconSizePx) / 2
                chipIcon.setBounds(x.toInt(), t, x.toInt() + iconSizePx, t + iconSizePx)
                chipIcon.draw(canvas)
                x += iconSizePx + pad * 0.6f
            }
            canvas.drawText(shown, x, height / 2f + textBaseline(), paint)
            return
        }
        val ic = icon
        if (ic != null) {
            val l = (width - iconSizePx) / 2
            val t = (height - iconSizePx) / 2
            ic.setBounds(l, t, l + iconSizePx, t + iconSizePx)
            ic.draw(canvas)
        } else if (label.isNotEmpty()) {
            canvas.drawText(label, width / 2f, height / 2f + textBaseline(), paint)
        }
    }
}

/**
 * Nền bàn phím: tô màu nền, nếu có ảnh thì vẽ ảnh (căn giữa, phủ kín) rồi phủ lớp tối nhẹ.
 * Là Drawable gắn làm nền nên không bao giờ làm thay đổi kích thước của bàn phím.
 */
private class BgDrawable(baseColor: Int) : Drawable() {
    private var bmp: Bitmap? = null
    private val basePaint = Paint().apply { color = baseColor }
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dimPaint = Paint()
    private val src = Rect()
    private var dimAlpha = 0

    fun setBitmap(b: Bitmap?) {
        bmp = b
        invalidateSelf()
    }

    fun setDim(a: Int) {
        dimAlpha = a.coerceIn(0, 255)
        dimPaint.color = Color.argb(dimAlpha, 0, 0, 0)
        invalidateSelf()
    }

    override fun draw(canvas: Canvas) {
        val r = bounds
        canvas.drawRect(r, basePaint)
        val b = bmp ?: return
        val vw = r.width()
        val vh = r.height()
        if (vw <= 0 || vh <= 0) return
        val sc = maxOf(vw / b.width.toFloat(), vh / b.height.toFloat())
        val sw = (vw / sc).toInt().coerceAtMost(b.width)
        val sh = (vh / sc).toInt().coerceAtMost(b.height)
        src.set((b.width - sw) / 2, (b.height - sh) / 2, (b.width + sw) / 2, (b.height + sh) / 2)
        canvas.drawBitmap(b, src, r, paint)
        if (dimAlpha > 0) canvas.drawRect(r, dimPaint)
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    override fun getOpacity(): Int = PixelFormat.OPAQUE
}

/**
 * Khung gốc của bàn phím. Giới hạn chiều cao tối đa = chiều cao bàn phím dự kiến + chút dư,
 * để dù có thành phần nào đo sai thì bàn phím cũng không bao giờ phình ra cả màn hình.
 */
private class KbRoot(ctx: Context, private val maxHeightPx: () -> Int) : FrameLayout(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val cap = maxHeightPx()
        val size = MeasureSpec.getSize(heightMeasureSpec)
        val limit = if (MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.UNSPECIFIED) cap else minOf(size, cap)
        super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(limit, MeasureSpec.AT_MOST))
    }
}

/** Bong bóng chữ: chỉ vẽ chữ, đổi chữ không phải đo lại giao diện. */
private class BubbleView(ctx: Context, textPx: Float, radiusPx: Float) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = textPx
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    fun setFont(t: Typeface) {
        paint.typeface = t
        baseline = Float.NaN
        invalidate()
    }

    var label: String = ""
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }

    init {
        background = GradientDrawable().apply {
            cornerRadius = radiusPx
            setColor(Theme.bubble)
            setStroke(1, Color.argb(90, 255, 255, 255))
        }
        visibility = View.INVISIBLE
    }

    private var baseline = Float.NaN

    override fun onDraw(canvas: Canvas) {
        if (baseline.isNaN()) {
            val fm = paint.fontMetrics
            baseline = -(fm.ascent + fm.descent) / 2f
        }
        canvas.drawText(label, width / 2f, height / 2f + baseline, paint)
    }
}

/** Lưới emoji tự vẽ: chỉ vẽ các ô đang nhìn thấy, cuộn + vuốt mượt, mở tức thì. */
private class EmojiGridView(
    ctx: Context,
    private val cols: Int,
    private val cellPx: Int,
    emojiPx: Float,
    hintPx: Float,
    private val onPick: (String) -> Unit
) : View(ctx) {

    private var items: List<String> = emptyList()
    private var hint: String? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = emojiPx
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = hintPx
        color = Theme.dim
    }
    private val hiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.keyPressed }
    private val baseline = paint.fontMetrics.let { -(it.ascent + it.descent) / 2f }
    private val scroller = OverScroller(ctx)
    private val cfg = ViewConfiguration.get(ctx)
    private val slop = cfg.scaledTouchSlop
    private val minFling = cfg.scaledMinimumFlingVelocity
    private val maxFling = cfg.scaledMaximumFlingVelocity
    private var velocity: VelocityTracker? = null
    private var scrollF = 0f
    private var downY = 0f
    private var lastY = 0f
    private var dragging = false
    private var pressedIndex = -1

    fun setItems(list: List<String>, emptyHint: String?) {
        items = list
        hint = emptyHint
        scroller.forceFinished(true)
        scrollF = 0f
        pressedIndex = -1
        scrollTo(0, 0)
        invalidate()
    }

    private fun maxScroll(): Int = ((items.size + cols - 1) / cols * cellPx - height).coerceAtLeast(0)

    private fun indexAt(x: Float, yContent: Float): Int {
        if (x < 0f || x >= width || yContent < 0f) return -1
        val c = (x / (width.toFloat() / cols)).toInt().coerceIn(0, cols - 1)
        val r = (yContent / cellPx).toInt()
        val i = r * cols + c
        return if (i in items.indices) i else -1
    }

    override fun onDraw(canvas: Canvas) {
        if (items.isEmpty()) {
            hint?.let { canvas.drawText(it, width / 2f, scrollY + height / 2f, hintPaint) }
            return
        }
        val cellW = width.toFloat() / cols
        val rows = (items.size + cols - 1) / cols
        val first = (scrollY / cellPx).coerceAtLeast(0)
        val last = ((scrollY + height) / cellPx).coerceAtMost(rows - 1)
        for (r in first..last) {
            for (c in 0 until cols) {
                val i = r * cols + c
                if (i >= items.size) break
                val cx = cellW * c + cellW / 2f
                val cy = r * cellPx + cellPx / 2f
                if (i == pressedIndex) {
                    canvas.drawRoundRect(
                        cellW * c + 2f, r * cellPx + 2f,
                        cellW * (c + 1) - 2f, (r + 1) * cellPx - 2f,
                        18f, 18f, hiPaint
                    )
                }
                canvas.drawText(items[i], cx, cy + baseline, paint)
            }
        }
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollF = scroller.currY.toFloat()
            scrollTo(0, scroller.currY)
            postInvalidateOnAnimation()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val vt = velocity ?: VelocityTracker.obtain().also { velocity = it }
        vt.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val flinging = !scroller.isFinished
                scroller.forceFinished(true)
                downY = e.y
                lastY = e.y
                dragging = flinging
                pressedIndex = if (flinging) -1 else indexAt(e.x, e.y + scrollY)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(e.y - downY) > slop) {
                    dragging = true
                    pressedIndex = -1
                    invalidate()
                }
                if (dragging) {
                    scrollF = (scrollF + lastY - e.y).coerceIn(0f, maxScroll().toFloat())
                    scrollTo(0, scrollF.roundToInt())
                }
                lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging && pressedIndex >= 0) {
                    items.getOrNull(pressedIndex)?.let(onPick)
                } else if (dragging) {
                    vt.computeCurrentVelocity(1000, maxFling.toFloat())
                    val vy = vt.yVelocity
                    if (abs(vy) > minFling) {
                        scroller.fling(0, scrollY, 0, (-vy).toInt(), 0, 0, 0, maxScroll())
                        postInvalidateOnAnimation()
                    }
                }
                pressedIndex = -1
                invalidate()
                vt.recycle()
                velocity = null
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedIndex = -1
                invalidate()
                vt.recycle()
                velocity = null
            }
        }
        return true
    }
}

/** Danh sách bộ nhớ tạm tự vẽ: thẻ bo góc, nút ghim và xóa; cuộn mượt như bảng emoji. */
private class ClipListView(
    ctx: Context,
    private val density: Float,
    textPx: Float,
    hintPx: Float,
    private val pinOff: Bitmap,
    private val pinOn: Bitmap,
    private val closeBmp: Bitmap,
    private val onAction: (Clip, Int) -> Unit   // zone: 0 = dán, 1 = ghim, 2 = xóa
) : View(ctx) {

    private fun px(v: Int): Int = (v * density).toInt()
    private val sidePad = px(4)
    private val gap = px(8)
    private val cardH = px(58)
    private val radius = px(12).toFloat()
    private val actionW = px(40)
    private val textPadL = px(12)

    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.text
        textSize = textPx
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val hintPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.dim
        textSize = hintPx
        textAlign = Paint.Align.CENTER
    }
    private val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.key }
    private val pressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.keyPressed }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Theme.accent
        style = Paint.Style.STROKE
        strokeWidth = px(1) * 1.5f
    }
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val rect = RectF()

    private var items: List<Clip> = emptyList()
    private var layouts: List<StaticLayout> = emptyList()
    private var hint = ""

    private val scroller = OverScroller(ctx)
    private val cfg = ViewConfiguration.get(ctx)
    private val slop = cfg.scaledTouchSlop
    private val minFling = cfg.scaledMinimumFlingVelocity
    private val maxFling = cfg.scaledMaximumFlingVelocity
    private var velocity: VelocityTracker? = null
    private var scrollF = 0f
    private var downY = 0f
    private var lastY = 0f
    private var dragging = false
    private var pressedIndex = -1
    private var pressedZone = 0

    fun setItems(list: List<Clip>, hintText: String, keepScroll: Boolean) {
        items = list
        hint = hintText
        rebuildLayouts()
        scroller.forceFinished(true)
        scrollF = if (keepScroll) scrollF.coerceAtMost(maxScroll().toFloat()) else 0f
        pressedIndex = -1
        scrollTo(0, scrollF.roundToInt())
        invalidate()
    }

    private fun rebuildLayouts() {
        if (width <= 0) {
            layouts = emptyList()
            return
        }
        val textW = (width - 2 * sidePad - textPadL - 2 * actionW - px(4)).coerceAtLeast(10)
        layouts = items.map { c ->
            val preview = c.text.replace(WS_REGEX, " ").trim()
            StaticLayout.Builder.obtain(preview, 0, preview.length, textPaint, textW)
                .setMaxLines(2)
                .setEllipsize(TextUtils.TruncateAt.END)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .build()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuildLayouts()
    }

    private fun maxScroll(): Int = (gap + items.size * (cardH + gap) - height).coerceAtLeast(0)

    private fun hit(x: Float, yContent: Float): Int {
        val rowH = cardH + gap
        val rel = yContent - gap
        if (rel < 0f) return -1
        val i = (rel / rowH).toInt()
        if (i !in items.indices) return -1
        if (rel - i * rowH > cardH) return -1
        if (x < sidePad || x > width - sidePad) return -1
        pressedZone = when {
            x > width - sidePad - actionW -> 2
            x > width - sidePad - 2 * actionW -> 1
            else -> 0
        }
        return i
    }

    override fun onDraw(canvas: Canvas) {
        if (items.isEmpty()) {
            val lines = hint.split("\n")
            val fm = hintPaint.fontMetrics
            val lineH = hintPaint.fontSpacing
            var y = scrollY + height / 2f - lineH * (lines.size - 1) / 2f - (fm.ascent + fm.descent) / 2f
            for (l in lines) {
                canvas.drawText(l, width / 2f, y, hintPaint)
                y += lineH
            }
            return
        }
        val rowH = cardH + gap
        val first = ((scrollY - gap - cardH) / rowH).coerceAtLeast(0)
        val last = ((scrollY + height - gap) / rowH).coerceAtMost(items.size - 1)
        val left = sidePad.toFloat()
        val right = (width - sidePad).toFloat()
        for (i in first..last) {
            val clip = items[i]
            val top = (gap + i * rowH).toFloat()
            val bottom = top + cardH
            rect.set(left, top, right, bottom)
            val pressedCard = i == pressedIndex && pressedZone == 0
            canvas.drawRoundRect(rect, radius, radius, if (pressedCard) pressPaint else cardPaint)
            if (clip.pinned) canvas.drawRoundRect(rect, radius, radius, strokePaint)

            layouts.getOrNull(i)?.let { lay ->
                canvas.save()
                canvas.translate(left + textPadL, top + (cardH - lay.height) / 2f)
                lay.draw(canvas)
                canvas.restore()
            }

            val cy = top + cardH / 2f
            val pinCx = right - actionW * 1.5f
            val closeCx = right - actionW * 0.5f
            if (i == pressedIndex && pressedZone == 1) canvas.drawCircle(pinCx, cy, actionW * 0.42f, pressPaint)
            if (i == pressedIndex && pressedZone == 2) canvas.drawCircle(closeCx, cy, actionW * 0.42f, pressPaint)
            val pin = if (clip.pinned) pinOn else pinOff
            canvas.drawBitmap(pin, pinCx - pin.width / 2f, cy - pin.height / 2f, bmpPaint)
            canvas.drawBitmap(closeBmp, closeCx - closeBmp.width / 2f, cy - closeBmp.height / 2f, bmpPaint)
        }
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollF = scroller.currY.toFloat()
            scrollTo(0, scroller.currY)
            postInvalidateOnAnimation()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val vt = velocity ?: VelocityTracker.obtain().also { velocity = it }
        vt.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val flinging = !scroller.isFinished
                scroller.forceFinished(true)
                downY = e.y
                lastY = e.y
                dragging = flinging
                pressedIndex = if (flinging) -1 else hit(e.x, e.y + scrollY)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(e.y - downY) > slop) {
                    dragging = true
                    pressedIndex = -1
                    invalidate()
                }
                if (dragging) {
                    scrollF = (scrollF + lastY - e.y).coerceIn(0f, maxScroll().toFloat())
                    scrollTo(0, scrollF.roundToInt())
                }
                lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging && pressedIndex >= 0) {
                    val idx = pressedIndex
                    val zone = pressedZone
                    pressedIndex = -1
                    invalidate()
                    items.getOrNull(idx)?.let { onAction(it, zone) }
                } else if (dragging) {
                    vt.computeCurrentVelocity(1000, maxFling.toFloat())
                    val vy = vt.yVelocity
                    if (abs(vy) > minFling) {
                        scroller.fling(0, scrollY, 0, (-vy).toInt(), 0, 0, 0, maxScroll())
                        postInvalidateOnAnimation()
                    }
                }
                pressedIndex = -1
                invalidate()
                vt.recycle()
                velocity = null
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedIndex = -1
                invalidate()
                vt.recycle()
                velocity = null
            }
        }
        return true
    }
}

class MyKeyboardService : InputMethodService() {

    private val prefs by lazy { Prefs.of(this) }

    private lateinit var outer: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var lettersPanel: LinearLayout
    private lateinit var symbolsPanel: LinearLayout
    private lateinit var emojiPanel: LinearLayout
    private lateinit var bubble: BubbleView
    private lateinit var emojiGrid: EmojiGridView
    private val emojiTabViews = mutableListOf<TextView>()

    // Bộ nhớ tạm
    private lateinit var clipPanel: LinearLayout
    private lateinit var clipList: ClipListView
    private val chipViews = mutableListOf<KeyView>()
    private val clips = mutableListOf<Clip>()
    private var clipEnabled = true
    private var selfSaving = false
    private var lastClipText: String? = null
    private var chipText: String? = null
    private var chipPreview = ""
    private var chipTime = 0L
    private var hideChip = false

    // Dịch ngôn ngữ
    private var translateOn = true
    private var trFrom = "vi"
    private var trTo = "en"
    private var trSelecting = 1          // 0 = đang chọn ngôn ngữ nguồn, 1 = ngôn ngữ đích
    private var trBusy = false
    private var lastOriginal = ""
    private var lastTranslated: String? = null
    private lateinit var translatePanel: LinearLayout
    private lateinit var trFromPill: TextView
    private lateinit var trToPill: TextView
    private lateinit var trStatus: TextView
    private lateinit var trUndo: TextView
    private val trCells = mutableListOf<TextView>()
    private var clipConfirm = false
    private lateinit var clipTitle: TextView
    private lateinit var clipCancel: KeyView
    private lateinit var clipClear: KeyView
    private val clipConfirmTimeout = Runnable { setClipConfirm(false) }
    private val chipExpire = Runnable { updateChip() }
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged() }
    private val clipboard: ClipboardManager by lazy {
        getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    }

    private val handler = Handler(Looper.getMainLooper())
    private val letterViews = mutableListOf<KeyView>()
    private val enterViews = mutableListOf<KeyView>()
    private var shiftView: KeyView? = null
    private var shiftIcons: Array<Drawable?> = arrayOfNulls(3)
    private var enterRes = 0
    private var bubbleOwner: View? = null
    private var bubbleW = 0
    private var bubbleH = 0
    private var lastKeyTime = 0L

    private var mode = Mode.LETTERS
    private var shift = Shift.OFF
    private var lastShiftTap = 0L
    private var emojiCat = 1
    private var autoCap = false
    private var capChars = false
    private var capWords = false
    private var capSentences = false
    private var sentenceEnd = false
    private var capsGen = 0
    private var renderedShift: Shift? = null
    private var secondaryBuilt = false
    private val idleBuild = object : Runnable {
        override fun run() {
            if (secondaryBuilt) return
            if (System.currentTimeMillis() - lastKeyTime < 1500) {
                handler.postDelayed(this, 700)      // đang gõ: đợi lúc rảnh
            } else {
                ensureSecondary()
            }
        }
    }

    // Cài đặt được nhớ sẵn trong bộ nhớ: không phải đọc SharedPreferences mỗi lần gõ
    private var vibrateOn = true
    private var vibMs = 18L
    private var vibAmp = 125
    private var vibStrength = 5
    private var oneHand = 0
    private var appearAnimOn = true
    private var bgOn = false
    private var bgDim = 2
    private var bgKeyAlpha = 6
    private val appearInterpolator = DecelerateInterpolator(1.6f)
    private val rebuildRunnable = Runnable { if (::outer.isInitialized) setInputView(onCreateInputView()) }
    private var soundOn = true
    private var soundVol = 0.5f
    private var popupOn = true
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> onPrefChanged(key) }

    // Rung chạy ở luồng riêng để không làm chậm việc gõ
    private lateinit var fxThread: HandlerThread
    private lateinit var fxHandler: Handler

    // Việc phải chờ ứng dụng khác trả lời (hỏi viết hoa, đọc clipboard) chạy ở luồng riêng
    private lateinit var ioThread: HandlerThread
    private lateinit var ioHandler: Handler

    @Volatile
    private var soundPool: SoundPool? = null
    private val soundIds = IntArray(3)

    private var keyFont: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private var labelFont: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? by lazy { getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator }

    /** Chỉ giữ emoji mà máy hiển thị được (tính sẵn ở luồng nền). */
    private val emojiLists: List<List<String>> by lazy {
        val p = Paint()
        EMOJI_RAW.map { raw -> raw.split(" ").filter { it.isNotEmpty() && p.hasGlyph(it) } }
    }

    private val repeatDelete = object : Runnable {
        override fun run() {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            onDeleted()
            handler.postDelayed(this, 50)
        }
    }
    private val hideBubbleRunnable = Runnable { bubble.visibility = View.INVISIBLE }
    private val capsVerify = Runnable { queryCapsAsync() }

    /* ================= BỐ CỤC PHÍM: chỉnh ở đây ================= */
    private fun chars(s: String) = s.map { Key(it.toString()) }

    private fun toolbarKeys(): List<Key> {
        val keys = mutableListOf(
            Key("", T.SETTINGS, 1f, R.drawable.ic_settings),
            Key("", T.EMOJI, 1f, R.drawable.ic_emoji),
            Key("", T.GLOBE, 1f, R.drawable.ic_globe)
        )
        if (translateOn) keys.add(Key("", T.TRANSLATE, 1f, R.drawable.ic_translate))
        keys.add(Key("", T.CLIPBOARD, 1f, R.drawable.ic_clipboard))
        keys.add(Key("", T.CHIP, if (translateOn) 3.2f else 4.2f, R.drawable.ic_clipboard))
        keys.add(Key("", T.HIDE, 1f, R.drawable.ic_hide))
        return keys
    }

    private fun bottomRow(modeLabel: String) = listOf(
        Key(modeLabel, T.MODE, 1.5f),
        Key(",", T.CHAR, 1f),
        Key("", T.SPACE, 5f),
        Key(".", T.CHAR, 1f),
        Key("", T.ENTER, 1.5f)
    )

    private fun lettersLayout() = listOf(
        chars("1234567890"),
        chars("qwertyuiop"),
        listOf(Key("", T.SPACER, 0.5f)) + chars("asdfghjkl") + Key("", T.SPACER, 0.5f),
        listOf(Key("", T.SHIFT, 1.5f, R.drawable.ic_shift)) + chars("zxcvbnm") +
            Key("", T.DELETE, 1.5f, R.drawable.ic_backspace),
        bottomRow("?123")
    )

    private fun symbolsLayout() = listOf(
        chars("1234567890"),
        chars("@#\$%&-+()/"),
        listOf(Key("", T.SPACER, 0.5f)) + chars("*\"':;!?~|") + Key("", T.SPACER, 0.5f),
        listOf(Key("€", T.CHAR, 1.5f)) + chars("=[]{}<>") +
            Key("", T.DELETE, 1.5f, R.drawable.ic_backspace),
        bottomRow("ABC")
    )

    /* ================= VÒNG ĐỜI ================= */
    override fun onCreate() {
        super.onCreate()
        // Luồng giao diện của bàn phím được ưu tiên cao hơn để phản hồi phím nhanh hơn
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_DISPLAY)
        } catch (e: Exception) {
            // bỏ qua nếu hệ thống không cho đổi
        }
        fxThread = HandlerThread("kb-feedback", android.os.Process.THREAD_PRIORITY_FOREGROUND).also { it.start() }
        fxHandler = Handler(fxThread.looper)
        ioThread = HandlerThread("kb-io").also { it.start() }
        ioHandler = Handler(ioThread.looper)

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val sp = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
        soundIds[0] = sp.load(this, R.raw.key_standard, 1)
        soundIds[1] = sp.load(this, R.raw.key_space, 1)
        soundIds[2] = sp.load(this, R.raw.key_delete, 1)
        soundPool = sp

        loadSettings()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        clips.addAll(ClipStore.load(prefs))
        clipboard.addPrimaryClipChangedListener(clipListener)
        Thread { emojiLists.size }.start()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        clipboard.removePrimaryClipChangedListener(clipListener)
        fxThread.quitSafely()
        ioThread.quitSafely()
        soundPool?.release()
        soundPool = null
        super.onDestroy()
    }

    /** Không dùng chế độ toàn màn hình khi xoay ngang (gây giật và xấu). */
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        shiftIcons[0] = icon(R.drawable.ic_shift, Theme.text)
        shiftIcons[1] = icon(R.drawable.ic_shift_on, Theme.text)
        shiftIcons[2] = icon(R.drawable.ic_caps, Theme.text)
        letterViews.clear()
        enterViews.clear()
        emojiTabViews.clear()
        chipViews.clear()
        shiftView = null
        enterRes = 0

        outer = KbRoot(this) { dp(4 + 44 + Theme.NUMBER_ROW_DP + 4 * Theme.ROW_DP + 8 + 24) }
        if (bgOn) {
            // Ảnh làm nền: đọc ảnh ở luồng nền để không làm chậm lúc bàn phím hiện
            val bg = BgDrawable(Theme.background)
            bg.setDim(bgDim * 255 / 10)
            outer.background = bg
            val path = BackgroundStore.outFile(this).path
            ioHandler.post {
                val b = ImageUtil.loadFile(path, 1600)
                handler.post { bg.setBitmap(b) }
            }
        } else {
            outer.setBackgroundColor(Theme.background)
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        // Chỉ dựng bảng chữ cái ngay để bàn phím hiện nhanh; các bảng còn lại dựng ngầm sau đó
        secondaryBuilt = false
        renderedShift = null
        lettersPanel = buildKeyPanel(lettersLayout())
        content.addView(lettersPanel)
        // Chế độ một tay: thu hẹp bàn phím còn 80% và dồn sang trái / phải
        val contentW = if (oneHand == 0) MATCH_PARENT else (resources.displayMetrics.widthPixels * 0.8f).toInt()
        val contentGravity = when (oneHand) {
            1 -> Gravity.START
            2 -> Gravity.END
            else -> Gravity.NO_GRAVITY
        }
        outer.addView(content, FrameLayout.LayoutParams(contentW, WRAP_CONTENT, contentGravity))

        bubble = BubbleView(this, sp(30f), dp(12).toFloat())
        bubble.setFont(labelFont)
        bubbleW = dp(56)
        bubbleH = dp(Theme.BUBBLE_DP)
        outer.addView(bubble, FrameLayout.LayoutParams(dp(56), dp(Theme.BUBBLE_DP)))

        updateEnterKeys()
        updateChip()
        showMode()
        handler.postDelayed(idleBuild, 1500)
        return outer
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val type = info?.inputType ?: 0
        val cls = type and InputType.TYPE_MASK_CLASS
        if (!restarting) mode = Mode.LETTERS
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) mode = Mode.SYMBOLS
        val isText = cls == InputType.TYPE_CLASS_TEXT
        capChars = isText && (type and InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS) != 0
        capWords = isText && (type and InputType.TYPE_TEXT_FLAG_CAP_WORDS) != 0
        capSentences = isText && (type and InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) != 0
        autoCap = capChars || capWords || capSentences
        shift = Shift.OFF
        sentenceEnd = false
        capsGen++
        if (::outer.isInitialized) {
            updateEnterKeys()
            showMode()
        }
        if (autoCap) {
            handler.removeCallbacks(capsVerify)
            handler.postDelayed(capsVerify, 60)
        }
        val variation = type and InputType.TYPE_MASK_VARIATION
        hideChip = (cls == InputType.TYPE_CLASS_TEXT &&
            (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)) ||
            (cls == InputType.TYPE_CLASS_NUMBER && variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        syncClipboard()
        updateChip()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        handler.removeCallbacks(repeatDelete)
        handler.removeCallbacks(capsVerify)
        handler.removeCallbacks(hideBubbleRunnable)
        if (::bubble.isInitialized) bubble.visibility = View.INVISIBLE
        super.onFinishInputView(finishingInput)
    }

    /** Khi bàn phím hiện lên: các hàng phím trượt lên và hiện dần, hàng dưới cùng trước. */
    override fun onWindowShown() {
        super.onWindowShown()
        playAppear()
    }

    override fun onWindowHidden() {
        super.onWindowHidden()
        resetAppear()
    }

    private fun playAppear() {
        if (!appearAnimOn || !::content.isInitialized) return
        val dy = dp(14).toFloat()
        for (i in 0 until content.childCount) {
            val panel = content.getChildAt(i)
            if (panel !is ViewGroup || panel.visibility != View.VISIBLE) continue
            val n = panel.childCount
            for (j in 0 until n) {
                val row = panel.getChildAt(j)
                row.animate().cancel()
                row.alpha = 0f
                row.translationY = dy
                row.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setStartDelay((n - 1 - j) * 16L)
                    .setDuration(160L)
                    .setInterpolator(appearInterpolator)
                    .withLayer()
                    .start()
            }
        }
    }

    /** Đưa mọi hàng về trạng thái bình thường (phòng khi hiệu ứng bị cắt ngang). */
    private fun resetAppear() {
        if (!::content.isInitialized) return
        for (i in 0 until content.childCount) {
            val panel = content.getChildAt(i)
            if (panel !is ViewGroup) continue
            for (j in 0 until panel.childCount) {
                val row = panel.getChildAt(j)
                row.animate().cancel()
                row.alpha = 1f
                row.translationY = 0f
            }
        }
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // Con trỏ nhảy xa (chạm vào văn bản, dán...): kiểm tra lại viết hoa, ở luồng nền
        if (autoCap && (newSelStart != newSelEnd || abs(newSelStart - oldSelStart) > 2)) {
            handler.removeCallbacks(capsVerify)
            handler.postDelayed(capsVerify, 150)
        }
    }

    /* ================= DỰNG BÀN PHÍM (chỉ một lần) ================= */
    private fun buildKeyPanel(rows: List<List<Key>>): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.addView(buildRow(toolbarKeys(), RowKind.TOOLBAR))
        rows.forEachIndexed { i, r ->
            p.addView(buildRow(r, if (i == 0) RowKind.NUMBER else RowKind.NORMAL))
        }
        return p
    }

    private fun buildEmojiPanel(): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.TOOLBAR_DP))
        EMOJI_TABS.forEachIndexed { i, icon ->
            val tab = TextView(this)
            tab.text = icon
            tab.gravity = Gravity.CENTER
            tab.textSize = 18f
            val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            tab.layoutParams = lp
            tab.setOnClickListener {
                feedback(T.CHAR)
                selectEmojiTab(i)
            }
            emojiTabViews.add(tab)
            tabs.addView(tab)
        }
        panel.addView(tabs)

        emojiGrid = EmojiGridView(
            this, Theme.EMOJI_COLS, dp(Theme.EMOJI_CELL_DP), sp(26f), sp(14f)
        ) { e ->
            feedback(T.CHAR)
            currentInputConnection?.commitText(e, 1)
            addRecent(e)
        }
        emojiGrid.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.EMOJI_GRID_DP))
        panel.addView(emojiGrid)

        panel.addView(
            buildRow(
                listOf(
                    Key("ABC", T.MODE, 1.5f),
                    Key("", T.SPACE, 7f),
                    Key("", T.DELETE, 1.5f, R.drawable.ic_backspace)
                ),
                RowKind.NORMAL
            )
        )
        return panel
    }

    private fun buildRow(keys: List<Key>, kind: RowKind): LinearLayout {
        val h = when (kind) {
            RowKind.TOOLBAR -> Theme.TOOLBAR_DP
            RowKind.NUMBER -> Theme.NUMBER_ROW_DP
            RowKind.NORMAL -> Theme.ROW_DP
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(h))
        keys.forEach { row.addView(buildKey(it, kind)) }
        return row
    }

    private fun baseColor(type: T): Int = when (type) {
        T.ENTER, T.TR_GO -> Theme.accent
        T.SHIFT -> if (shift == Shift.OFF) Theme.special else Theme.shiftOn
        T.DELETE, T.MODE, T.GLOBE, T.EMOJI -> Theme.special
        T.CLIP_CLEAR -> if (clipConfirm) Theme.danger else Theme.special
        T.SETTINGS, T.HIDE, T.CLIPBOARD, T.CHIP, T.CLIP_CANCEL, T.TRANSLATE -> Theme.special
        else -> Theme.key
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        cornerRadius = dp(Theme.CORNER_DP).toFloat()
        setColor(color)
    }

    private fun icon(res: Int, color: Int): Drawable {
        val d = getDrawable(res)!!.mutate()
        d.setTint(color)
        return d
    }

    private fun buildKey(k: Key, kind: RowKind): View {
        if (k.type == T.SPACER) {
            val spacer = View(this)
            spacer.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, k.weight)
            return spacer
        }
        val m = dp(Theme.KEY_MARGIN_DP)
        val pressedColor = if (k.type == T.ENTER || k.type == T.TR_GO) Theme.accentPressed else Theme.keyPressed
        val radius = if (kind == RowKind.TOOLBAR) dp(19) else dp(Theme.CORNER_DP)
        val kv = KeyView(this, k, radius.toFloat(), baseColor(k.type))
        val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, k.weight)
        lp.setMargins(m, m, m, m)
        kv.layoutParams = lp
        kv.iconSizePx = dp(if (k.type == T.CHIP) 16 else if (kind == RowKind.TOOLBAR) 20 else 22)

        if (k.iconRes != 0) {
            val tint = when {
                k.type == T.ENTER -> Theme.onAccent
                k.type == T.CLIPBOARD || k.type == T.CHIP -> Theme.accent
                kind == RowKind.TOOLBAR -> Theme.dim
                else -> Theme.text
            }
            kv.icon = icon(k.iconRes, tint)
        } else {
            kv.paint.typeface =
                if (k.type == T.MODE || k.type == T.CLIP_CLEAR || k.type == T.CLIP_CANCEL || k.type == T.TR_GO) labelFont else keyFont
            kv.paint.textSize = sp(
                when {
                    kind == RowKind.NUMBER -> 15f
                    k.type == T.MODE -> 14f
                    k.type == T.CLIP_CLEAR || k.type == T.CLIP_CANCEL -> 13f
                    k.type == T.CHAR -> if (kv.isLetter) 22f else 20f
                    else -> 16f
                }
            )
            kv.paint.color = when {
                k.type == T.TR_GO -> Theme.onAccent
                kind == RowKind.NUMBER -> Theme.dim
                else -> Theme.text
            }
        }

        if (k.type == T.CHIP) {
            kv.paint.typeface = keyFont
            kv.paint.textSize = sp(14f)
            kv.paint.color = Theme.text
        }
        if (kv.isLetter) letterViews.add(kv)
        if (k.type == T.SHIFT) shiftView = kv
        if (k.type == T.ENTER) enterViews.add(kv)
        if (k.type == T.CHIP) {
            chipViews.add(kv)
            kv.setStroke(dp(1), ((Theme.accent and 0x00FFFFFF) or (120 shl 24)))
            kv.visibility = View.INVISIBLE
        }

        kv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastKeyTime = System.currentTimeMillis()
                    val shown = kv.label            // lấy chữ trước khi trạng thái Shift đổi
                    onKeyDown(k, kv)                // gửi chữ đi trước để chữ hiện sớm nhất
                    kv.setFill(pressedColor)
                    if (k.type == T.CHAR) {
                        bubbleOwner = v
                        showBubble(kv, shown)
                    }
                    feedback(k.type)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    kv.setFill(baseColor(k.type))
                    handler.removeCallbacks(repeatDelete)
                    if (bubbleOwner === v) scheduleHideBubble()
                }
            }
            true
        }
        return kv
    }

    /* ================= CHẾ ĐỘ / NHÃN ================= */
    /* ================= DỊCH NGÔN NGỮ ================= */
    private fun trItems(): List<String> =
        if (trSelecting == 0) listOf("auto") + Langs.all.map { it.first } else Langs.all.map { it.first }

    private fun langPill(onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.gravity = Gravity.CENTER
        t.textSize = 14f
        t.typeface = labelFont
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setOnClickListener {
            feedback(T.CHAR)
            onClick()
        }
        return t
    }

    private fun stylePill(t: TextView, active: Boolean) {
        val d = GradientDrawable()
        d.cornerRadius = dp(19).toFloat()
        d.setColor(Theme.special)
        if (active) d.setStroke(dp(2), Theme.accent)
        t.background = d
        t.setTextColor(Theme.text)
    }

    private fun buildTranslatePanel(): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL

        // Hàng chọn ngôn ngữ: [Từ] ⇄ [Sang]
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.TOOLBAR_DP))
        trFromPill = langPill {
            trSelecting = 0
            refreshTranslateUi()
        }
        trToPill = langPill {
            trSelecting = 1
            refreshTranslateUi()
        }
        val swap = ImageView(this)
        swap.setImageResource(R.drawable.ic_swap)
        swap.setColorFilter(Theme.text)
        swap.setPadding(dp(10), dp(10), dp(10), dp(10))
        swap.setOnClickListener {
            feedback(T.CHAR)
            swapLanguages()
        }
        val pillLp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
        pillLp.setMargins(dp(3), dp(3), dp(3), dp(3))
        head.addView(trFromPill, pillLp)
        head.addView(swap, LinearLayout.LayoutParams(dp(44), MATCH_PARENT))
        head.addView(trToPill, LinearLayout.LayoutParams(pillLp))
        panel.addView(head)

        // Lưới chọn ngôn ngữ (4 cột x 3 hàng)
        val cellDp = (Theme.EMOJI_GRID_DP - 38) / 3
        val grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        grid.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(cellDp * 3))
        trCells.clear()
        for (r in 0 until 3) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            grid.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            for (c in 0 until 4) {
                val idx = r * 4 + c
                val cell = TextView(this)
                cell.gravity = Gravity.CENTER
                cell.textSize = 14f
                cell.typeface = labelFont
                cell.maxLines = 1
                cell.ellipsize = TextUtils.TruncateAt.END
                cell.setOnClickListener {
                    feedback(T.CHAR)
                    onLangCell(idx)
                }
                val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                row.addView(cell, lp)
                trCells.add(cell)
            }
        }
        panel.addView(grid)

        // Dòng trạng thái + nút Hoàn tác
        val statusRow = LinearLayout(this)
        statusRow.orientation = LinearLayout.HORIZONTAL
        statusRow.gravity = Gravity.CENTER_VERTICAL
        statusRow.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.EMOJI_GRID_DP - cellDp * 3))
        trStatus = TextView(this)
        trStatus.textSize = 12f
        trStatus.setTextColor(Theme.dim)
        trStatus.maxLines = 2
        trStatus.ellipsize = TextUtils.TruncateAt.END
        trStatus.setPadding(dp(8), 0, dp(8), 0)
        statusRow.addView(trStatus, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        trUndo = TextView(this)
        trUndo.text = "Undo"
        trUndo.textSize = 13f
        trUndo.typeface = labelFont
        trUndo.setTextColor(Theme.onAccent)
        trUndo.setPadding(dp(14), dp(5), dp(14), dp(5))
        val ud = GradientDrawable()
        ud.cornerRadius = dp(16).toFloat()
        ud.setColor(Theme.accent)
        trUndo.background = ud
        trUndo.visibility = View.GONE
        trUndo.setOnClickListener {
            feedback(T.CHAR)
            undoTranslation()
        }
        val undoLp = LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT)
        undoLp.rightMargin = dp(6)
        statusRow.addView(trUndo, undoLp)
        panel.addView(statusRow)

        // Hàng dưới: ABC | Dịch | xóa
        panel.addView(
            buildRow(
                listOf(
                    Key("ABC", T.MODE, 1.5f),
                    Key("Translate", T.TR_GO, 7f),
                    Key("", T.DELETE, 1.5f, R.drawable.ic_backspace)
                ),
                RowKind.NORMAL
            )
        )
        return panel
    }

    private fun refreshTranslateUi() {
        if (!::trFromPill.isInitialized) return
        trFromPill.text = Langs.name(trFrom)
        trToPill.text = Langs.name(trTo)
        stylePill(trFromPill, trSelecting == 0)
        stylePill(trToPill, trSelecting == 1)
        val items = trItems()
        val current = if (trSelecting == 0) trFrom else trTo
        trCells.forEachIndexed { i, cell ->
            val code = items.getOrNull(i)
            if (code == null) {
                cell.visibility = View.INVISIBLE
            } else {
                cell.visibility = View.VISIBLE
                cell.text = Langs.name(code)
                val on = code == current
                cell.setTextColor(if (on) Theme.onAccent else Theme.text)
                cell.background = rounded(if (on) Theme.accent else Theme.special)
            }
        }
    }

    private fun onLangCell(idx: Int) {
        val code = trItems().getOrNull(idx) ?: return
        if (trSelecting == 0) trFrom = code else trTo = code
        prefs.edit().putString(Prefs.TR_FROM, trFrom).putString(Prefs.TR_TO, trTo).apply()
        refreshTranslateUi()
    }

    private fun swapLanguages() {
        if (trFrom == "auto") {
            trFrom = trTo
            trTo = if (trTo == "en") "vi" else "en"
        } else {
            val t = trFrom
            trFrom = trTo
            trTo = t
        }
        prefs.edit().putString(Prefs.TR_FROM, trFrom).putString(Prefs.TR_TO, trTo).apply()
        refreshTranslateUi()
    }

    private fun setTrStatus(text: String, showUndo: Boolean = false) {
        if (!::trStatus.isInitialized) return
        trStatus.text = text
        trUndo.visibility = if (showUndo) View.VISIBLE else View.GONE
    }

    /** Dịch phần đang chọn, hoặc dòng đang gõ, rồi thay bằng bản dịch. */
    private fun startTranslate() {
        if (trBusy) return
        if (hideChip) {
            setTrStatus("Translation is turned off in password fields")
            return
        }
        val ic = currentInputConnection
        if (ic == null) {
            setTrStatus("No text field is open")
            return
        }
        trBusy = true
        setTrStatus("Translating…")
        val from = trFrom
        val to = trTo
        val gen = capsGen
        ioHandler.post {
            var wasSelection = true
            var src: String = ic.getSelectedText(0)?.toString() ?: ""
            if (src.isEmpty()) {
                wasSelection = false
                val before = ic.getTextBeforeCursor(500, 0)?.toString() ?: ""
                val nl = before.lastIndexOf('\n')
                src = if (nl >= 0) before.substring(nl + 1) else before
            }
            if (src.isBlank()) {
                handler.post {
                    trBusy = false
                    setTrStatus("Type some text first, then tap Translate")
                }
                return@post
            }
            val original = src
            val sel = wasSelection
            val res = Translator.translate(original, from, to)
            handler.post { applyTranslation(original, sel, res, from, to, gen) }
        }
    }

    private fun applyTranslation(
        original: String, wasSelection: Boolean, res: TranslateResult, from: String, to: String, gen: Int
    ) {
        trBusy = false
        val out = res.text
        if (out == null) {
            setTrStatus(res.error ?: "Couldn't translate")
            return
        }
        if (gen != capsGen) {
            setTrStatus("Your text changed while translating. Tap Translate again.")
            return
        }
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        if (!wasSelection) ic.deleteSurroundingText(original.length, 0)
        ic.commitText(out, 1)
        ic.endBatchEdit()
        lastOriginal = original
        lastTranslated = out
        setTrStatus("Done · " + Langs.name(from) + " → " + Langs.name(to), true)
    }

    private fun undoTranslation() {
        val t = lastTranslated ?: return
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(t.length, 0)
        ic.commitText(lastOriginal, 1)
        ic.endBatchEdit()
        lastTranslated = null
        setTrStatus("Restored your original text")
    }

    /** Dựng các bảng còn lại (ký hiệu, emoji, clipboard) một lần, lúc rảnh hoặc khi cần. */
    private fun ensureSecondary() {
        if (secondaryBuilt) return
        secondaryBuilt = true
        symbolsPanel = buildKeyPanel(symbolsLayout())
        emojiPanel = buildEmojiPanel()
        clipPanel = buildClipPanel()
        translatePanel = buildTranslatePanel()
        symbolsPanel.visibility = View.GONE
        emojiPanel.visibility = View.GONE
        clipPanel.visibility = View.GONE
        translatePanel.visibility = View.GONE
        content.addView(symbolsPanel)
        content.addView(emojiPanel)
        content.addView(clipPanel)
        content.addView(translatePanel)
        enterRes = 0
        updateEnterKeys()
        updateChip()
    }

    private fun showMode() {
        bubble.visibility = View.INVISIBLE
        if (clipConfirm) setClipConfirm(false)
        if (mode != Mode.LETTERS) ensureSecondary()
        lettersPanel.visibility = if (mode == Mode.LETTERS) View.VISIBLE else View.GONE
        if (secondaryBuilt) {
            symbolsPanel.visibility = if (mode == Mode.SYMBOLS) View.VISIBLE else View.GONE
            emojiPanel.visibility = if (mode == Mode.EMOJI) View.VISIBLE else View.GONE
            clipPanel.visibility = if (mode == Mode.CLIPBOARD) View.VISIBLE else View.GONE
            translatePanel.visibility = if (mode == Mode.TRANSLATE) View.VISIBLE else View.GONE
        }
        refreshLabels()
    }

    private fun refreshLabels() {
        if (renderedShift == shift) return
        renderedShift = shift
        val upper = shift != Shift.OFF
        for (kv in letterViews) {
            kv.label = if (upper) kv.key.label.uppercase() else kv.key.label
        }
        shiftView?.let { kv ->
            kv.icon = shiftIcons[shift.ordinal]
            kv.setFill(baseColor(T.SHIFT))
        }
    }

    private fun enterIconRes(): Int {
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        if ((opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return R.drawable.ic_enter
        return when (opts and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_NEXT -> R.drawable.ic_next
            EditorInfo.IME_ACTION_SEARCH -> R.drawable.ic_search
            EditorInfo.IME_ACTION_SEND -> R.drawable.ic_send
            EditorInfo.IME_ACTION_DONE -> R.drawable.ic_done
            else -> R.drawable.ic_enter
        }
    }

    private fun updateEnterKeys() {
        val r = enterIconRes()
        if (r == enterRes) return
        enterRes = r
        for (kv in enterViews) kv.icon = icon(r, Theme.onAccent)
    }

    /* ================= EMOJI ================= */
    private fun selectEmojiTab(i: Int) {
        emojiCat = i
        emojiTabViews.forEachIndexed { idx, t ->
            t.alpha = if (idx == i) 1f else 0.5f
            t.background = if (idx == i) rounded(Theme.special) else null
        }
        val items = if (i == 0) recentEmoji() else emojiLists[i - 1]
        emojiGrid.setItems(items, if (i == 0) "No recent emoji yet" else null)
    }

    private fun recentEmoji(): List<String> =
        (prefs.getString(Prefs.RECENT, "") ?: "").split(" ").filter { it.isNotEmpty() }

    private fun addRecent(e: String) {
        val list = (listOf(e) + recentEmoji().filter { it != e }).take(32)
        prefs.edit().putString(Prefs.RECENT, list.joinToString(" ")).apply()
    }

    /* ================= BỘ NHỚ TẠM ================= */
    private fun onPrefChanged(key: String?) {
        when (key) {
            Prefs.CLIPS -> if (!selfSaving) reloadClips()
            Prefs.RECENT -> Unit
            Prefs.THEME, Prefs.ACCENT, Prefs.KEY_HEIGHT, Prefs.KEY_SHAPE, Prefs.KEY_SPACING, Prefs.ONE_HAND,
            Prefs.FONT, Prefs.BG_ON, Prefs.BG_VER, Prefs.BG_DIM, Prefs.BG_KEY_ALPHA, Prefs.TR_ON -> {
                // Đổi giao diện: nạp lại rồi dựng lại bàn phím (gộp nhiều thay đổi liên tiếp)
                loadSettings()
                handler.removeCallbacks(rebuildRunnable)
                handler.postDelayed(rebuildRunnable, 120)
            }
            else -> loadSettings()
        }
    }

    private fun buildClipPanel(): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.TOOLBAR_DP))
        val title = TextView(this)
        title.text = "Clipboard"
        title.textSize = 17f
        title.typeface = labelFont
        title.setTextColor(Theme.text)
        title.gravity = Gravity.CENTER_VERTICAL
        title.setPadding(dp(12), 0, 0, 0)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        title.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 5.3f)
        header.addView(title)
        clipTitle = title
        clipCancel = buildKey(Key("Cancel", T.CLIP_CANCEL, 2.2f), RowKind.TOOLBAR) as KeyView
        clipCancel.visibility = View.GONE
        header.addView(clipCancel)
        clipClear = buildKey(Key("Clear", T.CLIP_CLEAR, 2.5f), RowKind.TOOLBAR) as KeyView
        header.addView(clipClear)
        panel.addView(header)

        val iconPx = dp(20)
        clipList = ClipListView(
            this, resources.displayMetrics.density, sp(15f), sp(14f),
            iconBitmap(R.drawable.ic_pin, Theme.dim, iconPx),
            iconBitmap(R.drawable.ic_pin_on, Theme.accent, iconPx),
            iconBitmap(R.drawable.ic_close, Theme.dim, iconPx)
        ) { clip, zone -> onClipAction(clip, zone) }
        clipList.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.EMOJI_GRID_DP))
        panel.addView(clipList)

        panel.addView(
            buildRow(
                listOf(
                    Key("ABC", T.MODE, 1.5f),
                    Key("", T.SPACE, 7f),
                    Key("", T.DELETE, 1.5f, R.drawable.ic_backspace)
                ),
                RowKind.NORMAL
            )
        )
        return panel
    }

    /** Vẽ icon vào Bitmap một lần để danh sách vẽ lại nhiều lần mà không tốn công. */
    private fun iconBitmap(res: Int, color: Int, px: Int): Bitmap {
        val d = icon(res, color)
        val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, px, px)
        d.draw(Canvas(b))
        return b
    }

    private fun onClipAction(clip: Clip, zone: Int) {
        when (zone) {
            0 -> {
                feedback(T.CHAR)
                currentInputConnection?.commitText(clip.text, 1)
            }
            1 -> {
                feedback(T.CHAR)
                togglePin(clip)
            }
            else -> {
                feedback(T.DELETE)
                deleteClip(clip)
            }
        }
    }

    /** Đọc chữ đang được sao chép; bỏ qua nội dung nhạy cảm, quá dài hoặc không phải chữ. */
    private fun readPrimaryText(): String? {
        return try {
            val cm = clipboard
            if (!cm.hasPrimaryClip()) return null
            val desc = cm.primaryClipDescription ?: return null
            if (!desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) &&
                !desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_HTML)
            ) return null
            if (desc.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return null
            val clip = cm.primaryClip ?: return null
            if (clip.itemCount == 0) return null
            val t = clip.getItemAt(0).coerceToText(this)?.toString() ?: return null
            if (t.isBlank() || t.length > MAX_CLIP_CHARS) null else t
        } catch (e: Exception) {
            null
        }
    }

    private fun onClipChanged() {
        if (!clipEnabled) return
        ioHandler.post {
            val text = readPrimaryText() ?: return@post
            handler.post {
                lastClipText = text
                addClip(text, true)
            }
        }
    }

    /** Khi mở bàn phím: bắt kịp nội dung đã sao chép lúc bàn phím chưa chạy. */
    private fun syncClipboard() {
        if (!clipEnabled) return
        ioHandler.post {
            val text = readPrimaryText() ?: return@post
            handler.post {
                if (clipEnabled && text != lastClipText) {
                    lastClipText = text
                    if (clips.none { it.text == text }) addClip(text, false)
                }
            }
        }
    }

    private fun addClip(text: String, showChip: Boolean) {
        val i = clips.indexOfFirst { it.text == text }
        val pinned = i >= 0 && clips[i].pinned
        if (i >= 0) clips.removeAt(i)
        clips.add(0, Clip(text, pinned, System.currentTimeMillis()))
        var unpinned = clips.count { !it.pinned }
        var j = clips.size - 1
        while (unpinned > MAX_UNPINNED && j >= 0) {
            if (!clips[j].pinned) {
                clips.removeAt(j)
                unpinned--
            }
            j--
        }
        saveClips()
        if (showChip) {
            chipText = text
            chipPreview = text.replace(WS_REGEX, " ").trim()
            chipTime = System.currentTimeMillis()
            handler.removeCallbacks(chipExpire)
            handler.postDelayed(chipExpire, CHIP_TTL_MS + 500)
            updateChip()
        }
        if (mode == Mode.CLIPBOARD) refreshClipList(false)
    }

    private fun togglePin(clip: Clip) {
        val i = clips.indexOfFirst { it.text == clip.text }
        if (i < 0) return
        clips[i] = clips[i].copy(pinned = !clips[i].pinned)
        saveClips()
        refreshClipList(true)
    }

    private fun deleteClip(clip: Clip) {
        clips.removeAll { it.text == clip.text }
        saveClips()
        refreshClipList(true)
    }

    private fun clearUnpinned() {
        clips.removeAll { !it.pinned }
        saveClips()
        refreshClipList(false)
    }

    /** Bật / tắt chế độ xác nhận xóa ngay trên thanh tiêu đề của Clipboard. */
    private fun setClipConfirm(on: Boolean) {
        clipConfirm = on
        handler.removeCallbacks(clipConfirmTimeout)
        if (!::clipTitle.isInitialized) return
        clipTitle.text = if (on) "Clear unpinned items?" else "Clipboard"
        clipTitle.textSize = if (on) 14f else 17f
        clipCancel.visibility = if (on) View.VISIBLE else View.GONE
        clipClear.label = if (on) "Delete" else "Clear"
        clipClear.setFill(baseColor(T.CLIP_CLEAR))
        if (on) handler.postDelayed(clipConfirmTimeout, 5000)
    }

    private fun saveClips() {
        selfSaving = true
        ClipStore.save(prefs, clips)
        selfSaving = false
    }

    private fun reloadClips() {
        clips.clear()
        clips.addAll(ClipStore.load(prefs))
        refreshClipList(true)
    }

    private fun refreshClipList(keepScroll: Boolean) {
        if (!::clipList.isInitialized) return
        val hint = if (clipEnabled) {
            "Copied text will show up here.\nTap an item to paste it."
        } else {
            "Clipboard history is off.\nTurn it on in the ML Keyboard app."
        }
        clipList.setItems(clips.sortedByDescending { it.pinned }, hint, keepScroll)
    }

    /** Chip trên thanh công cụ: hiện chữ vừa sao chép trong vài phút, chạm để dán. */
    private fun updateChip() {
        val t = chipText
        val fresh = t != null && !hideChip && System.currentTimeMillis() - chipTime < CHIP_TTL_MS
        for (kv in chipViews) {
            kv.label = if (fresh) chipPreview else ""
            kv.visibility = if (fresh) View.VISIBLE else View.INVISIBLE
        }
    }

    /* ================= BONG BÓNG CHỮ ================= */
    private fun showBubble(kv: KeyView, text: String) {
        if (!popupOn) return
        handler.removeCallbacks(hideBubbleRunnable)
        // Vị trí phím so với bàn phím: cộng các độ lệch, không tính ma trận, không đổi kích thước
        var x = 0
        var y = 0
        var v: View = kv
        while (v !== outer) {
            x += v.left
            y += v.top
            v = v.parent as? View ?: break
        }
        val bx = (x + (kv.width - bubbleW) / 2).coerceIn(0, (outer.width - bubbleW).coerceAtLeast(0))
        val by = (y - bubbleH).coerceAtLeast(0)
        bubble.label = text
        bubble.translationX = bx.toFloat()
        bubble.translationY = by.toFloat()
        bubble.visibility = View.VISIBLE
    }

    private fun scheduleHideBubble() {
        handler.removeCallbacks(hideBubbleRunnable)
        handler.postDelayed(hideBubbleRunnable, 70)
    }

    /* ================= RUNG + ÂM THANH ================= */
    private fun loadSettings() {
        vibrateOn = prefs.getBoolean(Prefs.VIBRATE, true)
        val s = prefs.getInt(Prefs.VIB_STRENGTH, 5).coerceIn(1, 10)
        vibMs = 8L + s * 2L
        vibAmp = (s * 25).coerceIn(1, 255)
        vibStrength = s
        soundOn = prefs.getBoolean(Prefs.SOUND, true)
        soundVol = prefs.getInt(Prefs.SOUND_VOLUME, 5).coerceIn(0, 10) / 10f
        popupOn = prefs.getBoolean(Prefs.POPUP, true)
        clipEnabled = prefs.getBoolean(Prefs.CLIP_ENABLED, true)
        // Giao diện: màu + kích thước phím + chế độ một tay
        Theme.applyColors(Themes.colors(prefs))
        Theme.applyMetrics(
            prefs.getInt(Prefs.KEY_HEIGHT, 1).coerceIn(0, 2),
            prefs.getInt(Prefs.KEY_SHAPE, 1).coerceIn(0, 2),
            prefs.getInt(Prefs.KEY_SPACING, 1).coerceIn(0, 2)
        )
        oneHand = prefs.getInt(Prefs.ONE_HAND, 0).coerceIn(0, 2)
        appearAnimOn = prefs.getBoolean(Prefs.ANIM, true)
        // Phông chữ
        val f = prefs.getInt(Prefs.FONT, 0).coerceIn(0, KbFonts.names.size - 1)
        keyFont = KbFonts.key(f)
        labelFont = KbFonts.label(f)
        // Ảnh nền
        bgOn = prefs.getBoolean(Prefs.BG_ON, false) && BackgroundStore.hasBackground(this)
        bgDim = prefs.getInt(Prefs.BG_DIM, 2).coerceIn(0, 7)
        bgKeyAlpha = prefs.getInt(Prefs.BG_KEY_ALPHA, 6).coerceIn(3, 10)
        if (bgOn) Theme.applyTranslucency(bgKeyAlpha * 25)
        // Dịch
        translateOn = prefs.getBoolean(Prefs.TR_ON, true)
        trFrom = prefs.getString(Prefs.TR_FROM, "vi") ?: "vi"
        trTo = prefs.getString(Prefs.TR_TO, "en") ?: "en"
    }

    private fun feedback(type: T) {
        val sound = soundOn && soundVol > 0f
        val vib = vibrateOn
        if (!vib && !sound) return
        val id = when (type) {
            T.SPACE -> soundIds[1]
            T.DELETE -> soundIds[2]
            else -> soundIds[0]
        }
        val vol = soundVol
        fxHandler.post {
            if (vib) doVibrate()
            if (sound) {
                try {
                    soundPool?.play(id, vol, vol, 1, 0, 1f)
                } catch (e: Exception) {
                    // bỏ qua nếu bộ phát âm đang đóng
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun doVibrate() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 29) {
            // Hiệu ứng dựng sẵn của hệ thống: phản hồi nhanh và đều hơn kiểu rung theo thời gian
            val effect = when {
                vibStrength <= 3 -> VibrationEffect.EFFECT_TICK
                vibStrength <= 7 -> VibrationEffect.EFFECT_CLICK
                else -> VibrationEffect.EFFECT_HEAVY_CLICK
            }
            v.vibrate(VibrationEffect.createPredefined(effect))
        } else if (Build.VERSION.SDK_INT >= 26) {
            val amp = if (v.hasAmplitudeControl()) vibAmp else VibrationEffect.DEFAULT_AMPLITUDE
            v.vibrate(VibrationEffect.createOneShot(vibMs, amp))
        } else {
            v.vibrate(vibMs)
        }
    }

    /* ================= XỬ LÝ PHÍM ================= */
    private fun onKeyDown(k: Key, kv: KeyView) {
        val ic = currentInputConnection
        when (k.type) {
            T.CHAR -> {
                ic?.commitText(kv.label, 1)
                typed(kv.isLetter, kv.label)
            }
            T.SPACE -> {
                ic?.commitText(" ", 1)
                typedSpace()
            }
            T.DELETE -> {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                onDeleted()
                handler.postDelayed(repeatDelete, 400)
            }
            T.ENTER -> {
                sendEnter()
                typedEnter()
            }
            T.SHIFT -> toggleShift()
            T.MODE -> handler.post {
                mode = if (mode == Mode.LETTERS) Mode.SYMBOLS else Mode.LETTERS
                showMode()
            }
            T.EMOJI -> handler.post {
                ensureSecondary()
                mode = Mode.EMOJI
                selectEmojiTab(if (recentEmoji().isEmpty()) 1 else 0)
                showMode()
            }
            T.GLOBE -> {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
            T.SETTINGS -> {
                val i = Intent(this, SettingsActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            T.HIDE -> requestHideSelf(0)
            T.TRANSLATE -> handler.post {
                ensureSecondary()
                mode = Mode.TRANSLATE
                trSelecting = 1
                refreshTranslateUi()
                setTrStatus("Type your text, then tap Translate")
                showMode()
            }
            T.TR_GO -> startTranslate()
            T.CLIPBOARD -> handler.post {
                ensureSecondary()
                mode = Mode.CLIPBOARD
                refreshClipList(false)
                showMode()
            }
            T.CHIP -> {
                val t = chipText
                if (t != null) {
                    ic?.commitText(t, 1)
                    chipText = null
                    updateChip()
                    typed(false, "")
                }
            }
            T.CLIP_CLEAR -> {
                if (clipConfirm) {
                    clearUnpinned()
                    setClipConfirm(false)
                } else if (clips.any { !it.pinned }) {
                    setClipConfirm(true)       // hỏi lại trước khi xóa
                }
            }
            T.CLIP_CANCEL -> setClipConfirm(false)
            T.SPACER -> Unit
        }
    }

    private fun toggleShift() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == Shift.CAPS -> Shift.OFF
            shift == Shift.ON && now - lastShiftTap < 350 -> Shift.CAPS
            shift == Shift.ON -> Shift.OFF
            else -> Shift.ON
        }
        lastShiftTap = now
        refreshLabels()
    }

    /* ================= VIẾT HOA TỰ ĐỘNG ================= */
    // Tính ngay tại chỗ theo những gì vừa gõ; không hỏi ứng dụng trong lúc gõ (hỏi là chậm, gây khựng).

    private fun setShift(next: Shift) {
        if (next != shift) {
            shift = next
            refreshLabels()
        }
    }

    private fun typed(letter: Boolean, label: String) {
        capsGen++
        sentenceEnd = !letter && (label == "." || label == "!" || label == "?")
        if (shift == Shift.CAPS) return
        setShift(if (capChars) Shift.ON else Shift.OFF)
    }

    private fun typedSpace() {
        capsGen++
        if (shift == Shift.CAPS) return
        val up = capChars || capWords || (capSentences && sentenceEnd)
        setShift(if (up) Shift.ON else Shift.OFF)
    }

    private fun typedEnter() {
        capsGen++
        sentenceEnd = false
        if (shift == Shift.CAPS) return
        setShift(if (autoCap) Shift.ON else Shift.OFF)
    }

    private fun onDeleted() {
        capsGen++
        sentenceEnd = false
        if (autoCap) {
            handler.removeCallbacks(capsVerify)
            handler.postDelayed(capsVerify, 250)
        }
    }

    /** Hỏi ứng dụng xem con trỏ có đang ở đầu câu không, làm ở luồng nền. */
    private fun queryCapsAsync() {
        if (!autoCap) return
        val ic = currentInputConnection ?: return
        val itype = currentInputEditorInfo?.inputType ?: 0
        val gen = capsGen
        ioHandler.post {
            val caps = try {
                ic.getCursorCapsMode(itype)
            } catch (e: Exception) {
                0
            }
            handler.post {
                if (gen == capsGen && shift != Shift.CAPS) {
                    setShift(if (caps != 0) Shift.ON else Shift.OFF)
                }
            }
        }
    }

    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun sp(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)
}
