package com.example.mykeyboard

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/* ================= GIAO DIỆN: chỉnh màu / kích thước ở đây ================= */
private object Theme {
    val background = Color.parseColor("#12141C")
    val key = Color.parseColor("#252A3B")
    val keyPressed = Color.parseColor("#3B4363")
    val special = Color.parseColor("#1B1F2E")
    val shiftOn = Color.parseColor("#3D4A7A")
    val accent = Color.parseColor("#4FD1C5")
    val accentPressed = Color.parseColor("#2FA89D")
    val bubble = Color.parseColor("#4A5380")
    val text = Color.parseColor("#E8EAF2")
    val dim = Color.parseColor("#8E94AD")
    val onAccent = Color.parseColor("#06201D")
    const val CORNER_DP = 10
    const val KEY_MARGIN_DP = 3
    const val ROW_DP = 50
    const val NUMBER_ROW_DP = 40
    const val TOOLBAR_DP = 40
    const val BUBBLE_DP = 46
    const val EMOJI_GRID_DP = 190
    const val EMOJI_CELL_DP = 44
    const val EMOJI_COLS = 8
}

/* ================= EMOJI: thêm / bớt ở đây (cách nhau bằng dấu cách) ================= */
private val EMOJI_TABS = listOf("🕘", "😀", "👋", "🐶", "🍔", "⚽", "🚗", "💡", "❤️")
private val EMOJI_RAW = listOf(
    "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾",
    "👋 🤚 ✋ 🖖 👌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦵 🦶 👂 👃 🧠 🦷 👀 👅 👄 💋 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 🙍 🙎 🙅 🙆 💁 🙋 🙇 🤦 🤷 👮 💂 👷 🤴 👸 👼 🎅 🤶 🦸 🦹 🧙 🧚 🧛 🧜 🧝 🧞 🧟 💃 🕺",
    "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦏 🐪 🦒 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🦚 🦜 🦢 🐇 🐁 🐀 🌵 🎄 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🍃 🍄 🌷 🌹 🌺 🌸 🌼 🌻 🌞 🌝 🌙 ⭐ 🌟 ✨ ⚡ 🔥 🌈 ☀️ ☁️ ❄️ 💧 🌊",
    "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌽 🥕 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 🥞 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 ☕ 🍵 🥤 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🍾",
    "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🏒 🥊 🥋 ⛳ 🎣 🎿 🎯 🎮 🎲 🧩 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🏆 🥇 🥈 🥉 🏅 🎫 🎪 🎉 🎊 🎈 🎁 🎀 🏋️ 🤸 🏊 🚴 🧘",
    "🚗 🚕 🚙 🚌 🚎 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛵 🏍️ 🚲 🛴 🚨 🚔 🚍 🚘 🚖 🚃 🚄 🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🚀 🛸 🚁 🛶 ⛵ 🚤 🚢 ⚓ ⛽ 🚧 🚦 🗽 🗼 🏰 🏯 🎡 🎢 🎠 ⛲ 🌋 🏠 🏡 🏢 🏥 🏦 🏨 🏫 🏭 ⛪ 🕌",
    "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 💽 💾 💿 📷 📸 📹 🎥 📞 ☎️ 📺 📻 ⏰ ⏳ 📡 🔋 🔌 💡 🔦 🛒 💰 💵 💴 💶 💷 💳 💎 🔧 🔨 🔩 ⚙️ 🧲 🔫 💣 🔪 🔮 🔭 🔬 💊 💉 🧬 🧪 🧹 🧺 🚽 🚿 🛁 🔑 🚪 🛋️ 🛏️ 🧸 📦 ✉️ 📝 📅 📌 📎 ✂️ 🔒 🔓 📚 📖",
    "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 💕 💞 💓 💗 💖 💘 💝 ☮️ ✝️ ☪️ ☸️ ✡️ ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓ ✅ ❌ ❎ ❓ ❔ ❕ ❗ ‼️ ⁉️ 💯 🔞 ⭕ ⛔ 🚫 ⚠️ ♻️ ➕ ➖ ✖️ ➗ 💲 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🔶 🔷 🔺 🔻 ▶️ ⏸️ ⏹️ 🔀 🔁 🔄 ⬆️ ⬇️ ⬅️ ➡️ ☑️ ✔️ 🔔 🔕 🔊 🔇 💬 💭"
)

private enum class T { CHAR, SPACER, SHIFT, DELETE, ENTER, MODE, EMOJI, GLOBE, SPACE, SETTINGS, HIDE }
private enum class Shift { OFF, ON, CAPS }
private enum class Mode { LETTERS, SYMBOLS, EMOJI }
private enum class RowKind { TOOLBAR, NUMBER, NORMAL }
private data class Key(val label: String, val type: T = T.CHAR, val weight: Float = 1f)

class MyKeyboardService : InputMethodService() {

    private val prefs by lazy { Prefs.of(this) }
    private lateinit var outer: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var bubble: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val letterViews = mutableListOf<Pair<TextView, String>>()
    private var shiftView: TextView? = null
    private var bubbleOwner: View? = null
    private var mode = Mode.LETTERS
    private var shift = Shift.OFF
    private var lastShiftTap = 0L
    private var emojiCat = 1

    private var soundPool: SoundPool? = null
    private val soundIds = IntArray(3)

    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? by lazy { getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator }

    /** Chỉ giữ emoji mà máy hiển thị được. */
    private val emojiLists: List<List<String>> by lazy {
        val p = Paint()
        EMOJI_RAW.map { raw -> raw.split(" ").filter { it.isNotEmpty() && p.hasGlyph(it) } }
    }

    private val repeatDelete = object : Runnable {
        override fun run() {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            handler.postDelayed(this, 50)
        }
    }
    private val hideBubbleRunnable = Runnable { bubble.visibility = View.GONE }

    /* ================= BỐ CỤC PHÍM: chỉnh ở đây ================= */
    private fun chars(s: String) = s.map { Key(it.toString()) }

    private fun toolbarKeys() = listOf(
        Key("⚙", T.SETTINGS, 1f),
        Key("", T.SPACER, 8f),
        Key("▾", T.HIDE, 1f)
    )

    private fun bottomRow(modeLabel: String) = listOf(
        Key(modeLabel, T.MODE, 1.5f),
        Key("😊", T.EMOJI, 1f),
        Key("🌐", T.GLOBE, 1f),
        Key(",", T.CHAR, 1f),
        Key("", T.SPACE, 3f),
        Key(".", T.CHAR, 1f),
        Key(enterLabel(), T.ENTER, 1.5f)
    )

    private fun lettersLayout() = listOf(
        chars("1234567890"),
        chars("qwertyuiop"),
        listOf(Key("", T.SPACER, 0.5f)) + chars("asdfghjkl") + Key("", T.SPACER, 0.5f),
        listOf(Key("⇧", T.SHIFT, 1.5f)) + chars("zxcvbnm") + Key("⌫", T.DELETE, 1.5f),
        bottomRow("?123")
    )

    private fun symbolsLayout() = listOf(
        chars("1234567890"),
        chars("@#\$%&-+()/"),
        listOf(Key("", T.SPACER, 0.5f)) + chars("*\"':;!?~|") + Key("", T.SPACER, 0.5f),
        listOf(Key("€", T.CHAR, 1.5f)) + chars("=[]{}<>") + Key("⌫", T.DELETE, 1.5f),
        bottomRow("ABC")
    )

    /* ================= VÒNG ĐỜI ================= */
    override fun onCreate() {
        super.onCreate()
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val sp = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
        soundIds[0] = sp.load(this, R.raw.key_standard, 1)
        soundIds[1] = sp.load(this, R.raw.key_space, 1)
        soundIds[2] = sp.load(this, R.raw.key_delete, 1)
        soundPool = sp
    }

    override fun onDestroy() {
        soundPool?.release()
        soundPool = null
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        outer = FrameLayout(this).apply { setBackgroundColor(Theme.background) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        outer.addView(content, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        bubble = TextView(this).apply {
            visibility = View.GONE
            gravity = Gravity.CENTER
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Theme.bubble)
            }
            elevation = dp(6).toFloat()
        }
        outer.addView(bubble, FrameLayout.LayoutParams(dp(56), dp(Theme.BUBBLE_DP)))

        render()
        return outer
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) mode = Mode.LETTERS
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) mode = Mode.SYMBOLS
        shift = Shift.OFF
        if (::outer.isInitialized) render()
        afterInput()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        handler.removeCallbacks(repeatDelete)
        super.onFinishInputView(finishingInput)
    }

    /* ================= VẼ BÀN PHÍM ================= */
    private fun render() {
        letterViews.clear()
        shiftView = null
        bubble.visibility = View.GONE
        if (mode == Mode.EMOJI) renderEmoji() else renderKeys()
        refreshLabels()
    }

    private fun renderKeys() {
        content.removeAllViews()
        content.addView(buildRow(toolbarKeys(), RowKind.TOOLBAR))
        val rows = if (mode == Mode.LETTERS) lettersLayout() else symbolsLayout()
        rows.forEachIndexed { i, row ->
            content.addView(buildRow(row, if (i == 0) RowKind.NUMBER else RowKind.NORMAL))
        }
    }

    private fun renderEmoji() {
        content.removeAllViews()

        // Hàng tab danh mục
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.TOOLBAR_DP))
        }
        EMOJI_TABS.forEachIndexed { i, icon ->
            val tab = TextView(this).apply {
                text = icon
                gravity = Gravity.CENTER
                textSize = 18f
                alpha = if (i == emojiCat) 1f else 0.5f
                if (i == emojiCat) background = rounded(Theme.special)
                layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
                    .apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
            }
            tab.setOnClickListener {
                feedback(T.CHAR)
                emojiCat = i
                render()
            }
            tabs.addView(tab)
        }
        content.addView(tabs)

        // Lưới emoji (cuộn được)
        val items = if (emojiCat == 0) recentEmoji() else emojiLists[emojiCat - 1]
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (items.isEmpty()) {
            grid.addView(TextView(this).apply {
                text = "No recent emoji yet"
                setTextColor(Theme.dim)
                gravity = Gravity.CENTER
                setPadding(0, dp(60), 0, 0)
            })
        }
        items.chunked(Theme.EMOJI_COLS).forEach { rowItems ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowItems.forEach { e ->
                val cell = TextView(this).apply {
                    text = e
                    gravity = Gravity.CENTER
                    textSize = 26f
                    layoutParams = LinearLayout.LayoutParams(0, dp(Theme.EMOJI_CELL_DP), 1f)
                }
                cell.setOnClickListener {
                    feedback(T.CHAR)
                    currentInputConnection?.commitText(e, 1)
                    addRecent(e)
                }
                row.addView(cell)
            }
            repeat(Theme.EMOJI_COLS - rowItems.size) {
                row.addView(View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(0, dp(Theme.EMOJI_CELL_DP), 1f)
                })
            }
            grid.addView(row, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        }
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.EMOJI_GRID_DP))
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(grid)
        }
        content.addView(scroll)

        // Hàng dưới: ABC | phím cách | xóa
        content.addView(
            buildRow(
                listOf(Key("ABC", T.MODE, 1.5f), Key("", T.SPACE, 7f), Key("⌫", T.DELETE, 1.5f)),
                RowKind.NORMAL
            )
        )
    }

    private fun buildRow(keys: List<Key>, kind: RowKind): LinearLayout {
        val h = when (kind) {
            RowKind.TOOLBAR -> Theme.TOOLBAR_DP
            RowKind.NUMBER -> Theme.NUMBER_ROW_DP
            RowKind.NORMAL -> Theme.ROW_DP
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(h))
        keys.forEach { row.addView(buildKey(it, kind)) }
        return row
    }

    private fun baseColor(type: T): Int = when (type) {
        T.ENTER -> Theme.accent
        T.SHIFT -> if (shift == Shift.OFF) Theme.special else Theme.shiftOn
        T.DELETE, T.MODE, T.GLOBE, T.EMOJI -> Theme.special
        T.SETTINGS, T.HIDE -> Color.TRANSPARENT
        else -> Theme.key
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        cornerRadius = dp(Theme.CORNER_DP).toFloat()
        setColor(color)
    }

    private fun buildKey(k: Key, kind: RowKind): View {
        if (k.type == T.SPACER) {
            val spacer = View(this)
            spacer.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, k.weight)
            return spacer
        }
        val bg = rounded(baseColor(k.type))
        val pressedColor = if (k.type == T.ENTER) Theme.accentPressed else Theme.keyPressed
        val m = dp(Theme.KEY_MARGIN_DP)

        val tv = TextView(this)
        tv.text = k.label
        tv.gravity = Gravity.CENTER
        tv.textSize = when {
            kind == RowKind.TOOLBAR -> 18f
            kind == RowKind.NUMBER -> 15f
            k.type == T.CHAR -> 21f
            else -> 16f
        }
        tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        tv.setTextColor(
            when {
                k.type == T.ENTER -> Theme.onAccent
                kind == RowKind.TOOLBAR || kind == RowKind.NUMBER -> Theme.dim
                else -> Theme.text
            }
        )
        tv.background = bg
        val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, k.weight)
        lp.setMargins(m, m, m, m)
        tv.layoutParams = lp

        if (k.type == T.CHAR && k.label.length == 1 && k.label[0].isLetter()) {
            letterViews.add(tv to k.label)
        }
        if (k.type == T.SHIFT) shiftView = tv

        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    bg.setColor(pressedColor)
                    feedback(k.type)
                    if (k.type == T.CHAR) {
                        bubbleOwner = v
                        showBubble(tv)
                    }
                    onKeyDown(k)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    bg.setColor(baseColor(k.type))
                    handler.removeCallbacks(repeatDelete)
                    if (bubbleOwner === v) scheduleHideBubble()
                }
            }
            true
        }
        return tv
    }

    private fun refreshLabels() {
        val upper = shift != Shift.OFF
        for ((tv, base) in letterViews) tv.text = if (upper) base.uppercase() else base
        shiftView?.let { tv ->
            tv.text = if (shift == Shift.CAPS) "⇪" else "⇧"
            (tv.background as GradientDrawable).setColor(baseColor(T.SHIFT))
        }
    }

    /* ================= BONG BÓNG CHỮ ================= */
    private fun showBubble(key: TextView) {
        if (!prefs.getBoolean(Prefs.POPUP, true)) return
        handler.removeCallbacks(hideBubbleRunnable)
        val kLoc = IntArray(2)
        val oLoc = IntArray(2)
        key.getLocationInWindow(kLoc)
        outer.getLocationInWindow(oLoc)

        val w = key.width + dp(16)
        val h = dp(Theme.BUBBLE_DP)
        val lp = bubble.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h) {
            lp.width = w
            lp.height = h
            bubble.layoutParams = lp
        }
        val maxX = (outer.width - w).coerceAtLeast(0)
        val x = (kLoc[0] - oLoc[0] - dp(8)).coerceIn(0, maxX)
        val y = (kLoc[1] - oLoc[1] - h).coerceAtLeast(0)
        bubble.text = key.text
        bubble.translationX = x.toFloat()
        bubble.translationY = y.toFloat()
        bubble.visibility = View.VISIBLE
    }

    private fun scheduleHideBubble() {
        handler.removeCallbacks(hideBubbleRunnable)
        handler.postDelayed(hideBubbleRunnable, 70)
    }

    /* ================= RUNG + ÂM THANH ================= */
    private fun feedback(type: T) {
        if (prefs.getBoolean(Prefs.VIBRATE, true)) vibrate()
        if (prefs.getBoolean(Prefs.SOUND, true)) playClick(type)
    }

    @Suppress("DEPRECATION")
    private fun vibrate() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val s = prefs.getInt(Prefs.VIB_STRENGTH, 5).coerceIn(1, 10)
        val ms = 8L + s * 2L
        if (Build.VERSION.SDK_INT >= 26) {
            val amp = if (v.hasAmplitudeControl()) (s * 25).coerceIn(1, 255)
            else VibrationEffect.DEFAULT_AMPLITUDE
            v.vibrate(VibrationEffect.createOneShot(ms, amp))
        } else {
            v.vibrate(ms)
        }
    }

    private fun playClick(type: T) {
        val vol = prefs.getInt(Prefs.SOUND_VOLUME, 5).coerceIn(0, 10) / 10f
        if (vol <= 0f) return
        val id = when (type) {
            T.SPACE -> soundIds[1]
            T.DELETE -> soundIds[2]
            else -> soundIds[0]
        }
        soundPool?.play(id, vol, vol, 1, 0, 1f)
    }

    /* ================= EMOJI GẦN ĐÂY ================= */
    private fun recentEmoji(): List<String> =
        (prefs.getString(Prefs.RECENT, "") ?: "").split(" ").filter { it.isNotEmpty() }

    private fun addRecent(e: String) {
        val list = (listOf(e) + recentEmoji().filter { it != e }).take(32)
        prefs.edit().putString(Prefs.RECENT, list.joinToString(" ")).apply()
    }

    /* ================= XỬ LÝ PHÍM ================= */
    private fun onKeyDown(k: Key) {
        val ic = currentInputConnection
        when (k.type) {
            T.CHAR -> {
                val up = shift != Shift.OFF && k.label.length == 1 && k.label[0].isLetter()
                ic?.commitText(if (up) k.label.uppercase() else k.label, 1)
                afterInput()
            }
            T.SPACE -> {
                ic?.commitText(" ", 1)
                afterInput()
            }
            T.DELETE -> {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                handler.postDelayed(repeatDelete, 400)
            }
            T.ENTER -> {
                sendEnter()
                afterInput()
            }
            T.SHIFT -> toggleShift()
            T.MODE -> handler.post {
                mode = if (mode == Mode.LETTERS) Mode.SYMBOLS else Mode.LETTERS
                render()
            }
            T.EMOJI -> handler.post {
                mode = Mode.EMOJI
                emojiCat = if (recentEmoji().isEmpty()) 1 else 0
                render()
            }
            T.GLOBE -> {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
            T.SETTINGS -> {
                val i = Intent(this, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            T.HIDE -> requestHideSelf(0)
            T.SPACER -> Unit
        }
    }

    private fun toggleShift() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == Shift.CAPS -> Shift.OFF
            shift == Shift.ON && now - lastShiftTap < 350 -> Shift.CAPS
            shift == Shift.ON -> Shift.OFF
            else -> Shift.ON
        }
        lastShiftTap = now
        refreshLabels()
    }

    /** Tự viết hoa đầu câu; tắt Shift sau khi gõ một chữ. */
    private fun afterInput() {
        if (shift == Shift.CAPS) return
        val caps = currentInputConnection
            ?.getCursorCapsMode(currentInputEditorInfo?.inputType ?: 0) ?: 0
        val next = if (caps != 0) Shift.ON else Shift.OFF
        if (next != shift) {
            shift = next
            refreshLabels()
        }
    }

    private fun enterLabel(): String {
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        if ((opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "↵"
        return when (opts and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Go"
            EditorInfo.IME_ACTION_SEARCH -> "Search"
            EditorInfo.IME_ACTION_SEND -> "Send"
            EditorInfo.IME_ACTION_NEXT -> "Next"
            EditorInfo.IME_ACTION_DONE -> "Done"
            else -> "↵"
        }
    }

    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
