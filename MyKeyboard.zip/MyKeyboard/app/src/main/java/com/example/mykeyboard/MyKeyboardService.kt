package com.example.mykeyboard

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.OverScroller
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt

/* ================= GIAO DIỆN: chỉnh màu / kích thước ở đây ================= */
private object Theme {
    val background = Color.parseColor("#12141C")
    val key = Color.parseColor("#252A3B")
    val keyPressed = Color.parseColor("#3B4363")
    val special = Color.parseColor("#1B1F2E")
    val shiftOn = Color.parseColor("#3D4A7A")
    val accent = Color.parseColor("#4FD1C5")
    val accentPressed = Color.parseColor("#2FA89D")
    val bubble = Color.parseColor("#4A5380")
    val text = Color.parseColor("#E8EAF2")
    val dim = Color.parseColor("#8E94AD")
    val onAccent = Color.parseColor("#06201D")
    const val CORNER_DP = 10
    const val KEY_MARGIN_DP = 3
    const val ROW_DP = 50
    const val NUMBER_ROW_DP = 40
    const val TOOLBAR_DP = 40
    const val BUBBLE_DP = 46
    const val EMOJI_GRID_DP = 190
    const val EMOJI_CELL_DP = 44
    const val EMOJI_COLS = 8
}

/* ================= EMOJI: thêm / bớt ở đây (cách nhau bằng dấu cách) ================= */
private val EMOJI_TABS = listOf("🕘", "😀", "👋", "🐶", "🍔", "⚽", "🚗", "💡", "❤️")
private val EMOJI_RAW = listOf(
    "😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾",
    "👋 🤚 ✋ 🖖 👌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦵 🦶 👂 👃 🧠 🦷 👀 👅 👄 💋 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 🙍 🙎 🙅 🙆 💁 🙋 🙇 🤦 🤷 👮 💂 👷 🤴 👸 👼 🎅 🤶 🦸 🦹 🧙 🧚 🧛 🧜 🧝 🧞 🧟 💃 🕺",
    "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦏 🐪 🦒 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🦚 🦜 🦢 🐇 🐁 🐀 🌵 🎄 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🍃 🍄 🌷 🌹 🌺 🌸 🌼 🌻 🌞 🌝 🌙 ⭐ 🌟 ✨ ⚡ 🔥 🌈 ☀️ ☁️ ❄️ 💧 🌊",
    "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌽 🥕 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 🥞 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 ☕ 🍵 🥤 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🍾",
    "⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🏒 🥊 🥋 ⛳ 🎣 🎿 🎯 🎮 🎲 🧩 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🏆 🥇 🥈 🥉 🏅 🎫 🎪 🎉 🎊 🎈 🎁 🎀 🏋️ 🤸 🏊 🚴 🧘",
    "🚗 🚕 🚙 🚌 🚎 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛵 🏍️ 🚲 🛴 🚨 🚔 🚍 🚘 🚖 🚃 🚄 🚅 🚈 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🚀 🛸 🚁 🛶 ⛵ 🚤 🚢 ⚓ ⛽ 🚧 🚦 🗽 🗼 🏰 🏯 🎡 🎢 🎠 ⛲ 🌋 🏠 🏡 🏢 🏥 🏦 🏨 🏫 🏭 ⛪ 🕌",
    "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 💽 💾 💿 📷 📸 📹 🎥 📞 ☎️ 📺 📻 ⏰ ⏳ 📡 🔋 🔌 💡 🔦 🛒 💰 💵 💴 💶 💷 💳 💎 🔧 🔨 🔩 ⚙️ 🧲 🔫 💣 🔪 🔮 🔭 🔬 💊 💉 🧬 🧪 🧹 🧺 🚽 🚿 🛁 🔑 🚪 🛋️ 🛏️ 🧸 📦 ✉️ 📝 📅 📌 📎 ✂️ 🔒 🔓 📚 📖",
    "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 💕 💞 💓 💗 💖 💘 💝 ☮️ ✝️ ☪️ ☸️ ✡️ ♈ ♉ ♊ ♋ ♌ ♍ ♎ ♏ ♐ ♑ ♒ ♓ ✅ ❌ ❎ ❓ ❔ ❕ ❗ ‼️ ⁉️ 💯 🔞 ⭕ ⛔ 🚫 ⚠️ ♻️ ➕ ➖ ✖️ ➗ 💲 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🔶 🔷 🔺 🔻 ▶️ ⏸️ ⏹️ 🔀 🔁 🔄 ⬆️ ⬇️ ⬅️ ➡️ ☑️ ✔️ 🔔 🔕 🔊 🔇 💬 💭"
)

private enum class T { CHAR, SPACER, SHIFT, DELETE, ENTER, MODE, EMOJI, GLOBE, SPACE, SETTINGS, HIDE }
private enum class Shift { OFF, ON, CAPS }
private enum class Mode { LETTERS, SYMBOLS, EMOJI }
private enum class RowKind { TOOLBAR, NUMBER, NORMAL }
private data class Key(
    val label: String,
    val type: T = T.CHAR,
    val weight: Float = 1f,
    val iconRes: Int = 0
)

/** Phím tự vẽ: nhẹ hơn TextView (không đo/dàn chữ mỗi lần), vẽ nền + chữ hoặc icon. */
private class KeyView(ctx: Context, val key: Key, radiusPx: Float, fillColor: Int) : View(ctx) {
    private val bg = GradientDrawable().apply {
        cornerRadius = radiusPx
        setColor(fillColor)
    }
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    val isLetter = key.type == T.CHAR && key.label.length == 1 && key.label[0].isLetter()
    var iconSizePx = 0
    var label: String = key.label
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }
    var icon: Drawable? = null
        set(v) {
            field = v
            invalidate()
        }

    fun setFill(color: Int) {
        bg.setColor(color)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        bg.setBounds(0, 0, width, height)
        bg.draw(canvas)
        val ic = icon
        if (ic != null) {
            val l = (width - iconSizePx) / 2
            val t = (height - iconSizePx) / 2
            ic.setBounds(l, t, l + iconSizePx, t + iconSizePx)
            ic.draw(canvas)
        } else if (label.isNotEmpty()) {
            val fm = paint.fontMetrics
            canvas.drawText(label, width / 2f, height / 2f - (fm.ascent + fm.descent) / 2f, paint)
        }
    }
}

/** Bong bóng chữ: chỉ vẽ chữ, đổi chữ không phải đo lại giao diện. */
private class BubbleView(ctx: Context, textPx: Float, radiusPx: Float) : View(ctx) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = textPx
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    var label: String = ""
        set(v) {
            if (field != v) {
                field = v
                invalidate()
            }
        }

    init {
        background = GradientDrawable().apply {
            cornerRadius = radiusPx
            setColor(Theme.bubble)
        }
        visibility = View.GONE
    }

    override fun onDraw(canvas: Canvas) {
        val fm = paint.fontMetrics
        canvas.drawText(label, width / 2f, height / 2f - (fm.ascent + fm.descent) / 2f, paint)
    }
}

/** Lưới emoji tự vẽ: chỉ vẽ các ô đang nhìn thấy, cuộn + vuốt mượt, mở tức thì. */
private class EmojiGridView(
    ctx: Context,
    private val cols: Int,
    private val cellPx: Int,
    emojiPx: Float,
    hintPx: Float,
    private val onPick: (String) -> Unit
) : View(ctx) {

    private var items: List<String> = emptyList()
    private var hint: String? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = emojiPx
    }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = hintPx
        color = Theme.dim
    }
    private val hiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Theme.keyPressed }
    private val baseline = paint.fontMetrics.let { -(it.ascent + it.descent) / 2f }
    private val scroller = OverScroller(ctx)
    private val cfg = ViewConfiguration.get(ctx)
    private val slop = cfg.scaledTouchSlop
    private val minFling = cfg.scaledMinimumFlingVelocity
    private val maxFling = cfg.scaledMaximumFlingVelocity
    private var velocity: VelocityTracker? = null
    private var scrollF = 0f
    private var downY = 0f
    private var lastY = 0f
    private var dragging = false
    private var pressedIndex = -1

    fun setItems(list: List<String>, emptyHint: String?) {
        items = list
        hint = emptyHint
        scroller.forceFinished(true)
        scrollF = 0f
        pressedIndex = -1
        scrollTo(0, 0)
        invalidate()
    }

    private fun maxScroll(): Int = ((items.size + cols - 1) / cols * cellPx - height).coerceAtLeast(0)

    private fun indexAt(x: Float, yContent: Float): Int {
        if (x < 0f || x >= width || yContent < 0f) return -1
        val c = (x / (width.toFloat() / cols)).toInt().coerceIn(0, cols - 1)
        val r = (yContent / cellPx).toInt()
        val i = r * cols + c
        return if (i in items.indices) i else -1
    }

    override fun onDraw(canvas: Canvas) {
        if (items.isEmpty()) {
            hint?.let { canvas.drawText(it, width / 2f, scrollY + height / 2f, hintPaint) }
            return
        }
        val cellW = width.toFloat() / cols
        val rows = (items.size + cols - 1) / cols
        val first = (scrollY / cellPx).coerceAtLeast(0)
        val last = ((scrollY + height) / cellPx).coerceAtMost(rows - 1)
        for (r in first..last) {
            for (c in 0 until cols) {
                val i = r * cols + c
                if (i >= items.size) break
                val cx = cellW * c + cellW / 2f
                val cy = r * cellPx + cellPx / 2f
                if (i == pressedIndex) {
                    canvas.drawRoundRect(
                        cellW * c + 2f, r * cellPx + 2f,
                        cellW * (c + 1) - 2f, (r + 1) * cellPx - 2f,
                        18f, 18f, hiPaint
                    )
                }
                canvas.drawText(items[i], cx, cy + baseline, paint)
            }
        }
    }

    override fun computeScroll() {
        if (scroller.computeScrollOffset()) {
            scrollF = scroller.currY.toFloat()
            scrollTo(0, scroller.currY)
            postInvalidateOnAnimation()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val vt = velocity ?: VelocityTracker.obtain().also { velocity = it }
        vt.addMovement(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val flinging = !scroller.isFinished
                scroller.forceFinished(true)
                downY = e.y
                lastY = e.y
                dragging = flinging
                pressedIndex = if (flinging) -1 else indexAt(e.x, e.y + scrollY)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(e.y - downY) > slop) {
                    dragging = true
                    pressedIndex = -1
                    invalidate()
                }
                if (dragging) {
                    scrollF = (scrollF + lastY - e.y).coerceIn(0f, maxScroll().toFloat())
                    scrollTo(0, scrollF.roundToInt())
                }
                lastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging && pressedIndex >= 0) {
                    items.getOrNull(pressedIndex)?.let(onPick)
                } else if (dragging) {
                    vt.computeCurrentVelocity(1000, maxFling.toFloat())
                    val vy = vt.yVelocity
                    if (abs(vy) > minFling) {
                        scroller.fling(0, scrollY, 0, (-vy).toInt(), 0, 0, 0, maxScroll())
                        postInvalidateOnAnimation()
                    }
                }
                pressedIndex = -1
                invalidate()
                vt.recycle()
                velocity = null
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedIndex = -1
                invalidate()
                vt.recycle()
                velocity = null
            }
        }
        return true
    }
}

class MyKeyboardService : InputMethodService() {

    private val prefs by lazy { Prefs.of(this) }

    private lateinit var outer: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var lettersPanel: LinearLayout
    private lateinit var symbolsPanel: LinearLayout
    private lateinit var emojiPanel: LinearLayout
    private lateinit var bubble: BubbleView
    private lateinit var emojiGrid: EmojiGridView
    private val emojiTabViews = mutableListOf<TextView>()

    private val handler = Handler(Looper.getMainLooper())
    private val letterViews = mutableListOf<KeyView>()
    private val enterViews = mutableListOf<KeyView>()
    private var shiftView: KeyView? = null
    private var shiftIcons: Array<Drawable?> = arrayOfNulls(3)
    private var enterRes = 0
    private var bubbleOwner: View? = null
    private val locA = IntArray(2)
    private val locB = IntArray(2)

    private var mode = Mode.LETTERS
    private var shift = Shift.OFF
    private var lastShiftTap = 0L
    private var emojiCat = 1
    private var autoCap = false
    private var capChars = false
    private var capsPending = false

    // Cài đặt được nhớ sẵn trong bộ nhớ: không phải đọc SharedPreferences mỗi lần gõ
    private var vibrateOn = true
    private var vibMs = 18L
    private var vibAmp = 125
    private var soundOn = true
    private var soundVol = 0.5f
    private var popupOn = true
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> loadSettings() }

    // Rung chạy ở luồng riêng để không làm chậm việc gõ
    private lateinit var fxThread: HandlerThread
    private lateinit var fxHandler: Handler
    private val vibrateTask = Runnable { doVibrate() }

    private var soundPool: SoundPool? = null
    private val soundIds = IntArray(3)

    private val keyFont: Typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    private val labelFont: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    @Suppress("DEPRECATION")
    private val vibrator: Vibrator? by lazy { getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator }

    /** Chỉ giữ emoji mà máy hiển thị được (tính sẵn ở luồng nền). */
    private val emojiLists: List<List<String>> by lazy {
        val p = Paint()
        EMOJI_RAW.map { raw -> raw.split(" ").filter { it.isNotEmpty() && p.hasGlyph(it) } }
    }

    private val repeatDelete = object : Runnable {
        override fun run() {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            afterKey(false)
            handler.postDelayed(this, 50)
        }
    }
    private val hideBubbleRunnable = Runnable { bubble.visibility = View.GONE }
    private val capsRunnable = Runnable { updateAutoShift() }

    /* ================= BỐ CỤC PHÍM: chỉnh ở đây ================= */
    private fun chars(s: String) = s.map { Key(it.toString()) }

    private fun toolbarKeys() = listOf(
        Key("", T.SETTINGS, 1f, R.drawable.ic_settings),
        Key("", T.SPACER, 8f),
        Key("", T.HIDE, 1f, R.drawable.ic_hide)
    )

    private fun bottomRow(modeLabel: String) = listOf(
        Key(modeLabel, T.MODE, 1.5f),
        Key("", T.EMOJI, 1f, R.drawable.ic_emoji),
        Key("", T.GLOBE, 1f, R.drawable.ic_globe),
        Key(",", T.CHAR, 1f),
        Key("", T.SPACE, 3f),
        Key(".", T.CHAR, 1f),
        Key("", T.ENTER, 1.5f)
    )

    private fun lettersLayout() = listOf(
        chars("1234567890"),
        chars("qwertyuiop"),
        listOf(Key("", T.SPACER, 0.5f)) + chars("asdfghjkl") + Key("", T.SPACER, 0.5f),
        listOf(Key("", T.SHIFT, 1.5f, R.drawable.ic_shift)) + chars("zxcvbnm") +
            Key("", T.DELETE, 1.5f, R.drawable.ic_backspace),
        bottomRow("?123")
    )

    private fun symbolsLayout() = listOf(
        chars("1234567890"),
        chars("@#\$%&-+()/"),
        listOf(Key("", T.SPACER, 0.5f)) + chars("*\"':;!?~|") + Key("", T.SPACER, 0.5f),
        listOf(Key("€", T.CHAR, 1.5f)) + chars("=[]{}<>") +
            Key("", T.DELETE, 1.5f, R.drawable.ic_backspace),
        bottomRow("ABC")
    )

    /* ================= VÒNG ĐỜI ================= */
    override fun onCreate() {
        super.onCreate()
        fxThread = HandlerThread("kb-feedback").also { it.start() }
        fxHandler = Handler(fxThread.looper)

        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val sp = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(attrs).build()
        soundIds[0] = sp.load(this, R.raw.key_standard, 1)
        soundIds[1] = sp.load(this, R.raw.key_space, 1)
        soundIds[2] = sp.load(this, R.raw.key_delete, 1)
        soundPool = sp

        loadSettings()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        Thread { emojiLists.size }.start()
    }

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        fxThread.quitSafely()
        soundPool?.release()
        soundPool = null
        super.onDestroy()
    }

    /** Không dùng chế độ toàn màn hình khi xoay ngang (gây giật và xấu). */
    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        shiftIcons[0] = icon(R.drawable.ic_shift, Theme.text)
        shiftIcons[1] = icon(R.drawable.ic_shift_on, Theme.text)
        shiftIcons[2] = icon(R.drawable.ic_caps, Theme.text)
        letterViews.clear()
        enterViews.clear()
        emojiTabViews.clear()
        shiftView = null
        enterRes = 0

        outer = FrameLayout(this).apply { setBackgroundColor(Theme.background) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        // Dựng sẵn cả 3 bảng một lần; đổi chế độ chỉ là ẩn/hiện, không dựng lại
        lettersPanel = buildKeyPanel(lettersLayout())
        symbolsPanel = buildKeyPanel(symbolsLayout())
        emojiPanel = buildEmojiPanel()
        content.addView(lettersPanel)
        content.addView(symbolsPanel)
        content.addView(emojiPanel)
        outer.addView(content, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        bubble = BubbleView(this, sp(30f), dp(12).toFloat())
        bubble.elevation = dp(6).toFloat()
        outer.addView(bubble, FrameLayout.LayoutParams(dp(56), dp(Theme.BUBBLE_DP)))

        updateEnterKeys()
        showMode()
        return outer
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val type = info?.inputType ?: 0
        val cls = type and InputType.TYPE_MASK_CLASS
        if (!restarting) mode = Mode.LETTERS
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) mode = Mode.SYMBOLS
        val isText = cls == InputType.TYPE_CLASS_TEXT
        capChars = isText && (type and InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS) != 0
        autoCap = isText && (type and (InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or
            InputType.TYPE_TEXT_FLAG_CAP_WORDS or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS)) != 0
        shift = Shift.OFF
        if (::outer.isInitialized) {
            updateEnterKeys()
            showMode()
        }
        updateAutoShift()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        handler.removeCallbacks(repeatDelete)
        handler.removeCallbacks(capsRunnable)
        handler.removeCallbacks(hideBubbleRunnable)
        capsPending = false
        if (::bubble.isInitialized) bubble.visibility = View.GONE
        super.onFinishInputView(finishingInput)
    }

    /* ================= DỰNG BÀN PHÍM (chỉ một lần) ================= */
    private fun buildKeyPanel(rows: List<List<Key>>): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.addView(buildRow(toolbarKeys(), RowKind.TOOLBAR))
        rows.forEachIndexed { i, r ->
            p.addView(buildRow(r, if (i == 0) RowKind.NUMBER else RowKind.NORMAL))
        }
        return p
    }

    private fun buildEmojiPanel(): LinearLayout {
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL

        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.TOOLBAR_DP))
        EMOJI_TABS.forEachIndexed { i, icon ->
            val tab = TextView(this)
            tab.text = icon
            tab.gravity = Gravity.CENTER
            tab.textSize = 18f
            val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, 1f)
            lp.setMargins(dp(2), dp(3), dp(2), dp(3))
            tab.layoutParams = lp
            tab.setOnClickListener {
                feedback(T.CHAR)
                selectEmojiTab(i)
            }
            emojiTabViews.add(tab)
            tabs.addView(tab)
        }
        panel.addView(tabs)

        emojiGrid = EmojiGridView(
            this, Theme.EMOJI_COLS, dp(Theme.EMOJI_CELL_DP), sp(26f), sp(14f)
        ) { e ->
            feedback(T.CHAR)
            currentInputConnection?.commitText(e, 1)
            addRecent(e)
        }
        emojiGrid.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(Theme.EMOJI_GRID_DP))
        panel.addView(emojiGrid)

        panel.addView(
            buildRow(
                listOf(
                    Key("ABC", T.MODE, 1.5f),
                    Key("", T.SPACE, 7f),
                    Key("", T.DELETE, 1.5f, R.drawable.ic_backspace)
                ),
                RowKind.NORMAL
            )
        )
        return panel
    }

    private fun buildRow(keys: List<Key>, kind: RowKind): LinearLayout {
        val h = when (kind) {
            RowKind.TOOLBAR -> Theme.TOOLBAR_DP
            RowKind.NUMBER -> Theme.NUMBER_ROW_DP
            RowKind.NORMAL -> Theme.ROW_DP
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, dp(h))
        keys.forEach { row.addView(buildKey(it, kind)) }
        return row
    }

    private fun baseColor(type: T): Int = when (type) {
        T.ENTER -> Theme.accent
        T.SHIFT -> if (shift == Shift.OFF) Theme.special else Theme.shiftOn
        T.DELETE, T.MODE, T.GLOBE, T.EMOJI -> Theme.special
        T.SETTINGS, T.HIDE -> Color.TRANSPARENT
        else -> Theme.key
    }

    private fun rounded(color: Int) = GradientDrawable().apply {
        cornerRadius = dp(Theme.CORNER_DP).toFloat()
        setColor(color)
    }

    private fun icon(res: Int, color: Int): Drawable {
        val d = getDrawable(res)!!.mutate()
        d.setTint(color)
        return d
    }

    private fun buildKey(k: Key, kind: RowKind): View {
        if (k.type == T.SPACER) {
            val spacer = View(this)
            spacer.layoutParams = LinearLayout.LayoutParams(0, MATCH_PARENT, k.weight)
            return spacer
        }
        val m = dp(Theme.KEY_MARGIN_DP)
        val pressedColor = if (k.type == T.ENTER) Theme.accentPressed else Theme.keyPressed
        val kv = KeyView(this, k, dp(Theme.CORNER_DP).toFloat(), baseColor(k.type))
        val lp = LinearLayout.LayoutParams(0, MATCH_PARENT, k.weight)
        lp.setMargins(m, m, m, m)
        kv.layoutParams = lp
        kv.iconSizePx = dp(if (kind == RowKind.TOOLBAR) 20 else 22)

        if (k.iconRes != 0) {
            val tint = when {
                k.type == T.ENTER -> Theme.onAccent
                kind == RowKind.TOOLBAR -> Theme.dim
                else -> Theme.text
            }
            kv.icon = icon(k.iconRes, tint)
        } else {
            kv.paint.typeface = if (k.type == T.MODE) labelFont else keyFont
            kv.paint.textSize = sp(
                when {
                    kind == RowKind.NUMBER -> 15f
                    k.type == T.MODE -> 14f
                    k.type == T.CHAR -> if (kv.isLetter) 22f else 20f
                    else -> 16f
                }
            )
            kv.paint.color = if (kind == RowKind.NUMBER) Theme.dim else Theme.text
        }

        if (kv.isLetter) letterViews.add(kv)
        if (k.type == T.SHIFT) shiftView = kv
        if (k.type == T.ENTER) enterViews.add(kv)

        kv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    flushCapsUpdate()
                    kv.setFill(pressedColor)
                    if (k.type == T.CHAR) {
                        bubbleOwner = v
                        showBubble(kv)
                    }
                    onKeyDown(k, kv)
                    feedback(k.type)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    kv.setFill(baseColor(k.type))
                    handler.removeCallbacks(repeatDelete)
                    if (bubbleOwner === v) scheduleHideBubble()
                }
            }
            true
        }
        return kv
    }

    /* ================= CHẾ ĐỘ / NHÃN ================= */
    private fun showMode() {
        bubble.visibility = View.GONE
        lettersPanel.visibility = if (mode == Mode.LETTERS) View.VISIBLE else View.GONE
        symbolsPanel.visibility = if (mode == Mode.SYMBOLS) View.VISIBLE else View.GONE
        emojiPanel.visibility = if (mode == Mode.EMOJI) View.VISIBLE else View.GONE
        refreshLabels()
    }

    private fun refreshLabels() {
        val upper = shift != Shift.OFF
        for (kv in letterViews) {
            kv.label = if (upper) kv.key.label.uppercase() else kv.key.label
        }
        shiftView?.let { kv ->
            kv.icon = shiftIcons[shift.ordinal]
            kv.setFill(baseColor(T.SHIFT))
        }
    }

    private fun enterIconRes(): Int {
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        if ((opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return R.drawable.ic_enter
        return when (opts and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_NEXT -> R.drawable.ic_next
            EditorInfo.IME_ACTION_SEARCH -> R.drawable.ic_search
            EditorInfo.IME_ACTION_SEND -> R.drawable.ic_send
            EditorInfo.IME_ACTION_DONE -> R.drawable.ic_done
            else -> R.drawable.ic_enter
        }
    }

    private fun updateEnterKeys() {
        val r = enterIconRes()
        if (r == enterRes) return
        enterRes = r
        for (kv in enterViews) kv.icon = icon(r, Theme.onAccent)
    }

    /* ================= EMOJI ================= */
    private fun selectEmojiTab(i: Int) {
        emojiCat = i
        emojiTabViews.forEachIndexed { idx, t ->
            t.alpha = if (idx == i) 1f else 0.5f
            t.background = if (idx == i) rounded(Theme.special) else null
        }
        val items = if (i == 0) recentEmoji() else emojiLists[i - 1]
        emojiGrid.setItems(items, if (i == 0) "No recent emoji yet" else null)
    }

    private fun recentEmoji(): List<String> =
        (prefs.getString(Prefs.RECENT, "") ?: "").split(" ").filter { it.isNotEmpty() }

    private fun addRecent(e: String) {
        val list = (listOf(e) + recentEmoji().filter { it != e }).take(32)
        prefs.edit().putString(Prefs.RECENT, list.joinToString(" ")).apply()
    }

    /* ================= BONG BÓNG CHỮ ================= */
    private fun showBubble(kv: KeyView) {
        if (!popupOn) return
        handler.removeCallbacks(hideBubbleRunnable)
        kv.getLocationInWindow(locA)
        outer.getLocationInWindow(locB)

        val w = kv.width + dp(16)
        val h = dp(Theme.BUBBLE_DP)
        val lp = bubble.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h) {
            lp.width = w
            lp.height = h
            bubble.layoutParams = lp
        }
        val maxX = (outer.width - w).coerceAtLeast(0)
        val x = (locA[0] - locB[0] - dp(8)).coerceIn(0, maxX)
        val y = (locA[1] - locB[1] - h).coerceAtLeast(0)
        bubble.label = kv.label
        bubble.translationX = x.toFloat()
        bubble.translationY = y.toFloat()
        bubble.visibility = View.VISIBLE
    }

    private fun scheduleHideBubble() {
        handler.removeCallbacks(hideBubbleRunnable)
        handler.postDelayed(hideBubbleRunnable, 70)
    }

    /* ================= RUNG + ÂM THANH ================= */
    private fun loadSettings() {
        vibrateOn = prefs.getBoolean(Prefs.VIBRATE, true)
        val s = prefs.getInt(Prefs.VIB_STRENGTH, 5).coerceIn(1, 10)
        vibMs = 8L + s * 2L
        vibAmp = (s * 25).coerceIn(1, 255)
        soundOn = prefs.getBoolean(Prefs.SOUND, true)
        soundVol = prefs.getInt(Prefs.SOUND_VOLUME, 5).coerceIn(0, 10) / 10f
        popupOn = prefs.getBoolean(Prefs.POPUP, true)
    }

    private fun feedback(type: T) {
        if (vibrateOn) {
            fxHandler.removeCallbacks(vibrateTask)
            fxHandler.post(vibrateTask)
        }
        if (soundOn && soundVol > 0f) {
            val id = when (type) {
                T.SPACE -> soundIds[1]
                T.DELETE -> soundIds[2]
                else -> soundIds[0]
            }
            soundPool?.play(id, soundVol, soundVol, 1, 0, 1f)
        }
    }

    @Suppress("DEPRECATION")
    private fun doVibrate() {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        if (Build.VERSION.SDK_INT >= 26) {
            val amp = if (v.hasAmplitudeControl()) vibAmp else VibrationEffect.DEFAULT_AMPLITUDE
            v.vibrate(VibrationEffect.createOneShot(vibMs, amp))
        } else {
            v.vibrate(vibMs)
        }
    }

    /* ================= XỬ LÝ PHÍM ================= */
    private fun onKeyDown(k: Key, kv: KeyView) {
        val ic = currentInputConnection
        when (k.type) {
            T.CHAR -> {
                ic?.commitText(kv.label, 1)
                afterKey(kv.isLetter)
            }
            T.SPACE -> {
                ic?.commitText(" ", 1)
                afterKey(false)
            }
            T.DELETE -> {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                afterKey(false)
                handler.postDelayed(repeatDelete, 400)
            }
            T.ENTER -> {
                sendEnter()
                afterKey(false)
            }
            T.SHIFT -> toggleShift()
            T.MODE -> handler.post {
                mode = if (mode == Mode.LETTERS) Mode.SYMBOLS else Mode.LETTERS
                showMode()
            }
            T.EMOJI -> handler.post {
                mode = Mode.EMOJI
                selectEmojiTab(if (recentEmoji().isEmpty()) 1 else 0)
                showMode()
            }
            T.GLOBE -> {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
            T.SETTINGS -> {
                val i = Intent(this, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            }
            T.HIDE -> requestHideSelf(0)
            T.SPACER -> Unit
        }
    }

    private fun toggleShift() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == Shift.CAPS -> Shift.OFF
            shift == Shift.ON && now - lastShiftTap < 350 -> Shift.CAPS
            shift == Shift.ON -> Shift.OFF
            else -> Shift.ON
        }
        lastShiftTap = now
        refreshLabels()
    }

    /**
     * Cập nhật Shift sau mỗi phím mà KHÔNG hỏi ứng dụng khi gõ chữ thường
     * (hỏi ứng dụng là thao tác chậm, trước đây gây khựng).
     */
    private fun afterKey(letter: Boolean) {
        if (shift == Shift.CAPS) return
        if (capChars) {
            if (shift != Shift.ON) {
                shift = Shift.ON
                refreshLabels()
            }
            return
        }
        if (letter) {
            if (shift == Shift.ON) {
                shift = Shift.OFF
                refreshLabels()
            }
            return
        }
        if (autoCap) {
            scheduleCapsUpdate()
        } else if (shift == Shift.ON) {
            shift = Shift.OFF
            refreshLabels()
        }
    }

    private fun scheduleCapsUpdate() {
        capsPending = true
        handler.removeCallbacks(capsRunnable)
        handler.postDelayed(capsRunnable, 80)
    }

    private fun flushCapsUpdate() {
        if (!capsPending) return
        handler.removeCallbacks(capsRunnable)
        updateAutoShift()
    }

    /** Tự viết hoa đầu câu (hỏi ứng dụng một lần, không nằm trong lúc gõ). */
    private fun updateAutoShift() {
        capsPending = false
        if (shift == Shift.CAPS) return
        val caps = if (autoCap) {
            currentInputConnection?.getCursorCapsMode(currentInputEditorInfo?.inputType ?: 0) ?: 0
        } else {
            0
        }
        val next = if (caps != 0) Shift.ON else Shift.OFF
        if (next != shift) {
            shift = next
            refreshLabels()
        }
    }

    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun sp(v: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)
}
