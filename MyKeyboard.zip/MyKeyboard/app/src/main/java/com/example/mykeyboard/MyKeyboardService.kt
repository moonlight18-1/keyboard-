package com.example.mykeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

/* ================= GIAO DIỆN: chỉnh màu / bo góc ở đây ================= */
private object Theme {
    val background = Color.parseColor("#12141C")
    val key = Color.parseColor("#252A3B")
    val keyPressed = Color.parseColor("#3B4363")
    val special = Color.parseColor("#1B1F2E")
    val shiftOn = Color.parseColor("#3D4A7A")
    val accent = Color.parseColor("#4FD1C5")
    val accentPressed = Color.parseColor("#2FA89D")
    val text = Color.parseColor("#E8EAF2")
    val dim = Color.parseColor("#8E94AD")
    val onAccent = Color.parseColor("#06201D")
    const val CORNER_DP = 10
    const val KEY_MARGIN_DP = 3
    const val ROW_DP = 52
    const val NUMBER_ROW_DP = 42
}

private enum class T { CHAR, SPACER, SHIFT, DELETE, ENTER, MODE, GLOBE, SPACE }
private enum class Shift { OFF, ON, CAPS }
private enum class Mode { LETTERS, SYMBOLS }
private data class Key(val label: String, val type: T = T.CHAR, val weight: Float = 1f)

class MyKeyboardService : InputMethodService() {

    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val letterViews = mutableListOf<Pair<TextView, String>>()
    private var shiftView: TextView? = null
    private var mode = Mode.LETTERS
    private var shift = Shift.OFF
    private var lastShiftTap = 0L

    private val repeatDelete = object : Runnable {
        override fun run() {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            handler.postDelayed(this, 50)
        }
    }

    /* ================= BỐ CỤC PHÍM: chỉnh ở đây ================= */
    private fun chars(s: String) = s.map { Key(it.toString()) }

    private fun bottomRow(modeLabel: String) = listOf(
        Key(modeLabel, T.MODE, 1.5f),
        Key("🌐", T.GLOBE, 1f),
        Key(",", T.CHAR, 1f),
        Key("", T.SPACE, 4f),
        Key(".", T.CHAR, 1f),
        Key(enterLabel(), T.ENTER, 1.5f)
    )

    private fun lettersLayout() = listOf(
        chars("1234567890"),
        chars("qwertyuiop"),
        listOf(Key("", T.SPACER, 0.5f)) + chars("asdfghjkl") + Key("", T.SPACER, 0.5f),
        listOf(Key("⇧", T.SHIFT, 1.5f)) + chars("zxcvbnm") + Key("⌫", T.DELETE, 1.5f),
        bottomRow("?123")
    )

    private fun symbolsLayout() = listOf(
        chars("1234567890"),
        chars("@#\$%&-+()/"),
        listOf(Key("", T.SPACER, 0.5f)) + chars("*\"':;!?~|") + Key("", T.SPACER, 0.5f),
        listOf(Key("€", T.CHAR, 1.5f)) + chars("=[]{}<>") + Key("⌫", T.DELETE, 1.5f),
        bottomRow("ABC")
    )

    /* ================= VÒNG ĐỜI ================= */
    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Theme.background)
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) mode = Mode.LETTERS
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) mode = Mode.SYMBOLS
        shift = Shift.OFF
        if (::root.isInitialized) render()
        afterInput()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        handler.removeCallbacks(repeatDelete)
        super.onFinishInputView(finishingInput)
    }

    /* ================= VẼ BÀN PHÍM ================= */
    private fun render() {
        root.removeAllViews()
        letterViews.clear()
        shiftView = null
        val rows = if (mode == Mode.LETTERS) lettersLayout() else symbolsLayout()
        rows.forEachIndexed { i, row ->
            val rowView = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(if (i == 0) Theme.NUMBER_ROW_DP else Theme.ROW_DP)
                )
            }
            row.forEach { rowView.addView(buildKey(it, i == 0)) }
            root.addView(rowView)
        }
        refreshLabels()
    }

    private fun baseColor(type: T): Int = when (type) {
        T.ENTER -> Theme.accent
        T.SHIFT -> if (shift == Shift.OFF) Theme.special else Theme.shiftOn
        T.DELETE, T.MODE, T.GLOBE -> Theme.special
        else -> Theme.key
    }

    private fun buildKey(k: Key, isNumberRow: Boolean): View {
        if (k.type == T.SPACER) {
            return View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, k.weight)
            }
        }
        val bg = GradientDrawable().apply {
            cornerRadius = dp(Theme.CORNER_DP).toFloat()
            setColor(baseColor(k.type))
        }
        val pressedColor = if (k.type == T.ENTER) Theme.accentPressed else Theme.keyPressed
        val m = dp(Theme.KEY_MARGIN_DP)

        val tv = TextView(this).apply {
            text = k.label
            gravity = Gravity.CENTER
            textSize = when {
                isNumberRow -> 15f
                k.type == T.CHAR -> 21f
                else -> 16f
            }
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(
                when {
                    k.type == T.ENTER -> Theme.onAccent
                    isNumberRow -> Theme.dim
                    else -> Theme.text
                }
            )
            background = bg
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, k.weight)
                .apply { setMargins(m, m, m, m) }
        }

        if (k.type == T.CHAR && k.label.length == 1 && k.label[0].isLetter()) {
            letterViews.add(tv to k.label)
        }
        if (k.type == T.SHIFT) shiftView = tv

        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    bg.setColor(pressedColor)
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    onKeyDown(k)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    bg.setColor(baseColor(k.type))
                    handler.removeCallbacks(repeatDelete)
                }
            }
            true
        }
        return tv
    }

    private fun refreshLabels() {
        val upper = shift != Shift.OFF
        for ((tv, base) in letterViews) tv.text = if (upper) base.uppercase() else base
        shiftView?.let { tv ->
            tv.text = if (shift == Shift.CAPS) "⇪" else "⇧"
            (tv.background as GradientDrawable).setColor(baseColor(T.SHIFT))
        }
    }

    /* ================= XỬ LÝ PHÍM ================= */
    private fun onKeyDown(k: Key) {
        val ic = currentInputConnection
        when (k.type) {
            T.CHAR -> {
                val up = shift != Shift.OFF && k.label.length == 1 && k.label[0].isLetter()
                ic?.commitText(if (up) k.label.uppercase() else k.label, 1)
                afterInput()
            }
            T.SPACE -> {
                ic?.commitText(" ", 1)
                afterInput()
            }
            T.DELETE -> {
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                handler.postDelayed(repeatDelete, 400)
            }
            T.ENTER -> {
                sendEnter()
                afterInput()
            }
            T.SHIFT -> toggleShift()
            T.MODE -> handler.post {
                mode = if (mode == Mode.LETTERS) Mode.SYMBOLS else Mode.LETTERS
                render()
            }
            T.GLOBE -> {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
            T.SPACER -> Unit
        }
    }

    private fun toggleShift() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == Shift.CAPS -> Shift.OFF
            shift == Shift.ON && now - lastShiftTap < 350 -> Shift.CAPS
            shift == Shift.ON -> Shift.OFF
            else -> Shift.ON
        }
        lastShiftTap = now
        refreshLabels()
    }

    /** Tự viết hoa đầu câu; tắt Shift sau khi gõ một chữ. */
    private fun afterInput() {
        if (shift == Shift.CAPS) return
        val caps = currentInputConnection
            ?.getCursorCapsMode(currentInputEditorInfo?.inputType ?: 0) ?: 0
        val next = if (caps != 0) Shift.ON else Shift.OFF
        if (next != shift) {
            shift = next
            refreshLabels()
        }
    }

    private fun enterLabel(): String {
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        if ((opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "↵"
        return when (opts and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "Đi"
            EditorInfo.IME_ACTION_SEARCH -> "Tìm"
            EditorInfo.IME_ACTION_SEND -> "Gửi"
            EditorInfo.IME_ACTION_NEXT -> "Tiếp"
            EditorInfo.IME_ACTION_DONE -> "Xong"
            else -> "↵"
        }
    }

    private fun sendEnter() {
        val ic = currentInputConnection ?: return
        val opts = currentInputEditorInfo?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
