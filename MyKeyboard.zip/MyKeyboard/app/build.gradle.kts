plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.mykeyboard"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.mykeyboard"
        minSdk = 24
        targetSdk = 34
        // Mỗi lần cập nhật: tăng versionCode lên 1 và đổi versionName
        versionCode = 13
        versionName = "1.5.5"
    }

    // Ký bằng khóa cố định, nhờ đó bản mới cài đè lên bản cũ được
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        // Vẫn dùng lệnh assembleDebug, nhưng APK được tối ưu như bản phát hành:
        // tắt chế độ gỡ lỗi (chậm) và bật R8 (thu gọn + tối ưu mã).
        getByName("debug") {
            isDebuggable = false
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
        // Bỏ các lệnh kiểm tra null thừa mà Kotlin chèn vào mỗi hàm
        freeCompilerArgs += listOf(
            "-Xno-param-assertions",
            "-Xno-call-assertions",
            "-Xno-receiver-assertions"
        )
    }
}
